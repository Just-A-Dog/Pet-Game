{
  "$GMNotes":"v2",
  "%Name":"THE WAY THINGS WORK",
  "name":"THE WAY THINGS WORK",
  "parent":{
    "name":"Pet Game",
    "path":"Pet Game.yyp",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}