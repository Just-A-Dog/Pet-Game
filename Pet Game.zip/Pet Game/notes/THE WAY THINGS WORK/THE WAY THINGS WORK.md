Freaks are divided into body parts that all react differently

Head Skeleton/Body Skeleton - It has two skeletons, a base and transformed type. Base is always global.base.
	- The base is paired with the transformed skeleton. Easily, as the colors denote which gets paired with which.
	- Each color denotes a body part. The full list can be found under Init.

Head/Body - Each has two types. A global base type, and the shape it is turning into.
	- First, it checks the cache to see if the paired list of pixels is already in the JSON cache.
	- If not, then:
		- Take the sprites, then gather the outlining pixels, putting it into an array.
		- That array is then paired with the array of the transformed version of the body part. //TODO use a half-radial to pair the points.
	
    - The paired pixel list has x,y and color from each pixel.
	- Then, the current pixel list is created, determined by the 'intensity' of the body part, with 0 being closer to base, and 1 being closer to its transformed state.
	- XYDepth is then determined, sometimes using co-ordinates from the current_pixel list to make sure it is in the proper place. Head, for example, is offset by half of its bottom row.
	- The pixel list is then drawn via scr_draw_outline, and the insides are drawn via scr_draw_and_fill_sprite

Chin - Chin is connected to the head, however, when the body transforms, depending on the shape, the lower the chin goes [up to 4 pixels, leaving just 2 pixels of the chin left.]
	 - It does not have an intensity.
	 
Eyes - First the sprite is gone through with its own color_changing method to match the palette.
     - Then it is drawn like a sprite.
	 - I still need to figure out how this will work with sideways eyes, but we will get there!
	 - I'm thinking they only become 'sideways eyes' after a transformation.
	 
Mouth - Changes position based on head skeleton current mouth position.
      - Changes into a different mouth upon transformation.

Ears/Nose/Tail - Simply transforms into another shape from one pixel. I haven't gotten this far yet, but hopefully it works!
Arms / Legs - Don't change shape at all, but do move based off of the body skeleton.