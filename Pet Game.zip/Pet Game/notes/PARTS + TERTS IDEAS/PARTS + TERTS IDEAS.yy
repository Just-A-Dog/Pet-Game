{
  "$GMNotes":"v2",
  "%Name":"PARTS + TERTS IDEAS",
  "name":"PARTS + TERTS IDEAS",
  "parent":{
    "name":"IDEAS",
    "path":"folders/NOTES/IDEAS.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}