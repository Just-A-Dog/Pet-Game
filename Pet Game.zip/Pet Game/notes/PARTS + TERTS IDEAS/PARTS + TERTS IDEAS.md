A-Types: [Atypical phenomes]
Physical:
	- One eye
	- One arm
	- Blinking asynchronatically
	- Lazy eye
	- Separate ear types
	- Cyclops

Mental:
	- Ticks [Cough,Sneeze]
	- Zones out occasionally
	- Energy is slower to raise AND lower, meaning longer sleep times
	- VERY picky about food, faster mutation rate
	- Has a harder time making friends, has a harder time hating made friends
	- Very good at one particular stat, awful at the rest
	
HEAD SHAPES:
	- Cat/Raccoon - [Short snout]
	- Dog/Bear/Rabbit - [Doug face]
	- Wolf - Long[er] snout, big nose
	- Badger *Could just be a pattern
	- Rhino - Horn on nose
	- Capybara/Horse
	- Bill
	- Beak
	- TV/Computer
	- Frog
	- None [x]
	- Pig
	- Elephant/Tapir
	- Slowpoke
	- Buttface [Gekkomon]
	- Lizard/Chameleon [Think Gugu's mask]
	
	[SIDEWAYS EYES]
	- Crocodile
	- Hippo
	- BIG Beak
	- Whale/Orca
	
FOREHEAD:
	- Unicorn horn
	- Hair tuft
	- Mane/Mohawk
	- Spikes
	- Short squat horn
	- Antlers

BODY SHAPES:
	- In reference3.GAL
	- Rectangle
	- Equilateral
	- Isoceles
	- Square
	- Circle
	
EAR SHAPES:
    - Pointed
	- Rounded [Bear -> Mouse]
	- Tall [Drowzee -> Rabbit]
	- Floppy [Dog -> Basset hound]
	- Elephant-like
	- Hippo-like
	- Shrek-like [Could be used for aliens]
	- Antennae
	
NECK:
	- Mane
	- Frill [Vaporeon]
	- Fur
	- Inflatable

TAILS:
	- Lizard
	- Bird [Short -> Peacock]
	- Cat [Ball -> Cat]
	- Fox [Fox -> Husky]
	- Curled [Rhino -> Pig]
	- Lion [Rabbit -> Lion]
	- Rat
	- Squirrel
	- Spade [Badger -> Beaver]
	- Whale
	
EYE SHAPES:
	- Standard
	- Tired
	- Wide
	- Squinted
	- Closed
	- Angry [Typhlosion]
	- Squinted [Drowzee]

Pupils:	
	- Pinprick [Slowpoke]
	- Alien [Vaporeon]
	- Bishounen
	- Slitted [Cat]
	- Digimon-esque/Mikumiku suikoden

--==TERTS==--
Head:
	- Snout tert [slowpoke]
	- Cat tert [lines on head]
	- Doug tert
	- Calico tert
	- Panda tert
	- Otto tert
	- Raccoon tert
	- Tip of nose tert
	- Metallic tert
	- Typhlosion
	- Duke
	- Heart forehead
	- Cheek Freckles/Nose Freckles/Both
	
Chest: 
	- Heart shape top of chest [may combine with snouth terts on head]
	- Belly tert [think like the regular weasel thing]
	- Metallic tert
	- Gabumon belly tert
	- Typhlosion

Arms:
	- End of hands tert
	- Fingles tert

Legs:
	- End of legs tert
	- Fingles tert
	
Tail:
	- Tip of tail tert
	- Stripes tert
	- Bottom of tail tert
	- Bottom of tail + tip tert
	
Ears:
	- Tip of ears
	- Inner ears
	- Tip + Inner ears
	- Differently colored ears	