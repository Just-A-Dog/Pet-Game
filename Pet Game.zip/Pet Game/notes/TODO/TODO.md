
CRITTER: 
	- Rotate the boy
	- 

 
PLANTS:
 - Buried plant
 - Sprout
 - Mid tree
 - Full tree
 - Full tree + fruit
 
WAYS TO INCREASE EFFICIENCY:

THINGS TO TRY:
	- So, instead of having intensity go from 0 to 1 to 0 to 1 in order to switch shapes, we can try an active swapping system
	- NOW HEAR ME OUT
	- In the cache we save every shape /post/ walkabout, meaning when a new pairing is created the only thing we have to run is scr_pair_points
 
 Organization:
 Changing some stuff into structs
 Change names of scripts to not be _1/_2...