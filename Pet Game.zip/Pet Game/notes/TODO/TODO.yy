{
  "$GMNotes":"v2",
  "%Name":"TODO",
  "name":"TODO",
  "parent":{
    "name":"Pet Game",
    "path":"Pet Game.yyp",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}