The Gates:
Place where the player might meet one of their Nimls who previously passed away without reincarnating immediately. 
This is when a Niml wants to come back as a baby. The gatekeeper will say something along the lines of:
	"This one wants to see you. It may want to come back and live in your garden once more. I may help you for a fee."
		- Pay [xxx] to turn [name] back into a seed.
		- Tell them it was nice to see them, but you don't need them right now. [Reduced chance for that one to want to ressurrect]
		- Tell them you cannot afford it. [No, but with same chance.]

Chances the Niml will show up will never be 0, there will always be a chance, no matter how many times you say 'no'.

You can also bring Niml here to let them pass through the gate. You will obtain currency based on the 'value' of the Niml.
Order of money tiers:
	-An older, well-loved Niml
	-A strong Niml
	-A baby Niml
	-A sad Niml

Apparel:
Place to buy clothes/Hats/Contacts, etc.

Gear:
Place to buy weapons/armor for adventuring

Hospital:
Edit birth certificates
See stats
See [very vague, wide variety] personality
See Atypes
Seed genome editing
	- Once per seed, can guarantee a 'type'/color of something. [If the player has a resurrected seed, they already 'know' what is on the Niml]

Help fix illness
Help fix injury
	- Injury has a chance to fail [save-scummable], in which case, the Niml has the injury permanently until they resurrect.
	- Ressurrection doesn't get rid of defect injuries, though. If they're born without an arm, that's permanent, baby.

Furniture:
	- Buy homes/interactable decorations for the Nimls.

Adventure:
	- Send Nimls on adventures!
	- Adventures can send up to 3, to earn treasure/money to buy stuff
	