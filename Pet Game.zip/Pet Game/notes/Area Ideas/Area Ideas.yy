{
  "$GMNotes":"v2",
  "%Name":"Area Ideas",
  "name":"Area Ideas",
  "parent":{
    "name":"IDEAS",
    "path":"folders/NOTES/IDEAS.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}