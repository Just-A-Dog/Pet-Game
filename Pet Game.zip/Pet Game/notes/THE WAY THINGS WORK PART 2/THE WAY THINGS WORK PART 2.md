This note describes the route each body part goes through:
BODY:
scr_body_part_init_3 -> scr_body_part_init_helper_2 -> 
											scr_analyze_shape_3.
											
											scr_walkabout_2 ->
													scr_find_adjacent_pixel.
													scr_find_adjacent_pixel_color.
											
											scr_pair_points_3 ->
													scr_pointOnLine.