{
  "$GMNotes":"v2",
  "%Name":"THE WAY THINGS WORK PART 2",
  "name":"THE WAY THINGS WORK PART 2",
  "parent":{
    "name":"Pet Game",
    "path":"Pet Game.yyp",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}