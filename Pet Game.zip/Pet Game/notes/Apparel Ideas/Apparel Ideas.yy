{
  "$GMNotes":"v2",
  "%Name":"Apparel Ideas",
  "name":"Apparel Ideas",
  "parent":{
    "name":"IDEAS",
    "path":"folders/NOTES/IDEAS.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}