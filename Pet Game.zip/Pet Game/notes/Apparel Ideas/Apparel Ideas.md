HEAD:
Witch hat [Black, White, etc...]
Conical Hat [Ala Witch Hat Atelier]
Big Bow [Different colors, Mirabelle]
Bonnie Hat
Little Crown [Char]
Top Hat
Headband

EYE:
Eye patch
Flower over eye
Eye shadow
Piercing
Nerdy Glasses
Stylish glasses
Monocle
Little glasses
Contacts

NECK:
Bandana

BODY:
Cloak [Various colors... Siffrin]

