Each body part sets its location in its create event. [That way we don't have to write like 18 scripts for various other things.]
It'll find its own depth, x, any y co-ordinate.
If it needs to find width/height find a reasonable way to do that.
	- Unchanging sprites are easy.
	- For Head, we're going to find the bottom row pixels. It's fine, but we need to set the current list before finding position.

- Skeletons need to be separated into body/head skeletons.
- Each freak is going to have 4, count 'em, 4 skeletons. 2 For the head, 2 for the body.

PAIRING POINTS:

- Since pairing will only really matter for Body and Head, we'll only work on that.
- We start at 0 degrees and turn the radius until we hit a point that hasn't been paired.
- Whatever points land on that line [rounded] get paired and added to the list
- Continue until we reach 360 degrees.

[I know it's vague, figure it out.