{
  "$GMNotes":"v2",
  "%Name":"NEW TRANSFORMATION NOTES",
  "name":"NEW TRANSFORMATION NOTES",
  "parent":{
    "name":"NOTES",
    "path":"folders/NOTES.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}