if(scr_check_change_sprite(app_chin_list)){
	scr_find_xydepth_chin();
	x = chin_x;
	y = chin_y;
	//Depth is always 0 for chin.
}
