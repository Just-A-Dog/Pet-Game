cache_key = scr_get_cache_key(base_chin_type, chin_type);
app_chin_list = scr_body_part_init(base_chin_type, chin_type, cache_key); 