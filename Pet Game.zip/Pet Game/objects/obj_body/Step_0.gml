if(scr_check_change_sprite(app_body_list)){
	scr_find_xydepth_body();
	x = body_x;
	y = body_y;
	//Depth is always 0 for body, I guess. LOL
}
