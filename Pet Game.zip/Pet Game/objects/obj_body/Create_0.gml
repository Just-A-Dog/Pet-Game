cache_key = scr_get_cache_key(global.base_body, body_type);
app_body_list = scr_body_part_init(global.base_body, body_type, cache_key);

//Create arms
scr_find_xydepth_left_arm();
left_arm = instance_create_depth(left_arm_x, left_arm_y, left_arm_depth, obj_arm,{
	freak_id : freak_id,
	arm_type : left_arm_type,
	dir : dir,
	base_color : base_color,
	intensity : intensity,
	global_arm_type : global.base_left_arm,
	color_coords : color_coords,
});

scr_find_xydepth_right_arm();
right_arm = instance_create_depth(right_arm_x, right_arm_y, right_arm_depth, obj_arm,{
	freak_id : freak_id,
	arm_type : right_arm_type,
	dir : dir,
	base_color : base_color,
	intensity : intensity,
	global_arm_type : global.base_right_arm,
	left : false,
	color_coords : color_coords,
});

//Legs
scr_find_xydepth_left_leg();
left_leg = instance_create_depth(left_leg_x,left_leg_y,0,obj_leg,{
	freak_id : freak_id,
	leg_type : left_leg_type,
	dir : dir,
	base_color : base_color,
	intensity : leg_intensity,
	global_leg_type : global.base_left_leg,
	color_coords : color_coords,
});


scr_find_xydepth_right_leg();
right_leg = instance_create_depth(right_leg_x,right_leg_y,right_leg_depth,obj_leg,{
	freak_id : freak_id,
	leg_type : right_leg_type,
	dir : dir,
	base_color : base_color,
	intensity : leg_intensity,
	global_leg_type : global.base_right_leg,
	left : false,
	color_coords : color_coords,
});
