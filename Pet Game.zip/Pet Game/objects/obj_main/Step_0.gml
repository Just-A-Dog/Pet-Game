//TODO: Remove debug
if(keyboard_check_released(ord("S"))){
	screen_save("DEBUG_IMG.png");
}

//Rotates the boy.
if(type == "ROTATE"){
	if(keyboard_check_released(vk_right)){
		dir_array_index--;
		if(dir_array_index < 0) dir_array_index = 7;
		scr_change_directions_2(freak, global.dir[dir_array_index]);
	}
	else if(keyboard_check_released(vk_left)){
		dir_array_index++;
		if(dir_array_index > 7) dir_array_index = 0;
		scr_change_directions_2(freak, global.dir[dir_array_index]);
	}
}

if(type == "CHANGE BODY INTENSITY"){
	if(keyboard_check(vk_right)) freak.body_intensity = min(1, freak.body_intensity + intensity_rate);
	else if(keyboard_check(vk_left)) freak.body_intensity = max(0, freak.body_intensity - intensity_rate);
}
if(type == "CHANGE HEAD INTENSITY"){
	if(keyboard_check(vk_right)) freak.head_intensity = min(1, freak.head_intensity + intensity_rate);
	else if(keyboard_check(vk_left)) freak.head_intensity = max(0, freak.head_intensity - intensity_rate);
}

if(type == "CHANGE EAR INTENSITY"){
	if(keyboard_check(vk_right)) freak.ear_intensity = min(1, freak.ear_intensity + intensity_rate);
	else if(keyboard_check(vk_left)) freak.ear_intensity = max(0, freak.ear_intensity - intensity_rate);
}
if(type == "CHANGE TAIL INTENSITY") {
	if(keyboard_check(vk_right)) freak.tail_intensity = min(1, freak.tail_intensity + intensity_rate);
	else if(keyboard_check(vk_left)) freak.tail_intensity = max(0, freak.tail_intensity - intensity_rate);
}

if(keyboard_check_released(vk_up)){
	type = type_index[num];
	num++;
	if(num >= array_length(type_index)) num = 0;
}

