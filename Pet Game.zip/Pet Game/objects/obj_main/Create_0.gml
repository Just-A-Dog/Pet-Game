scr_init();
dir = "n";
dir_array_index = array_get_index(global.dir, dir);
intensity_rate = 0.01;
freak = instance_create_depth(floor(room_width/2), floor(room_height/2), 0, obj_freak_2,
{
	dir : dir,
	base_color : global.colors.BLUE,
	tertiary_color : global.colors.RED,
});
num = 4;
type_index = ["ROTATE", "CHANGE BODY INTENSITY", "CHANGE HEAD INTENSITY", "CHANGE EAR INTENSITY", "CHANGE TAIL INTENSITY"];
type = type_index[num];

//scr_app_cache_save();
/*

data = {
	base_color : global.colors.BLUE,
	tertiary_color : global.colors.RED,
	skeleton_type : global.base_skeleton,
	head_type : global.raccoon_head,
	chin_type : global.raccoon_chin,
	head_intensity : 0,
	left_eye_type : global.base_left_eye,
	right_eye_type : global.base_right_eye,
	left_eyebrow_type : global.base_left_eyebrow,
	right_eyebrow_type : global.base_right_eyebrow,
	left_ear_type : global.base_left_ear,
	right_ear_type : global.base_right_ear,
	nose_type : global.base_nose,
	mouth_type : global.base_mouth,
	mouth_intensity : 0,
	body_type : global.base_body,
	body_intensity : 0,
	right_arm_type : global.base_right_arm,
	left_arm_type : global.base_left_arm,
	arm_intensity : 0,
	left_leg_type : global.base_left_leg,
	right_leg_type : global.base_right_leg,
	leg_intensity : 0,
};

freak = scr_create_freak(data);

scr_app_cache_save();

