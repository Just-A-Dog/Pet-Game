//Pair the base and transformed outlines for all directions
location_color = make_color_rgb(128,128,255);

color_dict = {
	"0,0,0" : global.colors.BLACK,
	"128,128,128" : base_color
}

app_list = scr_body_part_init_3(
	global_type,
	transformed_type,
	scr_get_cache_key_2(transformed_type),
	color_dict);

sprite_num = 0;

if(app_list[array_get_index(global.dir,dir)] != -1)
	current_pixel_list = scr_current_point_list(app_list[array_get_index(global.dir,dir)][sprite_num], intensity); 

