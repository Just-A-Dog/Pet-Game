if(!invisible){
	scr_draw_sprite(leg_sprite[dir_i][sprite_num],x,y);
}