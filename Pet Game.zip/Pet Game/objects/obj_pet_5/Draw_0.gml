draw_set_color(c_white);
draw_set_alpha(1);

current_pixel_list = [];
cpli = 0;
for(i = 0; i < array_length(app_list); i++){
	medium_pixel_x = round(lerp(app_list[i][0], app_list[i][2], intensity));
	medium_pixel_y = round(lerp(app_list[i][1], app_list[i][3], intensity)); 
	//Check to see if there is a gap between pixels now. [Before and after.]
	//Add pixel in, colored exact middle between two pixels.
	//Keep running until it runs out of space between the two pixels.

	current_pixel_list[cpli] = [medium_pixel_x, medium_pixel_y, scr_intensify_colors(app_list[i][4], app_list[i][5], intensity)];

	//Is there a space greater than 1 between this pixel and the pixel beforehand? If so, we create some new pixels to take the place.
	if(i != 0){
		xdiff = current_pixel_list[cpli - 1][0] - current_pixel_list[cpli][0];
		ydiff = current_pixel_list[cpli - 1][1] - current_pixel_list[cpli][1];
		if(xdiff > 1 or xdiff < -1 or ydiff > 1 or ydiff < -1){
			cpli += scr_fill_in_pixel_gaps(xdiff, ydiff, cpli, current_pixel_list, medium_pixel_x, medium_pixel_y);
		}
	}

	//Last pixel in the list checks for gaps between itself and the first pixel.
	//Acts as if 0 index pixel is checking behind itself.
	if(i == array_length(app_list) - 1){
		xdiff = current_pixel_list[cpli][0] - current_pixel_list[0][0];
		ydiff = current_pixel_list[cpli][1] - current_pixel_list[0][1];
		if(i != 0 and (xdiff > 1 or xdiff < -1 or ydiff > 1 or ydiff < -1)){
			scr_fill_in_pixel_gaps(xdiff, ydiff, 0, current_pixel_list, medium_pixel_x, medium_pixel_y);
		}
	}
	cpli++;
}

scr_draw_and_fill_in_sprite(current_pixel_list,c_gray);
scr_draw_outline_2(current_pixel_list);

/*draw_set_color(c_blue);
draw_line(sym_line, 0, sym_line, room_height);
draw_point(33,43);*/

//game_end();
