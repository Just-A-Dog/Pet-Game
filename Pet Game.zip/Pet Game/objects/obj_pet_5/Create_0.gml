window_set_fullscreen(true);
gpu_set_texfilter(false);

//Creates a list of all of the black pixels.
/*bd_unordered_list_1 = scr_analyze_shape_2(spr_base_head); 
bd_unordered_list_2 = scr_analyze_shape_2(spr_animal_head);*/

//Gets all of the bordered pixels
bd_unordered_list_1 = scr_analyze_shape_3(spr_base_s_idle_head); 
bd_unordered_list_2 = scr_analyze_shape_3(spr_animal_head_2);

//Organizes the bordered pixels
bd_list_1 = scr_walkabout_2(bd_unordered_list_1, sprite_get_width(spr_base_s_idle_head), sprite_get_height(spr_base_s_idle_head));
bd_list_2 = scr_walkabout_2(bd_unordered_list_2, sprite_get_width(spr_animal_head), sprite_get_height(spr_animal_head));

//Pairs the points together to their closest neighbor
sym_line = sprite_get_width(spr_base_s_idle_head) / 2;
if(sym_line % 2 != 0) sym_line = ceil(sym_line);
show_debug_message(sym_line);
app_list = scr_pair_points_symmetrical(bd_list_1, bd_list_2, sym_line);
//app_list = scr_pair_points_2(bd_list_1, bd_list_2);

intensity = 1; //Goes from 0 -> 1, from one shape to another.
intensity_rate = 0.01;

current_pixel_list = [];