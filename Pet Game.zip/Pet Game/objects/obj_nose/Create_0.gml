base_nose_type = variable_struct_get(global.base_nose, dir);
nose_list = scr_convert_to_palette(base_nose_type, color_data);
x_orig = x;
y_orig = y;
