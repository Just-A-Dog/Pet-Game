if(!invisible){
	scr_draw_sprite(nose_list[0],x,y);
}