//Pair the base and transformed outlines for all directions
location_color = make_color_rgb(255,0,0);
color_dict = {
	"0,0,0" : global.colors.BLACK,
	"128,128,128" : base_color
}
app_list = scr_body_part_init_3(global_type, transformed_type, scr_get_cache_key_2(transformed_type), color_dict);
head_height = [];
for(i = 0; i < array_length(global.dir); i++){
	array_push(head_height, scr_get_width_and_height(app_list[i][0])[1]);
}

sprite_num = 0;

if(app_list[array_get_index(global.dir,dir)] != -1)
	current_pixel_list = scr_current_point_list(app_list[array_get_index(global.dir,dir)][sprite_num], intensity); 

skeleton_moved = false;
prev_y = y;

head_offset = 0;