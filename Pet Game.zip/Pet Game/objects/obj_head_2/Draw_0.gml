if(!invisible){
	scr_draw_and_fill_in_sprite_3(current_pixel_list,base_color,height - head_offset);
	scr_draw_outline_2(current_pixel_list,base_color,height - head_offset);
}