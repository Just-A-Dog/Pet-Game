if(!invisible){
	scr_draw_sprite(eye_list[dir_i][sprite],x,y);
}
