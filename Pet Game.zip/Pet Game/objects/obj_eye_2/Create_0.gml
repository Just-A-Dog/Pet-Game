prev_intensity = -1;
prev_dir = -1;
x_orig = x;
y_orig = y;
if (!variable_instance_exists(id, "invisible")) invisible = false;
if(!variable_instance_exists(id,"left")) left = false;
sprite = 0;

//Get eye color. Check tertiary color.
switch(tertiary_color){
	case(global.colors.WHITE):
	case(global.colors.LIGHTGRAY):
		le_color = global.colors.WHITE;
		e_color = global.colors.LIGHTGRAY;
		de_color = global.colors.DARKGRAY;
	break;
	case(global.colors.DARKGRAY):
	case(global.colors.BLACK):
		le_color = global.colors.LIGHTGRAY;
		e_color = global.colors.DARKGRAY;
		de_color = global.colors.BLACK;
	break;
	case(global.colors.PINK):
	case(global.colors.RED):
		le_color = global.colors.PINK;
		e_color = global.colors.RED;
		de_color = global.colors.MIDRED;
	break;
	case(global.colors.MIDRED):
	case(global.colors.DARKRED):
		le_color = global.colors.RED;
		e_color = global.colors.MIDRED;
		de_color = global.colors.DARKRED;
	break;
	case(global.colors.LIGHTORANGE):
	case(global.colors.ORANGE):
		le_color = global.colors.LIGHTORANGE;
		e_color = global.colors.ORANGE;
		de_color = global.colors.BROWN;
	break;
	case(global.colors.BROWN):
	case(global.colors.DARKBROWN):
		le_color = global.colors.ORANGE;
		e_color = global.colors.BROWN;
		de_color = global.colors.DARKBROWN;
	break;
	case(global.colors.LIGHTYELLOW):
	case(global.colors.YELLOW):
		le_color = global.colors.LIGHTYELLOW;
		e_color = global.colors.YELLOW;
		de_color = global.colors.GOLD;
	break;
	case(global.colors.GOLD):
	case(global.colors.DARKGOLD):
		le_color = global.colors.YELLOW;
		e_color = global.colors.GOLD;
		de_color = global.colors.DARKGOLD;
	break;
	case(global.colors.LIGHTGREEN):
	case(global.colors.GREEN):
		le_color = global.colors.LIGHTGREEN;
		e_color = global.colors.GREEN;
		de_color = global.colors.MIDGREEN;
	break;
	case(global.colors.MIDGREEN):
	case(global.colors.DARKGREEN):
		le_color = global.colors.GREEN;
		e_color = global.colors.MIDGREEN;
		de_color = global.colors.DARKGREEN;
	break;
	case(global.colors.LIGHTCYAN):
	case(global.colors.CYAN):
		le_color = global.colors.LIGHTCYAN;
		e_color = global.colors.CYAN;
		de_color = global.colors.MIDCYAN;
	break;
	case(global.colors.MIDCYAN):
	case(global.colors.DARKCYAN):
		le_color = global.colors.CYAN;
		e_color = global.colors.MIDCYAN;
		de_color = global.colors.DARKCYAN;
	break;
	case(global.colors.LIGHTBLUE):
	case(global.colors.BLUE):
		le_color = global.colors.LIGHTBLUE;
		e_color = global.colors.BLUE;
		de_color = global.colors.MIDBLUE;
	break;
	case(global.colors.MIDBLUE):
	case(global.colors.DARKBLUE):
		le_color = global.colors.BLUE;
		e_color = global.colors.MIDBLUE;
		de_color = global.colors.DARKBLUE;
	break;
	case(global.colors.LIGHTPURPLE):
	case(global.colors.PURPLE):
		le_color = global.colors.LIGHTPURPLE;
		e_color = global.colors.PURPLE;
		de_color = global.colors.MIDPURPLE;
	break;
	case(global.colors.MIDPURPLE):
	case(global.colors.DARKPURPLE):
		le_color = global.colors.PURPLE;
		e_color = global.colors.MIDPURPLE;
		de_color = global.colors.DARKPURPLE;
	break;
	default:
	show_debug_message("Not a color??");
	show_debug_message(tertiary_color);
}
current_eye_type = variable_struct_get(eye_type, dir);
color_data = {};

variable_struct_set(color_data, scr_color_to_string(0,0,0), global.colors.BLACK);
variable_struct_set(color_data, scr_color_to_string(191,191,191), le_color);
variable_struct_set(color_data, scr_color_to_string(128,128,128), e_color);
variable_struct_set(color_data, scr_color_to_string(64,64,64), de_color);

eye_list = [];
for(i = 0; i < array_length(global.dir); i++){
	current_sprite = variable_struct_get(eye_type, global.dir[i]);
	if(current_sprite == -1) array_push(eye_list, -1);
	else array_push(eye_list,scr_convert_to_palette(current_sprite, color_data)); 
}

dir_i = array_get_index(global.dir, dir);