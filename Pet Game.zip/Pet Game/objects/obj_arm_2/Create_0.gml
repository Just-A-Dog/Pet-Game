//Arm is gonna have a sprite
//And a color for location
invisible = false;
prev_dir = -1;
prev_intensity = 0;
sprite_num = 0;
if(!variable_instance_get(self, "left")) left = false;

//Convert each sprite to appropriate colors:
color_data = { "128,128,128" : base_color};
arm_sprite = [];
for(i = 0; i < array_length(global.dir); i++){
	current_sprite = variable_struct_get(sprite_struct, global.dir[i]);
	if(current_sprite != -1) array_push(arm_sprite, scr_convert_to_palette(current_sprite,color_data));
}
