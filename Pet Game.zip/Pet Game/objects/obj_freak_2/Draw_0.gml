draw_text(10,30,head_intensity);
draw_text(10,50,body_intensity);