x = floor(room_width / 2);
y = floor(room_height / 2);
prev_dir = dir;
head_intensity = 0;
body_intensity = 0;
ear_intensity = 0;
tail_intensity = 0;
prev_head_intensity = head_intensity;
prev_body_intensity = body_intensity;
prev_ear_intensity = ear_intensity;
prev_tail_intensity = tail_intensity;

head_skeleton = instance_create_depth(x,y,-2,obj_head_skeleton,
{
	freak_id : id,
	dir : dir,
	transformed_type : global.raccoon_head_skeleton,
	base_type : global.base_head_skeleton,
});

body_skeleton = instance_create_depth(x,y,-2,obj_body_skeleton,
{
	freak_id : id,
	transformed_type : global.circle_body_skeleton,
	dir : dir,
});

body = instance_create_depth(x,y,depth,obj_body_2,
{
	freak_id : id,
	dir : dir,
	transformed_type : global.circle_body,
	global_type : global.base_body,
	base_color : base_color,
	skeleton : body_skeleton,
});

head = instance_create_depth(x,y,-1,obj_head_2,
{
	freak_id : id,
	dir : dir,
	transformed_type : global.raccoon_head,
	global_type : global.base_head,
	base_color : base_color,
	skeleton : head_skeleton,
});

left_arm = instance_create_depth(x,y,depth,obj_arm_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	skeleton : body_skeleton,
	sprite_struct : global.base_left_arm,
	left : true,
	location_color : make_color_rgb(255,128,255),
});

right_arm = instance_create_depth(x,y,depth,obj_arm_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	skeleton : body_skeleton,
	sprite_struct : global.base_right_arm,
	location_color : make_color_rgb(0,128,255),
});

left_leg = instance_create_depth(x,y,-1,obj_leg_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	skeleton : body_skeleton,
	sprite_struct : global.base_left_leg,
	location_color : make_color_rgb(0,128,0),
	left : true
});

right_leg = instance_create_depth(x,y,-1,obj_leg_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	skeleton : body_skeleton,
	sprite_struct : global.base_right_leg,
	location_color : make_color_rgb(128,128,255),
});

left_eye = instance_create_depth(x,y,-2, obj_eye_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	tertiary_color : tertiary_color,
	eye_type : global.base_left_eye,
	location_color : make_color_rgb(0,255,0),
	left : true
});

right_eye = instance_create_depth(x,y,-2,obj_eye_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	tertiary_color : tertiary_color,
	eye_type : global.base_right_eye,
	location_color : make_color_rgb(0,255,255),
});

left_eyebrow = instance_create_depth(x,y,-2,obj_eyebrow_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	eyebrow_type : global.base_left_eyebrow
});

right_eyebrow = instance_create_depth(x,y,-2,obj_eyebrow_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	eyebrow_type : global.base_right_eyebrow,
});

snout = instance_create_depth(x,y,-3,obj_snout,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	global_type : global.base_snout,
	transformed_type : global.raccoon_snout
});

nose = instance_create_depth(x,y,-4,obj_nose_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	global_type : global.base_nose,
	transformed_type : global.raccoon_nose
});

mouth = instance_create_depth(x,y,-4, obj_mouth_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	global_type : global.base_mouth,
	transformed_type : global.raccoon_mouth
});

right_ear = instance_create_depth(x,y,-2,obj_ear_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	global_type : global.base_right_ear,
	transformed_type : global.raccoon_right_ear,
	left : false,
});

left_ear = instance_create_depth(x,y,-2,obj_ear_2,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	global_type : global.base_left_ear,
	transformed_type : global.raccoon_left_ear,
	left : true,
});

tail = instance_create_depth(x,y,0,obj_tail,
{
	freak_id : id,
	dir : dir,
	base_color : base_color,
	global_type : global.base_tail,
	transformed_type : global.raccoon_tail
});
scr_update_freak();