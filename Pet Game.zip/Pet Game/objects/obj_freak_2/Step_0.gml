if(dir != prev_dir 
or prev_head_intensity != head_intensity 
or prev_body_intensity != body_intensity
or prev_ear_intensity != ear_intensity
or prev_tail_intensity != tail_intensity){
	prev_dir = dir;
	prev_body_intensity = body_intensity;
	prev_head_intensity = head_intensity;
	prev_ear_intensity = ear_intensity;
	prev_tail_intensity = tail_intensity;
	scr_update_freak();
}