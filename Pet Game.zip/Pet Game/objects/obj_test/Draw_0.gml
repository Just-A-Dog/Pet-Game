draw_set_color(c_white);
gpu_set_texfilter(false);
draw_sprite(spr_weird_shape,0,75,0);