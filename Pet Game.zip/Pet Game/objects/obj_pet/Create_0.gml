/// @description Initialize pet head

// Number of points around the head.
// More points = smoother shapes.
point_count = 60;

// Size of the head
head_width = 100;
head_height = 100;

// -------------------------------------------------
// DEBUG GROWTH SLIDER
// -------------------------------------------------

// 0 = triangle
// 0.5 = oval
// 1 = square
growth = 0.5;


// -------------------------------------------------
// SHAPE ARRAYS
// -------------------------------------------------

oval_x = [];
oval_y = [];

square_x = [];
square_y = [];

triangle_x = [];
triangle_y = [];

current_x = array_create(point_count, 0);
current_y = array_create(point_count, 0);


// -------------------------------------------------
// OVAL
// -------------------------------------------------

for (var i = 0; i < point_count; i++)
{
    var angle = (i / point_count) * 360;

    oval_x[i] = lengthdir_x(head_width, angle);
    oval_y[i] = lengthdir_y(head_height, angle);
}


// -------------------------------------------------
// SQUARE
// -------------------------------------------------

var half_w = head_width;
var half_h = head_height;

var square_side = point_count / 4;

for (var i = 0; i < point_count; i++)
{
    var side = floor(i / square_side);
    var t = (i mod square_side) / square_side;

    switch (side)
    {
        case 0:
            square_x[i] = lerp(-half_w, half_w, t);
            square_y[i] = -half_h;
        break;

        case 1:
            square_x[i] = half_w;
            square_y[i] = lerp(-half_h, half_h, t);
        break;

        case 2:
            square_x[i] = lerp(half_w, -half_w, t);
            square_y[i] = half_h;
        break;

        case 3:
            square_x[i] = -half_w;
            square_y[i] = lerp(half_h, -half_h, t);
        break;
    }
}


// -------------------------------------------------
// TRIANGLE
// -------------------------------------------------

// Triangle bounding box:
//
//             (0,-100)
//                ▲
//               / \
//              /   \
//             /     \
// (-100,100) ──────── (100,100)

var tri_top_x = 0;
var tri_top_y = -head_height;

var tri_left_x = -head_width;
var tri_left_y = head_height;

var tri_right_x = head_width;
var tri_right_y = head_height;


// Points per triangle edge
var triangle_side = point_count / 3;

for (var i = 0; i < point_count; i++)
{
    var side = floor(i / triangle_side);
    var t = (i mod triangle_side) / triangle_side;

    switch (side)
    {
        case 0:
            // Top → Right
            triangle_x[i] = lerp(tri_top_x, tri_right_x, t);
            triangle_y[i] = lerp(tri_top_y, tri_right_y, t);
        break;

        case 1:
            // Right → Left
            triangle_x[i] = lerp(tri_right_x, tri_left_x, t);
            triangle_y[i] = lerp(tri_right_y, tri_left_y, t);
        break;

        case 2:
            // Left → Top
            triangle_x[i] = lerp(tri_left_x, tri_top_x, t);
            triangle_y[i] = lerp(tri_left_y, tri_top_y, t);
        break;
    }
}