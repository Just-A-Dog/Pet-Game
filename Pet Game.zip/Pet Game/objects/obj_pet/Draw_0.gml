draw_primitive_begin(pr_trianglefan);

draw_vertex(x, y);

for (var i = 0; i < point_count; i++)
{
    draw_vertex(
        x + current_x[i],
        y + current_y[i]
    );
}

draw_vertex(
    x + current_x[0],
    y + current_y[0]
);

draw_primitive_end();