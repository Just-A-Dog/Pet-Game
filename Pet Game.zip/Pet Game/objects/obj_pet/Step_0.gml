// DEBUG CONTROL

if (keyboard_check(vk_right))
{
    growth += 0.01;
}

if (keyboard_check(vk_left))
{
    growth -= 0.01;
}

growth = clamp(growth, 0, 1);


// -------------------------------------------------
// DETERMINE TARGET SHAPE
// -------------------------------------------------

for (var i = 0; i < point_count; i++)
{
    var target_x;
    var target_y;

    if (growth < 0.5)
    {
        // Triangle → Oval

        var amount = growth / 0.5;

        target_x = lerp(
            triangle_x[i],
            oval_x[i],
            amount
        );

        target_y = lerp(
            triangle_y[i],
            oval_y[i],
            amount
        );
    }
    else
    {
        // Oval → Square

        var amount = (growth - 0.5) / 0.5;

        target_x = lerp(
            oval_x[i],
            square_x[i],
            amount
        );

        target_y = lerp(
            oval_y[i],
            square_y[i],
            amount
        );
    }


    // Slowly follow the target

    current_x[i] = lerp(
        current_x[i],
        target_x,
        0.05
    );

    current_y[i] = lerp(
        current_y[i],
        target_y,
        0.05
    );
}