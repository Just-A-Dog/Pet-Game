// -------------------------------------------------
// PET HEAD
// -------------------------------------------------

point_count = 120;

head_width = 100;
head_height = 100;


// 0 = triangle
// 0.5 = oval
// 1 = square

growth = 0.5;


// -------------------------------------------------
// ARRAYS
// -------------------------------------------------

oval_x = [];
oval_y = [];

triangle_x = [];
triangle_y = [];

square_x = [];
square_y = [];

current_x = array_create(point_count, 0);
current_y = array_create(point_count, 0);


// -------------------------------------------------
// GENERATE SHAPES
// -------------------------------------------------

for (var i = 0; i < point_count; i++)
{
    var angle = (i / point_count) * 360;


    // =================================================
    // OVAL
    // =================================================

    oval_x[i] = lengthdir_x(head_width, angle);
    oval_y[i] = lengthdir_y(head_height, angle);


    // =================================================
    // SQUARE
    // =================================================

    var dir_x = dcos(angle);
    var dir_y = dsin(angle);

    var square_radius;

    if (abs(dir_x) > abs(dir_y))
    {
        square_radius = head_width / abs(dir_x);
    }
    else
    {
        square_radius = head_height / abs(dir_y);
    }

    square_x[i] = dir_x * square_radius;
    square_y[i] = dir_y * square_radius;


    // =================================================
    // TRIANGLE
    // =================================================

    // Triangle vertices

    var top_x = 0;
    var top_y = -head_height;

    var left_x = -head_width;
    var left_y = head_height;

    var right_x = head_width;
    var right_y = head_height;


    // Determine which edge the ray hits.

    var edge_x1;
    var edge_y1;
    var edge_x2;
    var edge_y2;


    if (angle >= 330 || angle < 30)
    {
        // Top → Right

        edge_x1 = top_x;
        edge_y1 = top_y;

        edge_x2 = right_x;
        edge_y2 = right_y;
    }
    else if (angle < 150)
    {
        // Right → Left

        edge_x1 = right_x;
        edge_y1 = right_y;

        edge_x2 = left_x;
        edge_y2 = left_y;
    }
    else if (angle < 270)
    {
        // Left → Top

        edge_x1 = left_x;
        edge_y1 = left_y;

        edge_x2 = top_x;
        edge_y2 = top_y;
    }
    else
    {
        // Top → Right

        edge_x1 = top_x;
        edge_y1 = top_y;

        edge_x2 = right_x;
        edge_y2 = right_y;
    }


    // -------------------------------------------------
    // INTERSECTION
    // -------------------------------------------------

    var edge_dx = edge_x2 - edge_x1;
    var edge_dy = edge_y2 - edge_y1;

    var denominator =
        dir_x * edge_dy -
        dir_y * edge_dx;


    if (abs(denominator) > 0.00001)
    {
        var ray_distance =
            (edge_x1 * edge_dy -
             edge_y1 * edge_dx) /
            denominator;

        triangle_x[i] = dir_x * ray_distance;
        triangle_y[i] = dir_y * ray_distance;
    }
    else
    {
        // Fallback
        triangle_x[i] = dir_x * head_width;
        triangle_y[i] = dir_y * head_height;
    }
}