surf = surface_create(
    sprite_get_width(spr_weird_shape),
    sprite_get_height(spr_weird_shape)
);

surface_set_target(surf);

draw_clear_alpha(c_black, 0);

// Draw the sprite onto the surface
draw_sprite(spr_weird_shape, 0, 0, 0);

surface_reset_target();

// -------------------------------------------------
// Create pixel grid
// -------------------------------------------------

var sprite_w = sprite_get_width(spr_weird_shape);
var sprite_h = sprite_get_height(spr_weird_shape);

pixels = array_create(sprite_w);

for (var px = 0; px < sprite_w; px++)
{
    pixels[px] = array_create(sprite_h, false);
}

var pixel_buffer = buffer_create(
    sprite_w * sprite_h * 4,
    buffer_fixed,
    1
);

buffer_get_surface(
    pixel_buffer,
    surf,
    0
);

for (var py = 0; py < sprite_h; py++)
{
    for (var px = 0; px < sprite_w; px++)
    {
        var buffer_position =
            ((py * sprite_w) + px) * 4;

        var red = buffer_peek(
            pixel_buffer,
            buffer_position,
            buffer_u8
        );

        var green = buffer_peek(
            pixel_buffer,
            buffer_position + 1,
            buffer_u8
        );

        var blue = buffer_peek(
            pixel_buffer,
            buffer_position + 2,
            buffer_u8
        );

        var alpha = buffer_peek(
            pixel_buffer,
            buffer_position + 3,
            buffer_u8
        );

        pixels[px][py] = (alpha > 0);
    }
}

buffer_delete(pixel_buffer);

	//
	// Find boundary edges
	//

	boundary_edges = [];

	for (var py = 0; py < sprite_h; py++)
	{
	    for (var px = 0; px < sprite_w; px++)
	    {
	        if (!pixels[px][py])
	            continue;


	        // -----------------------------------------
	        // TOP
	        // -----------------------------------------

	        if (py == 0 || !pixels[px][py - 1])
	        {
	            array_push(boundary_edges, {
	                x1: px,
	                y1: py,

	                x2: px + 1,
	                y2: py
	            });
	        }


	        // -----------------------------------------
	        // RIGHT
	        // -----------------------------------------

	        if (px == sprite_w - 1 || !pixels[px + 1][py])
	        {
	            array_push(boundary_edges, {
	                x1: px + 1,
	                y1: py,

	                x2: px + 1,
	                y2: py + 1
	            });
	        }


	        // -----------------------------------------
	        // BOTTOM
	        // -----------------------------------------

	        if (py == sprite_h - 1 || !pixels[px][py + 1])
	        {
	            array_push(boundary_edges, {
	                x1: px + 1,
	                y1: py + 1,

	                x2: px,
	                y2: py + 1
	            });
	        }


	        // -----------------------------------------
	        // LEFT
	        // -----------------------------------------

	        if (px == 0 || !pixels[px - 1][py])
	        {
	            array_push(boundary_edges, {
	                x1: px,
	                y1: py + 1,

	                x2: px,
	                y2: py
	            });
	        }
	    }
	}

// -------------------------------------------------
// Connect boundary edges into an ordered loop
// -------------------------------------------------

polygon_points = [];

var edge_count = array_length(boundary_edges);

if (edge_count > 0)
{
    var used_edges = array_create(edge_count, false);

    // Start with the first edge
    var current_edge = 0;

    used_edges[current_edge] = true;

    var start_px = boundary_edges[current_edge].x1;
    var start_py = boundary_edges[current_edge].y1;

    var current_px = boundary_edges[current_edge].x2;
    var current_py = boundary_edges[current_edge].y2;


    // Add starting point
    array_push(polygon_points, {
        px: start_px,
        py: start_py
    });


    while (true)
    {
        // Add the current point
        array_push(polygon_points, {
            px: current_px,
            py: current_py
        });


        // Have we returned to the beginning?
        if (current_px == start_px &&
            current_py == start_py)
        {
            break;
        }


        var found_next = false;


        // Find the next edge
        for (var i = 0; i < edge_count; i++)
        {
            if (used_edges[i])
                continue;


            var edge = boundary_edges[i];


            if (edge.x1 == current_px &&
                edge.y1 == current_py)
            {
                used_edges[i] = true;

                current_px = edge.x2;
                current_py = edge.y2;

                found_next = true;

                break;
            }
        }


        // Something went wrong
        if (!found_next)
        {
            show_debug_message(
                "ERROR: Could not connect polygon boundary."
            );

            break;
        }
    }
}