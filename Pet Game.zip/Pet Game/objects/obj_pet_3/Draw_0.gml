draw_set_color(c_red);

draw_rectangle(
    0,
    0,
    480,
    270,
    false
);

draw_set_color(c_white);

var point_count = array_length(polygon_points);

for (var i = 0; i < point_count; i++)
{
    var next_i = (i + 1) mod point_count;

    draw_line(
        polygon_points[i].px,
        polygon_points[i].py,
        polygon_points[next_i].px,
        polygon_points[next_i].py
    );
}