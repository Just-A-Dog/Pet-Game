if(!invisible) {
	scr_draw_sprite(ear_list[0],x,y);
}
