current_ear_type = variable_struct_get(ear_type, dir);
ear_list = scr_convert_to_palette(current_ear_type, color_data);
x_orig = x;
y_orig = y;