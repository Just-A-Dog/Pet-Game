surf = surface_create(
    sprite_get_width(spr_weird_shape),
    sprite_get_height(spr_weird_shape)
);

surface_set_target(surf);

draw_clear_alpha(c_black, 0);

// Draw the sprite onto the surface
draw_sprite(spr_weird_shape, 0, 0, 0);

surface_reset_target();

// -------------------------------------------------
// Create pixel grid
// -------------------------------------------------

var sprite_w = sprite_get_width(spr_weird_shape);
var sprite_h = sprite_get_height(spr_weird_shape);

pixels = array_create(sprite_w);

for (var px = 0; px < sprite_w; px++)
{
    pixels[px] = array_create(sprite_h, false);
}

var pixel_buffer = buffer_create(
    sprite_w * sprite_h * 4,
    buffer_fixed,
    1
);

buffer_get_surface(
    pixel_buffer,
    surf,
    0
);

for (var py = 0; py < sprite_h; py++)
{
    for (var px = 0; px < sprite_w; px++)
    {
        var buffer_position =
            ((py * sprite_w) + px) * 4;

        var alpha = buffer_peek(
            pixel_buffer,
            buffer_position + 3,
            buffer_u8
        );

        pixels[px][py] = (alpha > 0);
    }
}

buffer_delete(pixel_buffer);

