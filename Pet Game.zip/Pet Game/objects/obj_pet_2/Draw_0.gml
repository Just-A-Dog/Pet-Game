draw_set_color(c_red);
draw_rectangle(0, 0, 480, 270, false);

draw_set_color(c_white);

var sprite_w = sprite_get_width(spr_weird_shape);
var sprite_h = sprite_get_height(spr_weird_shape);

//Draws a square for each pixel in 
_ = 0
for (var py = 0; py < sprite_h; py++)
{
    for (var px = 0; px < sprite_w; px++)
    {
        if (pixels[px][py])
        {
            draw_rectangle(
                px,
                py,
                px + 1,
                py + 1,
                false
            );
        }
    }
	_ = py
}
scr_draw_pixel_line(0,_,100,_);