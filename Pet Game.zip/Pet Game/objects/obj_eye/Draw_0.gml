if(!invisible){
	if(eye_list[dir_i] != -1){
		scr_draw_sprite(eye_list[dir_i][sprite],x,y);
	}
	if(prev_dir != dir) dir_i = array_get_index(global.dir, dir);
}
