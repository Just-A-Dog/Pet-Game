if(dir != prev_dir){
	//Adjust x and y co-ordinates of eyes
	scr_find_xydepth_eye(eye_type, eyebrow_type); //TODO: Edit the color_coords to match that of the current skeleton with intensity, not just base or transformed.
	x = eye_x;
	y = eye_y;
	if(left){
		freak_id.head.left_eyebrow.x = eyebrow_x;
		freak_id.head.left_eyebrow.y = eyebrow_y;
		freak_id.head.left_eyebrow.invisible = eyebrow_invisible;
	}
	else{
		freak_id.head.right_eyebrow.x = eyebrow_x;
		freak_id.head.right_eyebrow.y = eyebrow_y;
		freak_id.head.right_eyebrow.invisible = eyebrow_invisible;
	}
	prev_dir = dir;
}