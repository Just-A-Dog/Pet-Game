current_right_arm_type = variable_struct_get(right_arm_type, dir);
current_left_arm_type = variable_struct_get(left_arm_type, dir);

app_right_arm_list = scr_body_part_init_helper(spr_base_s_idle_arm, current_right_arm_type, false);
app_left_arm_list = scr_body_part_init_helper(spr_base_s_idle_arm_r, current_left_arm_type, false);

x_orig = x;
y_orig = y;
