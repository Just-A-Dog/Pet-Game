if(!invisible){
	scr_draw_sprite(eyebrow_list[dir_i][sprite],x,y);	
}
