prev_intensity = -1;
prev_dir = -1;
x_orig = x;
y_orig = y;
if (!variable_instance_exists(id, "invisible")) invisible = false;
sprite = 0;

color_data = {};

variable_struct_set(color_data, scr_color_to_string(0,0,0), global.colors.BLACK);

eyebrow_list = [];
for(i = 0; i < array_length(global.dir); i++){
	current_sprite = variable_struct_get(eyebrow_type, global.dir[i]);
	if(current_sprite == -1) array_push(eyebrow_list, -1);
	else array_push(eyebrow_list,scr_convert_to_palette(current_sprite, color_data)); 
}

dir_i = array_get_index(global.dir, dir);