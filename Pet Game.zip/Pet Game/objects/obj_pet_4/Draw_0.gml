draw_set_color(c_white);
draw_set_alpha(1);
for(i = 0; i < array_length(associated_pixels_list); i++){
	medium_pixel_x = lerp(associated_pixels_list[i][0], associated_pixels_list[i][2], intensity);
	medium_pixel_y = lerp(associated_pixels_list[i][1], associated_pixels_list[i][3], intensity);
	current_pixel_list[i] = [medium_pixel_x, medium_pixel_y];	
}


//scr_draw_outline(current_pixel_list);
for(i = 0; i < array_length(associated_pixels_list); i++){
	
}

draw_set_color(c_red);
draw_set_alpha(0.5);
for(i = 0; i < array_length(corner_pixels_list_2); i++){
	draw_rectangle(corner_pixels_list_2[i][0] - 1, corner_pixels_list_2[i][1] - 1, corner_pixels_list_2[i][0], corner_pixels_list_2[i][1],0);
}
/*
//Draws the outline of the current pixels.
for(i = 0; i < array_length(current_pixel_list); i++){
	if(i != array_length(current_pixel_list) - 1){
		draw_line(current_pixel_list[i][0], current_pixel_list[i][1], current_pixel_list[i+1][0], current_pixel_list[i+1][1]);
	}
	else draw_line(current_pixel_list[i][0], current_pixel_list[i][1], current_pixel_list[0][0], current_pixel_list[0][1]);
}

/*