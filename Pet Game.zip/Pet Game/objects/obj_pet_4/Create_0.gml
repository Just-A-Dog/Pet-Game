window_set_fullscreen(true);
gpu_set_texfilter(false);

//Creates a list of the pixels at each available turn.
//Using this list, you can make the exact image by going from 0->1, 1->0.
//Pixels are formatted as [[x, y], [x, y]... etc. etc.]
corner_pixels_list_1 = scr_analyze_shape(spr_base_s_idle_head); 
corner_pixels_list_2 = scr_analyze_shape(spr_animal_head);
show_debug_message(corner_pixels_list_1);
show_debug_message(corner_pixels_list_2);

//This returns a list of the associated pixels.
//It is formatted [[x1, y1, x2, y2], [x1, y1, x2, y2]... etc. etc.]
temp = [];
array_copy(temp, 0, corner_pixels_list_2, 0, array_length(corner_pixels_list_2));
associated_pixels_list = scr_pair_points(corner_pixels_list_1, temp);

for(i = 0; i < array_length(associated_pixels_list); i++){
	show_debug_message(associated_pixels_list[i]);
	show_debug_message(point_distance(associated_pixels_list[i][0],associated_pixels_list[i][1],associated_pixels_list[i][2],associated_pixels_list[i][3]));
	show_debug_message("====");
}

intensity = 0; //Goes from 0 -> 1, from one shape to another.
intensity_rate = 0.01;

current_pixel_list = [];