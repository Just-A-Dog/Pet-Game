if(keyboard_check(vk_left)){
	intensity -= intensity_rate;
}
if(keyboard_check(vk_right)){
	intensity += intensity_rate;
}
intensity = clamp(intensity, 0, 1 + intensity_rate);