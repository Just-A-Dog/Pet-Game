if(!variable_instance_exists(id, "left")) left = true;
cache_key = scr_get_cache_key(global_arm_type, arm_type);
app_arm_list = scr_body_part_init(global_arm_type, arm_type, cache_key);