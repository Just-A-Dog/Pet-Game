if(scr_check_change_sprite(app_arm_list)){
	if(left){
		scr_find_xydepth_left_arm(arm_type);
		depth = left_arm_depth;
		x = left_arm_x;
		y = left_arm_y;
	}
	else{
		scr_find_xydepth_right_arm(arm_type);
		depth = right_arm_depth;
		x = right_arm_x;
		y = right_arm_y;
	}
}