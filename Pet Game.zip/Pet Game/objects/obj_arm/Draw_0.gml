if(!invisible){
	scr_draw_and_fill_in_sprite(current_pixel_list, base_color);
	scr_draw_outline_2(current_pixel_list, base_color);
}
