if(dir != prev_dir){
	scr_find_xydepth_mouth(base_mouth_type);
	depth = mouth_depth;
	x = mouth_x;
	y = mouth_y;
	prev_dir = dir;
}