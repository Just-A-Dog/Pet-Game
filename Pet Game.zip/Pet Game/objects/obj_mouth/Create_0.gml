prev_intensity = -1;
prev_dir = dir;
x_orig = x;
y_orig = y;
if (!variable_instance_exists(id, "invisible")) {
    invisible = false;
}
sprite = 0;

cache_key = scr_get_cache_key(base_mouth_type,transformed_mouth_type); 
//app_mouth_list = scr_body_part_init(base_mouth_type,transformed_mouth_type, cache_key);

app_mouth_list = [];
for(i = 0; i < array_length(global.dir); i++){
	current_sprite = variable_struct_get(transformed_mouth_type, global.dir[i]);
	if(current_sprite == -1) array_push(app_mouth_list, -1);
	else array_push(app_mouth_list,scr_convert_to_palette(current_sprite, color_data)); 
}

dir_i = array_get_index(global.dir, dir);