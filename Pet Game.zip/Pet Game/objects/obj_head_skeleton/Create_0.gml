//Take the base sprite and find each of the points.
//Merge it with the transformed skeleton [should be very easy, just each color to each color]
invisible = true;
intensity = 0;
prev_intensity = -1;
prev_dir = dir;
dir_i = array_get_index(global.dir, dir);
location_color = make_color_rgb(255,0,0);

app_list = [];
for(i = 0; i < array_length(global.dir); i++){
	if(variable_struct_get(base_type, global.dir[i]) != -1){
		array_push(app_list, scr_skeleton_match(variable_struct_get(base_type,global.dir[i]), 
								  variable_struct_get(transformed_type,global.dir[i])));
	}
}
prev_x = x;
prev_y = y;
skeleton_moved = false;