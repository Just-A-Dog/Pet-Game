if(!invisible){
	for(i=0; i < array_length(current_list); i++){
		draw_set_color(current_list[i][2]);
		draw_point(x + current_list[i][0], y + current_list[i][1]);
	}
}

draw_text(10,50,intensity);