if(!invisible){
	scr_draw_sprite(eyebrow_list[sprite],x,y);
}