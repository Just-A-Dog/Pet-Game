current_eyebrow_type = variable_struct_get(eyebrow_type, dir);
eyebrow_list = scr_convert_to_palette(current_eyebrow_type, color_data);

sprite = 0;
prev_intensity = -1;
prev_dir = dir;
x_orig = x;
y_orig = y;

if (!variable_instance_exists(id, "invisible")) {
    invisible = false;
}
