dir = "s";
freak_id = id;

//Adds every skeleton to color_coords.
color_coords = [];
for(i = 0; i < array_length(global.dir); i++){
	array_push(color_coords, scr_skeleton_analyzer(variable_struct_get(global.base_skeleton, global.dir[i])));
}

scr_find_xydepth_head(data.head_type);
head = instance_create_depth(head_x,head_y,0,obj_head,
{
	base_color : data.base_color,
	tertiary_color : data.tertiary_color,
	head_type : data.head_type,
	intensity : data.head_intensity,
	left_eye_type : data.left_eye_type,
	right_eye_type : data.right_eye_type,
	left_eyebrow_type: data.left_eyebrow_type,
	right_eyebrow_type: data.right_eyebrow_type,
	nose_type :data.nose_type,
	mouth_type : data.mouth_type,
	mouth_intensity : data.mouth_intensity,
	chin_type : data.chin_type,
	left_ear_type : data.left_ear_type,
	right_ear_type : data.right_ear_type,
	dir : dir,
	color_coords : color_coords,
	global_head_type : global.base_head,
	freak_id : freak_id
});

body_type = data.body_type; //Unpacked for find xydepth
scr_find_xydepth_body();
body = instance_create_depth(body_x,body_y,0,obj_body,
{
	base_color : data.base_color,
	body_type : data.body_type,
	intensity : data.body_intensity,
	right_arm_type : data.right_arm_type,
	left_arm_type : data.left_arm_type,
	arm_intensity : data.arm_intensity,
	left_leg_type : data.left_leg_type,
	right_leg_type : data.right_leg_type,
	leg_intensity : data.leg_intensity,
	dir : dir,
	color_coords : color_coords,
	freak_id : freak_id,
});

stop_idle = false;
anim_start = false;