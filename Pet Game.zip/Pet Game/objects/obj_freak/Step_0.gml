/*if(!stop_idle){
	scr_anim_blink(head.l_eye, head.r_eye);
	scr_anim_idle();
}