if(scr_check_change_sprite(app_head_list)){
	scr_find_xydepth_head();
	x = head_x;
	y = head_y;
	//depth = head_depth;
}