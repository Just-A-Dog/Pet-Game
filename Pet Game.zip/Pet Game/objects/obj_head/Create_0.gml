cache_key = scr_get_cache_key(global_head_type, head_type);
app_head_list = scr_body_part_init(global_head_type, head_type, cache_key);

color_data = {};
variable_struct_set(color_data, scr_color_to_string(0, 0, 0), global.colors.BLACK);
variable_struct_set(color_data, scr_color_to_string(252,252,252), global.colors.WHITE);

//CHIN SPAWN
base_chin_type = global.base_chin;
scr_find_xydepth_chin(chin_type);
chin = instance_create_depth(chin_x, chin_y, 0, obj_chin,
{
	tertiary_color : tertiary_color,
	base_color : base_color,
	color_data : color_data,
	chin_type : chin_type,
	intensity : intensity,
	dir : dir,
	mirrored : false,
	freak_id : freak_id,
	base_chin_type : base_chin_type,
	color_coords : color_coords,
});

left = true;
eyebrow_type = left_eyebrow_type;
scr_find_xydepth_eye(left_eye_type, left_eyebrow_type);
left_eye = instance_create_depth(eye_x, eye_y, eye_depth, obj_eye,
{
	tertiary_color : tertiary_color,
	eye_type : left_eye_type,
	color_data : color_data,
	color_coords : color_coords,
	dir : dir,
	freak_id : freak_id,
	eyebrow_type : eyebrow_type,
	left : true,
});

variable_struct_set(color_data, scr_color_to_string(128,128,128), base_color);

left_eyebrow = instance_create_depth(eyebrow_x, eyebrow_y, eyebrow_depth, obj_eyebrow,{
	color_data : color_data,
	color_coords : color_coords,
	eyebrow_type : left_eyebrow_type,
	invisible : eyebrow_invisible,
	dir : dir,
	left : true,
});


left = false;
eyebrow_type = right_eyebrow_type;
scr_find_xydepth_eye(right_eye_type, right_eyebrow_type);
right_eye = instance_create_depth(eye_x,eye_y,eye_depth, obj_eye,
{
	tertiary_color : tertiary_color,
	color_coords : color_coords,
	eye_type : right_eye_type,
	color_data : color_data,
	dir : dir,
	eyebrow_type : eyebrow_type,
	freak_id : freak_id,
	left : false,
});

right_eyebrow = instance_create_depth(eyebrow_x, eyebrow_y, eyebrow_depth, obj_eyebrow,{
	color_data : color_data,
	color_coords : color_coords,
	eyebrow_type : right_eyebrow_type,
	invisible : eyebrow_invisible,
	dir : dir,
	left : false,
});

variable_struct_set(color_data, scr_color_to_string(128,128,128), base_color);

//Mouth, Blue: Top Middle

scr_find_xydepth_mouth(mouth_type);
mouth = instance_create_depth(mouth_x, mouth_y, mouth_depth, obj_mouth,
{
	color_data : color_data,
	transformed_mouth_type : mouth_type,
	base_mouth_type : global.base_mouth,
	dir : dir,
	intensity : mouth_intensity,
	color_coords : color_coords,
	freak_id: freak_id,
});


/*
//Nose, Yellow: Bottom Middle
if(variable_struct_exists(color_coords, "255,255,0") or variable_struct_exists(color_coords, "255,128,128")){
	nose_sprite = variable_struct_get(nose_type, dir);
	w = sprite_get_width(nose_sprite);
	h = sprite_get_height(nose_sprite);

	if(variable_struct_exists(color_coords, "255,255,0")) color = "255,255,0";
	else color = "255,128,128";
	color = variable_struct_get(color_coords, color);
	nose_xpos = x + (color[0] - floor(w/2));
	nose_ypos = y + color[1] - h + 1;

	nose = instance_create_depth(nose_xpos, nose_ypos, -1, obj_nose,
	{
		color_data : color_data,
		nose_type : nose_type,
		dir : dir,
	});
}


//Ears, Red + Orange. Red: Bottom Right, Orange: Bottom Left.
if(variable_struct_exists(color_coords, "255,0,0")){
	ear_sprite = variable_struct_get(left_ear_type,dir);
	w = sprite_get_width(ear_sprite);
	h = sprite_get_height(ear_sprite);
	color = variable_struct_get(color_coords, "255,0,0");
	l_ear_xpos = x + (color[0] - w) + 1;
	ear_ypos = y + (color[1] - h);
	l_ear = instance_create_depth(l_ear_xpos, ear_ypos, -1, obj_ear,
	{
		ear_type : left_ear_type,
		color_data : color_data,
		dir : dir,

	});
}

if(variable_struct_exists(color_coords, "255,128,0")){
	ear_sprite = variable_struct_get(right_ear_type,dir);
	w = sprite_get_width(ear_sprite);
	h = sprite_get_height(ear_sprite);
	color = variable_struct_get(color_coords, "255,128,0");
	r_ear_xpos = x + color[0];
	ear_ypos = y + (color[1] - h);
	r_ear = instance_create_depth(r_ear_xpos, ear_ypos, -1, obj_ear,
	{
		ear_type : right_ear_type,
		color_data : color_data,
		dir : dir,
	});
}

//Forehead, Purple: Bottom Middle
