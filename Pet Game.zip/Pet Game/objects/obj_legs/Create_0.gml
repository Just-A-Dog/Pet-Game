current_right_leg_type = variable_struct_get(right_leg_type, dir);
current_left_leg_type = variable_struct_get(left_leg_type, dir);

app_right_leg_list = scr_body_part_init_helper(spr_base_s_idle_leg, current_right_leg_type, false);
app_left_leg_list = scr_body_part_init_helper(spr_base_s_idle_leg_r, current_left_leg_type, false);

x_orig = x;
y_orig = y;