x = x1;

current_pixel_list = scr_current_point_list(app_left_leg_list, 1-intensity);
scr_draw_and_fill_in_sprite(current_pixel_list,base_color);
scr_draw_outline_2(current_pixel_list, base_color);

x = x2;

current_pixel_list = scr_current_point_list(app_right_leg_list, 1-intensity);
scr_draw_and_fill_in_sprite(current_pixel_list,base_color);
scr_draw_outline_2(current_pixel_list, base_color);