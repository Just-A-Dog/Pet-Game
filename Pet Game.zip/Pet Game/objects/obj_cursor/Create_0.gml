window_set_cursor(cr_none);
sprite_num = 0;
frame_num = 0;
frame_0_length = 60;
frame_1_length = 120;
petting = false;