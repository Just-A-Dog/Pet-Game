if(!petting) draw_sprite(spr_cursor,sprite_num,mouse_x,mouse_y);
else draw_sprite(spr_petting,sprite_num,x,y);