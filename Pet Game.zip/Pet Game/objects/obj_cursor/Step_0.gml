
//Petting
if(petting){
	scr_anim_petted(freak);
	switch(frame_num){
		case(10): sprite_num = 1; break;
		case(20): sprite_num = 2; break;
		case(30): sprite_num = 3; break;
		case(40): sprite_num = 4; break;
		case(50): sprite_num = 0; frame_num = 0; break;		
	}
}
//Idle Cursor
else{
	if(frame_num == frame_0_length) sprite_num = 1;
	else if(frame_num == frame_1_length) {
		sprite_num = 0;
		frame_num = 0;
	}
}

//When cursor in head area of any freak and click
if(mouse_check_button(mb_left) and !petting){
	touching_freak_head = false;
	for(i = 0; i < instance_number(obj_freak); i++){
		freak = instance_find(obj_freak, i);
		if(point_in_rectangle(mouse_x, mouse_y, freak.head.x, freak.head.y, freak.head.x + freak.head.head_width, freak.head.y + freak.head.head_height)){
			touching_freak_head = freak;	
			break;
		}
	}
	if(touching_freak_head != false){
		x = freak.head.x;
		y = freak.head.y - 6;
		petting = true;
		frame_num = 0;
		scr_reset_anim(freak);
		freak.stop_idle = true;
	}
}
if(petting and mouse_check_button_released(mb_left)) {
	petting = false;
	freak._eye_blink_frame = 100;
	scr_reset_anim(freak);
	freak.stop_idle = false;
}
frame_num++;


//Pet them
//When petting, if click release, return to normal