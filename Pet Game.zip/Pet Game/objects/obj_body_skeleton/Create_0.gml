//Take the base sprite and find each of the points.
//Merge it with the transformed skeleton [should be very easy, just each color to each color]
invisible = true;
intensity = 0;
prev_head_intensity = 0;
prev_intensity = -1;
prev_dir = dir;
dir_i = array_get_index(global.dir, dir);

app_list = [];
for(var i = 0; i < array_length(global.dir); i++){
	array_push(app_list, scr_skeleton_match(variable_struct_get(global.base_body_skeleton,global.dir[i]), 
							  variable_struct_get(transformed_type,global.dir[i])));
}

//Creates an offset for the bottom of the head.
if(variable_instance_exists(transformed_type, "max_head_offset")){
	max_head_offset = variable_instance_get(transformed_type, "max_head_offset");
	arr_length = array_length(max_head_offset);
	if(arr_length < 8){
	    for (var i = arr_length; i < 8; i++) {
	        max_head_offset[i] = 0;
	    }		
	}
}
else max_head_offset = [0,0,0,0,0,0,0,0];

