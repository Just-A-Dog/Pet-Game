cache_key = scr_get_cache_key(global_leg_type, leg_type);
app_leg_list = scr_body_part_init(global_leg_type, leg_type, cache_key, false);
if(!variable_instance_exists(id, "left")) left = true;
