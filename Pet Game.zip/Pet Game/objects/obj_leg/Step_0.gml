if(scr_check_change_sprite(app_leg_list)){
	if(!left){
		scr_find_xydepth_right_leg(leg_type);
		x = right_leg_x;
		y = right_leg_y;
		depth = right_leg_depth;
	}
	else{
		scr_find_xydepth_left_leg(leg_type);
		x = left_leg_x;
		y = left_leg_y;
		//depth = left_leg_depth; Oddly enough, doesn't need depth???
	}
}