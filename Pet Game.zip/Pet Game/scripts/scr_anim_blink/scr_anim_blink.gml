function scr_anim_blink(l_eye, r_eye){
	min_blink_time = 120;
	max_blink_time = 240;
	//Keep note that the frame length's actual length is it minus the previous frame.
	frame_1_length = 6; //Eye closed
	frame_2_length = 8; //Eye opening
	if(!variable_instance_exists(self, "_eye_blink_frame")) _eye_blink_frame = 0;
	if(!variable_instance_exists(self, "_random_blink_frame")) _random_blink_frame = irandom_range(min_blink_time,max_blink_time);
	if(_eye_blink_frame == _random_blink_frame) {
		l_eye.sprite = 1;
		r_eye.sprite = 1;
	}
	else if(_eye_blink_frame == _random_blink_frame + frame_1_length) {
		l_eye.sprite = 2;
		r_eye.sprite = 2;
	}
	else if(_eye_blink_frame == _random_blink_frame + frame_2_length){
		l_eye.sprite = 0;
		r_eye.sprite = 0;
	}
	else if(_eye_blink_frame == _random_blink_frame + frame_2_length + 1){
		_random_blink_frame = irandom_range(min_blink_time,max_blink_time);
		_eye_blink_frame = 0;
	}
	_eye_blink_frame++;
}