{
  "$GMScript":"v1",
  "%Name":"scr_anim_blink",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_anim_blink",
  "parent":{
    "name":"Animations",
    "path":"folders/Current Scripts/Animations.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}