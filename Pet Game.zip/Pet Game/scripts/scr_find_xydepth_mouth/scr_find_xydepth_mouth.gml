function scr_find_xydepth_mouth(mouth_type){
	dir_i = array_get_index(global.dir, dir);
	if(variable_struct_exists(color_coords[dir_i], "0,0,255")){
		invisible = false;
		mouth_sprite = variable_struct_get(mouth_type, dir);
		w = sprite_get_width(mouth_sprite);
		h = sprite_get_height(mouth_sprite);
		color = variable_struct_get(color_coords[dir_i], "0,0,255");
		mouth_x = freak_id.x + ceil(color[0] - floor(w/2)); 
		mouth_y = freak_id.y + color[1];
		mouth_depth = -1;
	}
	else{
		mouth_x = 0;
		mouth_y = 0;
		mouth_depth = -1;
		invisible = true;
	}
}