//Takes two lists of pixels, and associates each pixel with the closest one on the other list.
function scr_pair_points_4(cp_1, cp_2, origin_x = 0, origin_y = 0) {
    var final_array = [];

    if (debug) {
        show_debug_message("DEBUG WORKING");
        show_debug_message(cp_1);
    }

    // Select the longer array as the ordering backbone.
    if (array_length(cp_1) > array_length(cp_2)) {
        long_array = cp_1;
        short_array = cp_2;
        array_swapped = true;
    }
    else {
        long_array = cp_2;
        short_array = cp_1;
        array_swapped = false;
    }

    var long_len = array_length(long_array);
    var short_len = array_length(short_array);

    var matched_long = array_create(long_len, false);
    var matched_short = array_create(short_len, false);

    // Each long-array point gets its own bucket of pairings.
    pair_buckets = array_create(long_len);

    for (var i = 0; i < long_len; i++) {
        pair_buckets[i] = [];
    }

    // Helper: store a pairing in the correct orientation.
    // The bucket index determines where it appears in the final order.
    var add_pair = function(_long_i, _short_j) {
        if (array_swapped) {
            array_push(pair_buckets[_long_i], [
                long_array[_long_i][0],
                long_array[_long_i][1],
                short_array[_short_j][0],
                short_array[_short_j][1],
                long_array[_long_i][2],
                short_array[_short_j][2]
            ]);
        }
        else {
            array_push(pair_buckets[_long_i], [
                short_array[_short_j][0],
                short_array[_short_j][1],
                long_array[_long_i][0],
                long_array[_long_i][1],
                short_array[_short_j][2],
                long_array[_long_i][2]
            ]);
        }
    };

    // MAIN PASS: find radial matches.
    for (var i = 0; i < long_len; i++) {
        for (var j = 0; j < short_len; j++) {
            var matches = scr_pointOnLine_2(
                short_array[j][0],
                short_array[j][1],
                long_array[i][0],
                long_array[i][1],
                origin_x,
                origin_y
            );

            if (!matches) {
                matches = scr_pointOnLine_2(
                    long_array[i][0],
                    long_array[i][1],
                    short_array[j][0],
                    short_array[j][1],
                    origin_x,
                    origin_y
                );
            }

            if (matches) {
                add_pair(i, j);
                matched_long[i] = true;
                matched_short[j] = true;
            }
        }
    }

    // FIRST FALLBACK: match unmatched long-array points.
    for (var i = 0; i < long_len; i++) {
        if (matched_long[i]) continue;

        var best_j = -1;
        var best_distance = infinity;

        for (var j = 0; j < short_len; j++) {
            var d = point_distance(
                long_array[i][0],
                long_array[i][1],
                short_array[j][0],
                short_array[j][1]
            );

            if (d < best_distance) {
                best_distance = d;
                best_j = j;
            }
        }

        if (best_j != -1) {
            add_pair(i, best_j);
            matched_long[i] = true;
            matched_short[best_j] = true;
        }
    }

    // SECOND FALLBACK: match any remaining short-array points.
    for (var j = 0; j < short_len; j++) {
        if (matched_short[j]) continue;

        var best_i = -1;
        var best_distance = infinity;

        for (var i = 0; i < long_len; i++) {
            var d = point_distance(
                short_array[j][0],
                short_array[j][1],
                long_array[i][0],
                long_array[i][1]
            );

            if (d < best_distance) {
                best_distance = d;
                best_i = i;
            }
        }

        if (best_i != -1) {
            add_pair(best_i, j);
            matched_short[j] = true;
            matched_long[best_i] = true;
        }
    }

    // Flatten the buckets in long-array order.
    for (var i = 0; i < long_len; i++) {
        for (var k = 0; k < array_length(pair_buckets[i]); k++) {
            array_push(final_array, pair_buckets[i][k]);
        }
    }

    if (debug) {
        show_debug_message("FINAL ARRAY:");
        show_debug_message(final_array);
    }

    return final_array;
}
