function scr_anim_petted(_freak = self){
	if(!variable_instance_exists(_freak, "_step")) _freak._step = 0;
	if(!_freak.anim_start){
			//Pauses for a sec.
			if(_freak._step == 120){
				_freak.anim_start = true;
				_freak.head.l_eye.sprite = 1;
				_freak.head.r_eye.sprite = 1;
				
				_freak.head.l_eye.y--;
				_freak.head.r_eye.y--;

				_freak.head.mouth.sprite = 1;
				_freak.head.mouth.y-=2;

				_freak.head.l_eyebrow.sprite = 1;
				_freak.head.r_eyebrow.sprite = 1;
				
				_freak._step = 0;
			}
	}
	else{
		//Starts the happy expression
		switch(_freak._step){
			case(50): 
				_freak.head.l_eye.y--;
				_freak.head.r_eye.y--;
				break;
			case(100):
				_freak.head.l_eye.y++;
				_freak.head.r_eye.y++;
				_freak._step = 0;
				break;
			default: break;
		}
	}
	_freak._step++;
}