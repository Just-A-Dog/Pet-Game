{
  "$GMScript":"v1",
  "%Name":"scr_anim_petted",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_anim_petted",
  "parent":{
    "name":"Animations",
    "path":"folders/Current Scripts/Animations.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}