function scr_find_xydepth_head(h_type = head_type){
	dir_i = array_get_index(global.dir, dir);
	if(variable_struct_exists(color_coords[dir_i], "128,0,0") or variable_struct_exists(color_coords[dir_i], "255,128,128")){
		if(variable_struct_exists(color_coords[dir_i], "128,0,0")) color = "128,0,0";
		else color = "255,128,128";
		
		//TODO head_sprite width should be the bottom width of the head.
		head_sprite = variable_struct_get(h_type, dir);
		head_x = variable_struct_get(color_coords[dir_i], color)[0] + freak_id.x - floor(sprite_get_width(head_sprite) / 2);
		head_y = variable_struct_get(color_coords[dir_i], color)[1] + freak_id.y - sprite_get_height(head_sprite);
	}
	else{
		head_x = 0;
		head_y = 0;
		//head_depth = 0;
		invisible = true;
	}
}