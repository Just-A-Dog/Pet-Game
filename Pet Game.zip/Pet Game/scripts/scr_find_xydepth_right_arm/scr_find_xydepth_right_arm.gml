function scr_find_xydepth_right_arm(r_arm_type = right_arm_type){
	dir_i = array_get_index(global.dir, dir);
	if(variable_struct_exists(color_coords[dir_i], "0,128,255")){
		if(dir == "sw" or dir == "w" or dir == "nw" or dir == "ne") right_arm_depth = -1;
		else right_arm_depth = 0;
		right_arm_x = freak_id.x + variable_struct_get(color_coords[dir_i],"0,128,255")[0];
		right_arm_y = freak_id.y + variable_struct_get(color_coords[dir_i],"0,128,255")[1];
		invisible = false;
	}
	else{
		right_arm_x = 0;
		right_arm_y = 0;
		right_arm_depth = 0;
		invisible = true;
	}
}