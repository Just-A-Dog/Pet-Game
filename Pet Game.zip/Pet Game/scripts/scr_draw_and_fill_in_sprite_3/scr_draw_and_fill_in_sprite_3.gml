
function scr_draw_and_fill_in_sprite_3(_points, _fill_color, _head_offset = infinity) {
    var _count = array_length(_points);

    if (_count < 3) return;

    // Find vertical bounds.
    var _min_y = _points[0][1];
    var _max_y = min(_points[0][1],_head_offset);

    for (var i = 1; i < _count; i++) {
        _min_y = min(_min_y, _points[i][1]);
        _max_y = max(_max_y, _points[i][1]);
    }

    draw_set_color(_fill_color);

    // Scan each horizontal row.
	for (var _scan_y = ceil(_min_y); _scan_y <= floor(_max_y); _scan_y++) {
	    var _intersections = [];

	    for (var i = 0; i < _count; i++) {
	        var _next = (i + 1) mod _count;

	        var x1 = _points[i][0];
	        var y1 = _points[i][1];

	        var x2 = _points[_next][0];
	        var y2 = _points[_next][1];

	        if (y1 == y2) continue;

	        if (_scan_y >= min(y1, y2) && _scan_y < max(y1, y2)) {
	            var _t = (_scan_y - y1) / (y2 - y1);
	            var _x = lerp(x1, x2, _t);

	            array_push(_intersections, _x);
	        }
	    }

	    array_sort(_intersections, true);

	    for (var i = 0; i + 1 < array_length(_intersections); i += 2) {
	        draw_line(
	            ceil(x + _intersections[i]),
	            y + _scan_y,
	            floor(x + _intersections[i + 1]),
	            y + _scan_y
	        );
	    }
	}
}
