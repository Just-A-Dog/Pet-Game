{
  "$GMScript":"v1",
  "%Name":"scr_draw_and_fill_in_sprite_3",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_draw_and_fill_in_sprite_3",
  "parent":{
    "name":"DRAW",
    "path":"folders/Current Scripts/DRAW.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}