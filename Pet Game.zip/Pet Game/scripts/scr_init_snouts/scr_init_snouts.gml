function scr_init_snouts(){
	global.base_snout = {
		"s":spr_snout_base_s,
		"sw":spr_snout_base_s,
		"w":spr_snout_base_w,
		"nw":-1,
		"n":-1,
		"ne":-1,
		"e":spr_snout_base_w_r,
		"se":spr_snout_base_s,
	}
	
	global.raccoon_snout = {
		"s":spr_snout_raccoon_s,
		"sw":spr_snout_raccoon_sw,
		"w":spr_snout_raccoon_w,
		"nw":-1,
		"n":-1,
		"ne":-1,
		"e":spr_snout_raccoon_w_r,
		"se":spr_snout_raccoon_sw_r,
	}

}