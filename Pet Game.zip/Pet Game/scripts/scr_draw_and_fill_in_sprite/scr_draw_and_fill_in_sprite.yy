{
  "$GMScript":"v1",
  "%Name":"scr_draw_and_fill_in_sprite",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_draw_and_fill_in_sprite",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}