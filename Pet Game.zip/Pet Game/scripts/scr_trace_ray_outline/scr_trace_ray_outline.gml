function trace_ray_outline(_boundary_pixels){
	final_array = [];
	for (var i = 0; i < array_length(_boundary_pixels); i++)
	{
	    var point = _boundary_pixels[i];

	    var ix = point[0];
	    var iy = point[1];
		
		//Check to the east.
		var has_west = false;
		var has_east = false;
		var has_south = false;

		for (var j = 0; j < array_length(_boundary_pixels); j++)
		{
		    var check_point = _boundary_pixels[j];

		    if (check_point[0] == ix - 1 && check_point[1] == iy)
		    {
		        has_west = true;
		        break;
		    }
		}		
		if(!has_west){
			pttx = ix;
			ptty = iy;
			fpx = -1;
			fpy = -1;

			for(var j = 0; j < array_length(_boundary_pixels); j++){
				point = _boundary_pixels[j];
				var jx = point[0];
				var jy = point[1];
			
				if(jx == pttx + 1 and jy == ptty){
					pttx = jx;
					ptty = jy;
					fpx = jx;
					fpy = jy;
					j = 0;
				}
			}
			if(fpx != -1) {
				array_push(final_array, [[ix, iy], [fpx, fpy]]);
				has_east = true;
			}
		}
		
		// Now check South
		var has_north = false;

		for (var j = 0; j < array_length(_boundary_pixels); j++)
		{
		    var check_point = _boundary_pixels[j];

		    if (check_point[0] == ix && check_point[1] == iy - 1)
		    {
		        has_north = true;
		        break;
		    }
		}		
		if(!has_north){
			pttx = ix;
			ptty = iy;
			fpx = -1;
			fpy = -1;

			for(var j = 0; j < array_length(_boundary_pixels); j++){
				point = _boundary_pixels[j];
				var jx = point[0];
				var jy = point[1];
			
				if(jx == pttx and jy == ptty + 1){
					pttx = jx;
					ptty = jy;
					fpx = jx;
					fpy = jy;
					j = 0;
				}
			}
			if(fpx != -1) array_push(final_array, [[ix, iy], [fpx, fpy]]);
		}
		
		// Now check Southwest
		var has_northeast = false;

		for (var j = 0; j < array_length(_boundary_pixels); j++)
		{
		    var check_point = _boundary_pixels[j];

		    if (check_point[0] == ix + 1 && check_point[1] == iy - 1)
		    {
		        has_northeast = true;
		        break;
		    }
		}		
		if(!has_northeast){
			pttx = ix;
			ptty = iy;
			fpx = -1;
			fpy = -1;

			for(var j = 0; j < array_length(_boundary_pixels); j++){
				point = _boundary_pixels[j];
				var jx = point[0];
				var jy = point[1];
			
				if(jx == pttx - 1 and jy == ptty + 1){
					pttx = jx;
					ptty = jy;
					fpx = jx;
					fpy = jy;
					j = 0;
				}
			}
			if(fpx != -1) array_push(final_array, [[ix, iy], [fpx, fpy]]);
		}
		
		// Now check Southeast
		var has_northwest = false;

		for (var j = 0; j < array_length(_boundary_pixels); j++)
		{
		    var check_point = _boundary_pixels[j];

		    if (check_point[0] == ix - 1 && check_point[1] == iy - 1)
		    {
		        has_northwest = true;
		        break;
		    }
		}		
		if(!has_northwest){
			pttx = ix;
			ptty = iy;
			fpx = -1;
			fpy = -1;

			for(var j = 0; j < array_length(_boundary_pixels); j++){
				point = _boundary_pixels[j];
				var jx = point[0];
				var jy = point[1];
			
				if(jx == pttx + 1 and jy == ptty + 1){
					pttx = jx;
					ptty = jy;
					fpx = jx;
					fpy = jy;
					j = 0;
				}
			}
			if(fpx != -1) array_push(final_array, [[ix, iy], [fpx, fpy]]);
		}
	}
	return final_array
}