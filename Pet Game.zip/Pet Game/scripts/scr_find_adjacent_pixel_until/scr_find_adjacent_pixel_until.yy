{
  "$GMScript":"v1",
  "%Name":"scr_find_adjacent_pixel_until",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_find_adjacent_pixel_until",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}