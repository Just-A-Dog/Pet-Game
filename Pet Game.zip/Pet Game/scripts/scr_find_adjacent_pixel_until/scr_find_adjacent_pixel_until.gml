//Takes a point and searches in that direction until it doesn't find anymore points in that direction.
function find_adjacent_pixel_until(pixel_array, px, py, _dir){
	found_point = false;
	if(_dir == "NE"){
		pxmod = 1;
		pymod = -1;
	}
	else if(_dir == "E"){
		pxmod = 1;
		pymod = 0;
	}
	else if(_dir == "SE"){
		pxmod = 1;
		pymod = 1;
	}
	px += pxmod;
	py += pymod;

	for(var i = 0; i < array_length(pixel_array); i++){
		if(pixel_array[i][0] == px and pixel_array[i][1] == py){
			found_point = i;
			px+=pxmod
			py+=pymod
			i = 0;
		}
	}
	return found_point;
}