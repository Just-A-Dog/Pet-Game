function scr_find_xydepth_left_leg(l_leg_type = left_leg_type){
	dir_i = array_get_index(global.dir, dir);
	if(variable_struct_exists(color_coords[dir_i], "0,128,0")){
		left_leg_x = freak_id.x + variable_struct_get(color_coords[dir_i],"0,128,0")[0];
		left_leg_y = freak_id.y + variable_struct_get(color_coords[dir_i],"0,128,0")[1];
		invisible = false;
	}
	else{
		left_leg_x = 0;
		left_leg_y = 0;
		invisible = true;
	}
}