function scr_update_head_skeleton(_id){
	_id.dir_i = dir_i;
	var body_skeleton = _id.freak_id.body_skeleton;
	var intensity = _id.freak_id.head_intensity;

	_id.current_list = [];
	_id.dir_i = array_get_index(global.dir, dir);
	for(var i = 0; i < array_length(_id.app_list[_id.dir_i]); i++){
		array_push(_id.current_list,
		[
			lerp(_id.app_list[_id.dir_i][i][0], _id.app_list[_id.dir_i][i][2], intensity),
			lerp(_id.app_list[_id.dir_i][i][1], _id.app_list[_id.dir_i][i][3], intensity),
			_id.app_list[_id.dir_i][i][4]]);
	}

	
	_id.half_width = sprite_get_width(variable_struct_get(_id.base_type, dir)) / 2;
	_id.height = sprite_get_height(variable_struct_get(_id.base_type, dir));
	
	//Update x and y based on position of red in self.
	for(var i = 0; i < array_length(body_skeleton.current_list); i++){
		if(body_skeleton.current_list[i][2] == _id.location_color){
			_id.x = body_skeleton.current_list[i][0] - _id.half_width + body_skeleton.x;
			_id.y = body_skeleton.current_list[i][1] - _id.height + body_skeleton.y + 1;
		}
	}
}