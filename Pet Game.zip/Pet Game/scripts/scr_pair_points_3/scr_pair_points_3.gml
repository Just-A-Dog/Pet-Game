//Takes two lists of pixels, and associates each pixel with the closest one on the other list.
function scr_pair_points_3(cp_1, cp_2, origin_x = 0, origin_y = 0){
	final_array = [];

	//Find the widest/tallest CP list
	/*var x1 = 1000;
	var x2 = -1;
	var y1 = 1000;
	var y2 = -1;
	w_and_h_1 = scr_get_width_and_height(cp_1);
	w_and_h_2 = scr_get_width_and_height(cp_2);
	width = max(w_and_h_1[0], w_and_h_2[0]);
	height = max(w_and_h_1[0], w_and_h_2[0]);
	width_difference = w_and_h_1[0] - w_and_h_2[0];
	height_difference = w_and_h_1[1] - w_and_h_2[1];
	

	//Set the smaller sprite to be in the middle of the compared sprites.

	// FIND ORIGIN
	//Finds origin by iterating through all possible points and finding the lowest average distance to all of the outer points.
	//This is expensive, but shouldn't be an issue with the cache.

	var both_array_lengths = array_length(cp_1) + array_length(cp_2);
	var best_average = 10000;
	var current_average = best_average;

	for(var i = 0; i < height; i++){
		for(var j = 0; j < width; j++){
			sum = 0;
			for(var k = 0; k < array_length(cp_1); k++){
				sum += point_distance(i, j, cp_1[k][0], cp_1[k][1]);
			}
			for(var k = 0; k < array_length(cp_2); k++){
				sum += point_distance(i, j, cp_2[k][0], cp_2[k][1]);
			}
			current_average = sum / both_array_lengths;
			if(best_average > current_average){
				best_average = current_average;
				origin_x = i;
				origin_y = j;
			}
		}
	}
*/
	//Now we should have an origin. And now we pair points based on that origin.
	//Currently arbitrarily starting at 0 on the 'longer' array. Don't know what starting point would be 'good'.
	//The longer array should be the one that encircles the other.
	if(array_length(cp_1) > array_length(cp_2)){
		long_array = cp_1;
		short_array = cp_2;
		array_swapped = true;
	}
	else{
		long_array = cp_2;
		short_array = cp_1;
		array_swapped = false;
	}
	//Pair the points.
	for(var i = 0; i < array_length(long_array); i++){
		//Check each point in long array. See if any points from short array cross between it and the origin.
		for(var j = 0; j < array_length(short_array); j++){
			//The issue is that we're missing some points somehow. Maybe we grab the closest one?
			//But then, this will always cause some to be missing. THOUGH if we're going through the larger one, if we grab the closest it might work
			//Though... what about overlap? The two closest?? That'd be kinda funny. Why not try it?
			if(scr_pointOnLine(short_array[j][0], short_array[j][1], long_array[i][0], long_array[i][1], origin_x, origin_y)){
				if(array_swapped)
					array_push(final_array, [long_array[i][0], long_array[i][1], short_array[j][0], short_array[j][1], long_array[i][2], short_array[j][2]]);
				else
					array_push(final_array, [short_array[j][0], short_array[j][1], long_array[i][0], long_array[i][1], short_array[j][2], long_array[i][2]]);
			}
			else if(scr_pointOnLine(long_array[i][0], long_array[i][1], short_array[j][0], short_array[j][1],origin_x,origin_y)){
				if(array_swapped)
					array_push(final_array, [long_array[i][0], long_array[i][1], short_array[j][0], short_array[j][1], long_array[i][2], short_array[j][2]]);
				else
					array_push(final_array, [short_array[j][0], short_array[j][1], long_array[i][0], long_array[i][1], short_array[j][2], long_array[i][2]]);
			}
		}
	}
	//POTENTIAL ISSUE: Match Long array points that don't match up with anyone to its closest match.
	//Create a struct with all of the small array's points in it. Initialize each key as an infinitely high number.
	short_array_struct = {};
	for(var i = 0; i < array_length(short_array); i++){
		current_index = string(short_array[i][0]) + "," + string(short_array[i][1]);

		short_array_struct[$ current_index] = {
		    distance : infinity,
		    coord : -1,
		    color : short_array[i][2]
		};
	}
	
	for(var i = 0; i < array_length(long_array); i++){
		found_point = false;
		closest_short_point = {distance : infinity, coord : -1};
		//Check each point in long array. See if any points from short array cross between it and the origin.
		for(var j = 0; j < array_length(short_array); j++){
			//Look into the short array struct. If it is in there, still, save the smaller of the current value at that key or the distance to line.
			//That way, if the point is never found, we can instead attach it to the shortest point.
			distance = scr_pointOnLine(short_array[j][0], short_array[j][1], long_array[i][0], long_array[i][1], origin_x, origin_y);
			current_index = string(short_array[j][0]) + "," + string(short_array[j][1]);
			if(variable_struct_exists(short_array_struct, current_index) and !is_bool(distance)){
				_ = variable_struct_get(short_array_struct, current_index);
				if(distance < _.distance){
					_.coord = [long_array[i][0], long_array[i][1]];
					_.distance = distance;
				}
			}			
			if(distance == true){
				found_point = true;
				//Remove short array's point from the short_array_struct, since it already has a partner.
				if(variable_struct_exists(short_array_struct, current_index)) struct_remove(short_array_struct, current_index);
				if(array_swapped)
					array_push(final_array, [long_array[i][0], long_array[i][1], short_array[j][0], short_array[j][1], long_array[i][2], short_array[j][2]]);
				else
					array_push(final_array, [short_array[j][0], short_array[j][1], long_array[i][0], long_array[i][1], short_array[j][2], long_array[i][2]]);
			}			
			else if(scr_pointOnLine(long_array[i][0], long_array[i][1], short_array[j][0], short_array[j][1],origin_x,origin_y) == true){
				found_point = true;
				//Remove short array's point from the short_array_struct, since it already has a partner.
				if(variable_struct_exists(short_array_struct, current_index)) struct_remove(short_array_struct, current_index);

				if(array_swapped)
					array_push(final_array, [long_array[i][0], long_array[i][1], short_array[j][0], short_array[j][1], long_array[i][2], short_array[j][2]]);
				else
					array_push(final_array, [short_array[j][0], short_array[j][1], long_array[i][0], long_array[i][1], short_array[j][2], long_array[i][2]]);
			}
			else if(!is_bool(distance)){
				if(closest_short_point.distance > distance){
					closest_short_point.distance = distance;
					closest_short_point.coord = short_array[j];
				}
			}
		}
		
		if(!found_point){
				if(array_swapped)
					array_push(final_array, [long_array[i][0], long_array[i][1], closest_short_point.coord[0], closest_short_point.coord[1], long_array[i][2], closest_short_point.coord[2]]);
				else
					array_push(final_array, [closest_short_point.coord[0], closest_short_point.coord[1], long_array[i][0], long_array[i][1], closest_short_point.coord[2], long_array[i][2]]);
		}
	}
	//Iterate through the short array struct. This should have all of the non-used points in it.
	var keys = struct_get_names(short_array_struct);
	
	for(var i = 0; i < array_length(keys); i++){
		//Then add the point into the final array based on where the larger array point it is connected is. 
		//Convert key into an actual array [the actual point needed to add into the final array]
		var key = keys[i];
		var parts = string_split(key, ",");
		var missing_point = [real(parts[0]),real(parts[1])];
		
		//When we find the larger array point, we add all of the shorter array points connected to that one point [in a row] to a new array.
		var found_index = -1;		
		list_of_long_array_points = {};
		for(var j = 0; j < array_length(final_array); j++){
			
			if((array_equals([final_array[j][0],final_array[j][1]], short_array_struct[$ key].coord) and array_swapped)
			or array_equals([final_array[j][2], final_array[j][3]], short_array_struct[$ key].coord)){
				if(found_index == -1) found_index = j;
				//Normalize this list of long array_points
				if(array_swapped) variable_struct_set(list_of_long_array_points, string(final_array[j][2]) + ", " + string(final_array[j][3]), true);
				else variable_struct_set(list_of_long_array_points, string(final_array[j][0]) + ", " + string(final_array[j][1]), true);
			}
			else if(found_index != -1) break;
		}
		//Then we search through the shorter array. Whenever we hit a point that's on the new array, we increment a value.
		index_offset = 0;
		for(var j = 0; j < array_length(short_array); j++){
			if (short_array[j][0] == missing_point[0] &&  short_array[j][1] == missing_point[1]) break;
			else if(variable_struct_exists(list_of_long_array_points, string(short_array[j][0]) + ", " + string(short_array[j][1]))) index_offset++;
		}

		//This is all to find the right x,y,color coords to add to the array.
		var long_coord = short_array_struct[$ key].coord;
		var short_color = short_array_struct[$ key].color;
		var long_color = -1;

		if (is_real(long_coord)) {
		    show_debug_message("ERROR: SOMEHOW LONG_COORD NOT ASSIGNED");
		    continue;
		}

		// Find the color associated with the matched long-array point.
		for (var j = 0; j < array_length(long_array); j++) {
		    if (long_array[j][0] == long_coord[0]
		    &&  long_array[j][1] == long_coord[1]) {
		        long_color = long_array[j][2];
		        break;
		    }
		}

		if (found_index == -1) {
			show_debug_message("ERROR: NO FOUND INDEX SOMEHOW.");
		    continue;
		}

		if (!array_swapped) {
		    array_insert(final_array, found_index + index_offset, [
		        missing_point[0], missing_point[1],
		        long_coord[0], long_coord[1],
		        short_color, long_color
		    ]);
		} else {
		    array_insert(final_array, found_index + index_offset, [
		        long_coord[0], long_coord[1],
		        missing_point[0], missing_point[1],
		        long_color, short_color
		    ]);
		}
	}
	return final_array;
}