//Converts a sprite to the proper palette's colors.
function scr_convert_to_palette(sprite_to_analyze, _color_data = {}){
	final_array = [];
	var w = sprite_get_width(sprite_to_analyze);
	var h = sprite_get_height(sprite_to_analyze);

	surf = surface_create(w, h);
	
	for(_i = 0; _i < sprite_get_number(sprite_to_analyze); _i++){
		surface_set_target(surf);
		draw_clear_alpha(c_white, 0);
		draw_sprite(sprite_to_analyze, _i, 0, 0);
		surface_reset_target();
		surface_set_target(surf);

		// Turns the image into an array that is True for non-transparent pixels
		// and False for transparent pixels.
		var pixels = [];
	
		for (var py = 0; py < h; py++)
		{
		    pixels[py] = [];

		    for (var px = 0; px < w; px++)
		    {
				// Get the pixel's color
				var pixel = surface_getpixel_ext(surf, px, py);

				var red  = pixel & 255;
				var green = (pixel >> 8) & 255;
				var blue   = (pixel >> 16) & 255;
				var alpha = (pixel >> 24) & 255;
				if(alpha > 0){
					color_string = scr_color_to_string(red, green, blue);
					if(variable_struct_exists(_color_data, color_string)) color = variable_struct_get(_color_data, color_string);	
					else color = make_color_rgb(red, green, blue);
		            final_array[_i][array_length(final_array[_i])] = [px, py, color];
				}			
		    }
		}
	
		surface_reset_target();
	}
	
	return final_array;
}