{
  "$GMScript":"v1",
  "%Name":"scr_convert_to_palette",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_convert_to_palette",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}