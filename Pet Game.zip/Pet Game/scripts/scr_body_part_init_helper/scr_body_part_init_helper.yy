{
  "$GMScript":"v1",
  "%Name":"scr_body_part_init_helper",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_body_part_init_helper",
  "parent":{
    "name":"Body Part Init",
    "path":"folders/Current Scripts/Body Part Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}