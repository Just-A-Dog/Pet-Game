//Initializes a body part by associating the point of a pretransformed part, and a post transformed part, returning a list of associated pixels.
//TODO: Find out whether or not they're both symmetrical. If they are, return scr_pair_points_symmetrical, else do scr_pair_points_2
function scr_body_part_init_helper(_base_sprite, _transform_sprite, _symmetrical = true){
//Gets all of the bordered pixels
bd_unordered_list_1 = scr_analyze_shape_3(_base_sprite);  //
bd_unordered_list_2 = scr_analyze_shape_3(_transform_sprite); //

//Organizes the bordered pixels
bd_list_1 = scr_walkabout_2(bd_unordered_list_1, sprite_get_width(_base_sprite), sprite_get_height(_base_sprite));
bd_list_2 = scr_walkabout_2(bd_unordered_list_2, sprite_get_width(_transform_sprite), sprite_get_height(_transform_sprite));

//Pairs the points together to their closest neighbor
if(_symmetrical){
	sym_line = (sprite_get_width(_base_sprite) / 2);
	if(sym_line % 2 != 0) sym_line = floor(sym_line);
	return scr_pair_points_symmetrical(bd_list_1, bd_list_2, sym_line);
}

else return scr_pair_points_2(bd_list_1, bd_list_2);
}