function scr_update_body(_id){
	_id.dir_i = dir_i;
	current_pixel_list = [];
	var min_x = 1000;
	var min_y = 1000;
	var max_x = -1;
	var max_y = -1;
	prev_x = undefined;
	prev_y = undefined;
	app_list = _id.app_list;
	sprite_num = _id.sprite_num;
	intensity = _id.freak_id.body_intensity;
	var skeleton = _id.freak_id.body_skeleton;
	
	for(i = 0; i < array_length(app_list[dir_i][sprite_num]); i++){
		current_x = round(lerp(app_list[dir_i][sprite_num][i][0], app_list[dir_i][sprite_num][i][2], intensity));
		current_y = round(lerp(app_list[dir_i][sprite_num][i][1], app_list[dir_i][sprite_num][i][3], intensity));

		min_x = min(current_x, min_x);
		min_y = min(current_y, min_y);
		max_x = max(current_x, max_x);
		max_y = max(current_y, max_y);

		scr_fill_in_pixel_gaps_3(i);
		
		array_push(current_pixel_list,
		[current_x, current_y,
		make_color_rgb(
			(app_list[dir_i][sprite_num][i][4][0] * (1-intensity) + app_list[dir_i][sprite_num][i][5][0] * (intensity)),
			(app_list[dir_i][sprite_num][i][4][1] * (1-intensity) + app_list[dir_i][sprite_num][i][5][1] * (intensity)),
			(app_list[dir_i][sprite_num][i][4][2] * (1-intensity) + app_list[dir_i][sprite_num][i][5][2] * (intensity)))
		]);
		
		prev_x = current_x;
		prev_y = current_y;
	}
	current_x = current_pixel_list[0][0];
	current_y = current_pixel_list[0][1];
		
	//Fill in gap between first and last point if need be.
	scr_fill_in_pixel_gaps_3(i-1);
		
	var w_and_h = scr_get_width_and_height(current_pixel_list);
	var half_width = floor(w_and_h[0]/2);
	var height = w_and_h[1];
	
	for(i = 0; i < array_length(skeleton.current_list); i++){
		//XY should be based on bottom middle of body.
		if(skeleton.current_list[i][2] == _id.location_color){
			_id.x = (floor(skeleton.current_list[i][0]) + skeleton.x) - half_width;
			_id.y = (floor(skeleton.current_list[i][1]) + skeleton.y) - height;
			break;
		}
	}
	
	_id.current_pixel_list = scr_walkabout_2(current_pixel_list, max_x, max_y);

	_id.x -= min_x;
	_id.y -= min_y;
	scr_update_adjust_x_and_y_helper(_id, _id.global_type, _id.transformed_type);
	
	_id.depth = _id.freak_id.depth;
}