// This returns pairs that are opposite each other horizontally. Not exactly what I wanted, but useful, I guess.

function trace_ray(_pixels, _w, _h, _x, _y, _dx, _dy)
{
    var px = _x + _dx;
    var py = _y + _dy;

    // The adjacent pixel is transparent.
    // Nothing to trace.
    if (px < 0 || px >= _w || py < 0 || py >= _h)
        return undefined;

    if (!_pixels[py][px])
        return undefined;

    // Keep moving while the pixels are solid.
    while (true)
    {
        var next_x = px + _dx;
        var next_y = py + _dy;

        // We've reached the edge of the sprite.
        if (next_x < 0 || next_x >= _w ||
            next_y < 0 || next_y >= _h)
        {
            break;
        }

        // The next pixel is transparent.
        if (!_pixels[next_y][next_x])
        {
            break;
        }

        px = next_x;
        py = next_y;
    }

    return [[_x, _y], [px, py]];
}