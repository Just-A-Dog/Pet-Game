{
  "$GMScript":"v1",
  "%Name":"scr_change_directions_2",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_change_directions_2",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}