function scr_change_directions_2(_freak, _dir){
	_freak.dir = _dir;
	/*
	_freak.body.dir = _dir;
	_freak.body_skeleton.dir = _dir;
	_freak.head.dir = _dir;
	_freak.left_arm.dir = _dir;
	_freak.right_arm.dir = _dir;
	_freak.left_leg.dir = _dir;
	_freak.right_leg.dir = _dir;
	_freak.left_eye.dir = _dir;
	_freak.right_eye.dir = _dir;
	_freak.snout.dir = _dir;*/
}