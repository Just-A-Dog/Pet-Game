function scr_reset_anim(_freak){
	if(variable_instance_exists(_freak, "_step")) _freak._step = 0;
	_freak.anim_start = false;
	_freak.head.mouth.sprite = 0;
	_freak.head.r_eyebrow.sprite = 0;
	_freak.head.l_eyebrow.sprite = 0;
	
	scr_reset_anim_helper(_freak.body);
	scr_reset_anim_helper(_freak.body.left_arm);
	scr_reset_anim_helper(_freak.body.left_leg);
	scr_reset_anim_helper(_freak.body.right_arm);
	scr_reset_anim_helper(_freak.body.right_leg);


	scr_reset_anim_helper(_freak.head);
	scr_reset_anim_helper(_freak.head.l_ear);
	scr_reset_anim_helper(_freak.head.r_ear);
	scr_reset_anim_helper(_freak.head.l_eye);
	scr_reset_anim_helper(_freak.head.r_eye);
	scr_reset_anim_helper(_freak.head.l_eyebrow);
	scr_reset_anim_helper(_freak.head.r_eyebrow);
	scr_reset_anim_helper(_freak.head.mouth);
	scr_reset_anim_helper(_freak.head.nose);
	scr_reset_anim_helper(_freak.head.chin);
}