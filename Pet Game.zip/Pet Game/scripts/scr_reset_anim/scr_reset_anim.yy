{
  "$GMScript":"v1",
  "%Name":"scr_reset_anim",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_reset_anim",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}