function scr_init_noses(){
	global.base_nose = {
		s : spr_base_s_idle_nose,
		sw : spr_base_s_idle_nose,
		w : spr_base_s_idle_nose,
		nw : -1,
		n : -1,
		ne : -1,
		e : spr_base_s_idle_nose,
		se : spr_base_s_idle_nose,
	}
	global.raccoon_nose = {
		s : spr_raccoon_s_idle_nose,
		sw : spr_raccoon_s_idle_nose,
		w : spr_raccoon_s_idle_nose,
		nw : -1,
		n : -1,
		ne : -1,
		e : spr_raccoon_s_idle_nose,
		se : spr_raccoon_s_idle_nose,
	}
}