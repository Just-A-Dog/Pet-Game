function scr_draw_and_fill_in_sprite_OLD(_boundary_pixels, _inner_color, _head_offset = infinity)
{
    var count = array_length(_boundary_pixels);

    if (count < 3) return;

    var min_y = _boundary_pixels[0][1];
    var max_y = min_y;

    for (var i = 1; i < count; i++)
    {
        min_y = min(min_y, _boundary_pixels[i][1]);
        max_y = max(max_y, _boundary_pixels[i][1]);
    }

    draw_set_color(_inner_color);

    for (var py = min_y; py <= max_y; py++)
    {
        var intersections = [];

        // Collect intersections with this scanline.
        for (var i = 0; i < count; i++)
        {
            var j = (i + 1) mod count;

            var x1 = _boundary_pixels[i][0];
            var y1 = _boundary_pixels[i][1];
            var x2 = _boundary_pixels[j][0];
            var y2 = _boundary_pixels[j][1];

            // Horizontal edges are handled separately by the fill rule.
            if (y1 == y2) continue;

            // Half-open interval avoids counting shared vertices twice.
            if (py >= min(y1, y2) && py < max(y1, y2))
            {
                var ix = x1 + (py - y1) * (x2 - x1) / (y2 - y1);
                array_push(intersections, ix);
            }
        }

        array_sort(intersections, true);

        // Fill between pairs of intersections.
        for (var k = 0; k + 1 < array_length(intersections); k += 2)
        {
            var left = ceil(intersections[k]);
            var right = floor(intersections[k + 1]);
			
			py = min(py, _head_offset);
            if (left <= right)
            {
                draw_rectangle(
                    x + left,
                    y + py,
                    x + right,
                    y + py,
                    false
                );
            }
        }
    }
}