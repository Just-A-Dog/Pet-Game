{
  "$GMScript":"v1",
  "%Name":"scr_draw_and_fill_in_sprite_OLD",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_draw_and_fill_in_sprite_OLD",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}