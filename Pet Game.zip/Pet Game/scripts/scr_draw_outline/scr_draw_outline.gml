function scr_draw_outline(_outline_pixels){
	for(var i = 0; i < array_length(_outline_pixels); i++){
		px1 = _outline_pixels[i][0];
		py1 = _outline_pixels[i][1];
	
		if(i != array_length(_outline_pixels) - 1) {
			px2 = _outline_pixels[i+1][0];
			py2 = _outline_pixels[i+1][1];
		}
		else {
			px2 = _outline_pixels[0][0];
			py2 = _outline_pixels[0][1];	
		}
		if(px2 > px1){
			xmod = -1;
			xmod2 = 0;
		}
		else{
			xmod = 0;
			xmod2 = -1;
		}
		if (py2 > py1){
			ymod = -1;
			ymod2 = 0;
		}
		else{
			ymod = 0;
			ymod2 = -1;
		}
		draw_line(px1 + xmod, py1 + ymod, px2 + xmod2, py2 + ymod2);
	}
}