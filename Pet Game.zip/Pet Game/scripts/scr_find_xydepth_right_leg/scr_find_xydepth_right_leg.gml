function scr_find_xydepth_right_leg(r_leg_type = right_leg_type){
	dir_i = array_get_index(global.dir, dir);
	if(variable_struct_exists(color_coords[dir_i], "128,128,255")){
		if(dir == "sw" or dir == "nw") right_leg_depth = -1;
		else right_leg_depth = 0;
		right_leg_sprite = variable_struct_get(r_leg_type, dir);
		right_leg_width = sprite_get_width(right_leg_sprite) - 1;
		right_leg_x = freak_id.x + variable_struct_get(color_coords[dir_i],"128,128,255")[0] - right_leg_width;
		right_leg_y = freak_id.y + variable_struct_get(color_coords[dir_i],"128,128,255")[1];
		invisible = false;
	}
	else{
		right_leg_x = 0;
		right_leg_y = 0;
		right_leg_depth = 0;
		invisible = true;
	}
}