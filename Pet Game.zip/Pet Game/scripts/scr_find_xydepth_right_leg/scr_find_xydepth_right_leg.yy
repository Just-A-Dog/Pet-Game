{
  "$GMScript":"v1",
  "%Name":"scr_find_xydepth_right_leg",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_find_xydepth_right_leg",
  "parent":{
    "name":"Find XYDEPTH",
    "path":"folders/Current Scripts/Find XYDEPTH.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}