function scr_update_tail(_id){
	_id.dir_i = dir_i;
	current_pixel_list = []; //Empties the drawn pixel list

	//Min_x/min_y are used to position the pixels properly, since the shape is unknown.
	var min_x = 1000;
	var min_y = 1000;
	
	//Max_x/max_y are used by the new walkabout to prevent checking through sprite boundaries
	var max_x = -1;
	var max_y = -1;

	//Prev_x/prev_y used to check gaps between moved pixels so that a pixel can be added between them.
	prev_x = undefined;
	prev_y = undefined;
	
	app_list = _id.app_list;
	sprite_num = _id.sprite_num;
	intensity = _id.freak_id.tail_intensity;
	var skeleton = _id.freak_id.body_skeleton;
	var location_color = _id.location_color;
	
	if(app_list[dir_i] != -1){
		//Creates the new list of pixels based on the paired pixels' distance from one another.
		current_x = -1;
		current_y = -1;
		for(i = 0; i < array_length(app_list[dir_i][sprite_num]); i++){
			current_x = round(lerp(app_list[dir_i][sprite_num][i][0], app_list[dir_i][sprite_num][i][2], intensity));
			current_y = round(lerp(app_list[dir_i][sprite_num][i][1], app_list[dir_i][sprite_num][i][3], intensity));
	
			min_x = min(current_x, min_x);
			min_y = min(current_y, min_y);
			max_x = max(current_x, max_x);
			max_y = max(current_y, max_y);
		
			//If there is a gap in the pixels, are you the first pixel/is x farther than 1 pixel away/is y farther than 1 pixel away
			scr_fill_in_pixel_gaps_3(i);
			
			array_push(current_pixel_list,
			[current_x, current_y,
			make_color_rgb(
				(app_list[dir_i][sprite_num][i][4][0] * (1-intensity) + app_list[dir_i][sprite_num][i][5][0] * (intensity)),
				(app_list[dir_i][sprite_num][i][4][1] * (1-intensity) + app_list[dir_i][sprite_num][i][5][1] * (intensity)),
				(app_list[dir_i][sprite_num][i][4][2] * (1-intensity) + app_list[dir_i][sprite_num][i][5][2] * (intensity)))
			]);
		
			prev_x = current_x;
			prev_y = current_y;
		}
		current_x = current_pixel_list[0][0];
		current_y = current_pixel_list[0][1];
		
		//Fill in gap between first and last point if need be.
		scr_fill_in_pixel_gaps_3(i-1);

		//Positions the new x and y of the shape.
		var w_and_h = scr_get_width_and_height(current_pixel_list);
		var width = w_and_h[0];
		var half_width = floor(width/2);
		var height = w_and_h[1];
		var found = false;

		for(i = 0; i < array_length(skeleton.current_list); i++){
			//XY should be based on bottom middle of body.
			if(skeleton.current_list[i][2] == location_color){
				found = true;
				_id.x = (floor(skeleton.current_list[i][0]) + skeleton.x);
				if(_id.freak_id.dir == "n" or _id.freak_id.dir == "s") _id.x -= half_width;
				else if(_id.freak_id.dir == "ne" or _id.freak_id.dir == "e" or _id.freak_id.dir == "se") _id.x -= width;
				_id.y = floor(skeleton.current_list[i][1]) + skeleton.y;
				break;
			}
		}
		if(!found) _id.invisible = true;
		else{
			_id.invisible = false;
			_id.current_pixel_list = scr_walkabout_2(current_pixel_list, max_x, max_y);
			_id.x -= min_x;
			_id.y -= min_y;

			scr_update_adjust_x_and_y_helper(_id, _id.global_type, _id.transformed_type);
		}
	}
	else _id.invisible = true;
	if(_id.freak_id.dir == "s" or _id.freak_id.dir == "se" or _id.freak_id.dir == "sw") _id.depth = _id.freak_id.depth + 3;
	else if(_id.freak_id.dir == "e" or _id.freak_id.dir == "w") _id.depth = _id.freak_id.depth - 1;
	else _id.depth = _id.freak_id.depth - 1;
}