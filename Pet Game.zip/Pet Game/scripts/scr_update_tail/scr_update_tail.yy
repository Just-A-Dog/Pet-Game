{
  "$GMScript":"v1",
  "%Name":"scr_update_tail",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_update_tail",
  "parent":{
    "name":"Update Freak Position and Depth",
    "path":"folders/Current Scripts/Update Freak Position and Depth.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}