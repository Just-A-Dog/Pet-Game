function scr_color_to_string(red, green, blue){
	return string(red) + "," + string(green) + "," + string(blue);
}