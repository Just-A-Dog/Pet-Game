{
  "$GMScript":"v1",
  "%Name":"scr_color_to_string",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_color_to_string",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}