function scr_get_cache_key(_struct_1, _struct_2){
	return scr_get_cache_key_helper(_struct_1) + ":" + scr_get_cache_key_helper(_struct_2);
}