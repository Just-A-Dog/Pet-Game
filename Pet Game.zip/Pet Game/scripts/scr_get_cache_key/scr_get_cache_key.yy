{
  "$GMScript":"v1",
  "%Name":"scr_get_cache_key",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_get_cache_key",
  "parent":{
    "name":"Cache",
    "path":"folders/Current Scripts/Cache.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}