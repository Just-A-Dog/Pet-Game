{
  "$GMScript":"v1",
  "%Name":"scr_body_part_init",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_body_part_init",
  "parent":{
    "name":"Body Part Init",
    "path":"folders/Current Scripts/Body Part Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}