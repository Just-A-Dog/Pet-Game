//Returns a list of paired points lists. Paired points from the transformed sprite and the base sprite.
function scr_body_part_init(_base_type, _transformed_type, _cache_key, symmetrical = false) {
    prev_intensity = -1;
    prev_dir = dir;
    x_orig = x;
    y_orig = y;

    if (!variable_instance_exists(id, "invisible")) {
        invisible = false;
    }

    // Check whether this configuration is already cached.
    if (variable_struct_exists(global.app_cache, _cache_key)) {
        return variable_struct_get(global.app_cache, _cache_key);
    }

    // Cache miss: generate the app_list.
    var _app_list = [];

    for (var _k = 0; _k < array_length(global.dir); _k++) {
        var _base_type_sprite =
            variable_struct_get(_base_type, global.dir[_k]);

        var _current_type_sprite =
            variable_struct_get(_transformed_type, global.dir[_k]);

        if (_current_type_sprite == -1 || _base_type_sprite == -1) {
            array_push(_app_list, -1);
        } else {
            array_push(
                _app_list,
                scr_body_part_init_helper(
                    _base_type_sprite,
                    _current_type_sprite,
                    symmetrical
                )
            );
        }
    }

    // Keep the generated result for future requests.
    variable_struct_set(global.app_cache, _cache_key, _app_list);
    global.app_cache_dirty = true;

    return _app_list;
}


/*function scr_body_part_init(_base_type, _transformed_type){
	prev_intensity = -1;
	prev_dir = dir;
	x_orig = x;
	y_orig = y;
	if(!variable_instance_exists(id, "invisible")) invisible = false;

	_app_list = [];
	for(_k = 0; _k < array_length(global.dir); _k++){
		_base_type_sprite = variable_struct_get(_base_type, global.dir[_k]);
		_current_type_sprite = variable_struct_get(_transformed_type, global.dir[_k]);
		if(_current_type_sprite == -1 or _base_type_sprite == -1) array_push(_app_list, -1);
		else array_push(_app_list,scr_body_part_init_helper(_base_type_sprite, _current_type_sprite, false));
	}
	return _app_list;
}