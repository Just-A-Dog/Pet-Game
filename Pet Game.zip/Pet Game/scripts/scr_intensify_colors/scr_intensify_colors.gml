function scr_intensify_colors(_color_set_1, _color_set_2, _intensity){
	var r = _color_set_1[0] + ((_color_set_2[0] - _color_set_1[0]) * _intensity);
	var g = _color_set_1[1] + ((_color_set_2[1] - _color_set_1[1]) * _intensity);
	var b = _color_set_1[2] + ((_color_set_2[2] - _color_set_1[2]) * _intensity);
	return make_color_rgb(r, g, b);
}