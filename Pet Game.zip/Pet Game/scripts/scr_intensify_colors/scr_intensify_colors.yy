{
  "$GMScript":"v1",
  "%Name":"scr_intensify_colors",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_intensify_colors",
  "parent":{
    "name":"Update current pixel list",
    "path":"folders/Current Scripts/Update current pixel list.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}