function scr_analyze_shape(sprite_to_analyze){
	var w = sprite_get_width(sprite_to_analyze);
	var h = sprite_get_height(sprite_to_analyze);

	surf = surface_create(w, h);

	surface_set_target(surf);
	draw_clear_alpha(c_black, 0);
	draw_sprite(sprite_to_analyze, 0, 0, 0);
	surface_reset_target();

	surface_set_target(surf);

	//Turns the image into an array that is True for non-transparent pixels and False for transparent pixels.
	var pixels = [];
	for (var py = 0; py < h; py++)
	{
	    pixels[py] = [];

	    for (var px = 0; px < w; px++)
	    {
			var pixel = surface_getpixel_ext(surf, px, py);
			// Basically, turning Alpha RGB -> Just alpha then ANDing it with 11111111 to keep just the value of alpha.
			// These are bitwise operators.
	        var alpha = (pixel >> 24) & 255;

	        pixels[py][px] = (alpha > 0);
	    }
	}

	surface_reset_target();

	var boundary_pixels = [];

	for (var py = 0; py < h; py++)
	{
	    for (var px = 0; px < w; px++)
	    {
	        // Ignore transparent pixels
	        if (!pixels[py][px])
	            continue;

	        var boundary = false;

	        // North
	        if (py == 0 || !pixels[py - 1][px])
	            boundary = true;

	        // East
	        if (px == w - 1 || !pixels[py][px + 1])
	            boundary = true;

	        // South
	        if (py == h - 1 || !pixels[py + 1][px])
	            boundary = true;

	        // West
	        if (px == 0 || !pixels[py][px - 1])
	            boundary = true;

	        if (boundary)
	        {
	            boundary_pixels[array_length(boundary_pixels)] = [px, py];
	        }
	    }
	}
	
	//Now we're going to try my code to find the pairs.
	return scr_walkabout(boundary_pixels, w, h);
}