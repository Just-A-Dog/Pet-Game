function scr_skeleton_analyzer(_skeleton_sprite){
	var w = sprite_get_width(_skeleton_sprite);
	var h = sprite_get_height(_skeleton_sprite);
	_color_coords = {};

	surf = surface_create(w, h);

	surface_set_target(surf);
	draw_clear_alpha(c_black, 0);
	draw_sprite(_skeleton_sprite, 0, 0, 0);
	surface_reset_target();

	surface_set_target(surf);

	// Turns the image into an array that is True for non-transparent pixels
	// and False for transparent pixels.
	// Create a 2D array to store whether each pixel is visible.
    var pixels = array_create(h);
	
	for (var py = 0; py < h; py++) {
        pixels[py] = array_create(w, false);
    }
		
	for (var py = 0; py < h; py++)
	{
		for (var px = 0; px < w; px++)
	    {
			var pixel = surface_getpixel_ext(surf, px, py);

            // Extract alpha. Transparent pixels are ignored.
            var alpha = (pixel >> 24) & 255;

            if (alpha == 0)
                continue;
			
	        pixels[py][px] = true;
		   
			// Get the pixel's color
			var pixel = surface_getpixel_ext(surf, px, py);

			var red  = pixel & 255;
			var green = (pixel >> 8) & 255;
			var blue   = (pixel >> 16) & 255;
			variable_struct_set(_color_coords, scr_color_to_string(red,green,blue), [px, py]);
		}
	}
	surface_reset_target();
	return _color_coords;
}