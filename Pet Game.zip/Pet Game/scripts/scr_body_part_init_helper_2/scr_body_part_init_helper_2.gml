//Initializes a body part by associating the point of a pretransformed part, and a post transformed part, returning a list of associated pixels.
function scr_body_part_init_helper_2(_base_sprite, _transform_sprite, _color_dict = {}){
//Gets all of the bordered pixels
//We need to add in some adjustments for the size of each sprite if they're off.

//This is a complicated way to say 'if the width/height is significantly higher than the others', we move it to the middle.
//Since body should be drawn from the middle of itself, then this shouldn't effect x/y depending on transform_sprite.
x1_offset = max(floor((sprite_get_width(_transform_sprite) - sprite_get_width(_base_sprite)) / 2), 0);
y1_offset = max(floor((sprite_get_height(_transform_sprite) - sprite_get_height(_base_sprite)) / 2), 0);
bd_unordered_list_1 = scr_analyze_shape_3(_base_sprite,x1_offset, y1_offset, _color_dict);

x2_offset = max(floor((sprite_get_width(_base_sprite) - sprite_get_width(_transform_sprite)) / 2), 0);
y2_offset = max(floor((sprite_get_height(_base_sprite) - sprite_get_height(_transform_sprite)) / 2), 0);
bd_unordered_list_2 = scr_analyze_shape_3(_transform_sprite,x2_offset, y2_offset, _color_dict);

//Organizes the bordered pixels
bd_list_1 = [];
bd_list_2 = [];
for(var i = 0; i < array_length(bd_unordered_list_1); i++){
	array_push(bd_list_1,scr_walkabout_2(bd_unordered_list_1[i], sprite_get_width(_base_sprite) + x1_offset, sprite_get_height(_base_sprite) + y1_offset));
}

for(var i = 0; i < array_length(bd_unordered_list_2); i++){
	array_push(bd_list_2,scr_walkabout_2(bd_unordered_list_2[i], sprite_get_width(_transform_sprite) + x2_offset, sprite_get_height(_transform_sprite) + y2_offset));
}

//Pairs the points together to their closest neighbor
var height = max(sprite_get_height(_transform_sprite), sprite_get_height(_base_sprite));
var width = max(sprite_get_width(_transform_sprite), sprite_get_width(_base_sprite));

var final_array = [];
for(var i = 0; i < min(array_length(bd_list_1),array_length(bd_list_2)); i++){
	array_push(final_array, scr_pair_points_4(bd_list_1[i],bd_list_2[i],width/2,height/2));
}

return final_array;
}