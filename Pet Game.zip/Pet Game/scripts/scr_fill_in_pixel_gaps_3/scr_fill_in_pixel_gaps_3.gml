function scr_fill_in_pixel_gaps_3(_i, debug = false){
	while(!is_undefined(prev_x) and (abs(current_x - prev_x) > 1 or abs(current_y - prev_y) > 1)){
		var x_offset = 0;
		var y_offset = 0;
		if(floor(current_x) - floor(prev_x) > 1){
			x_offset = 1;
		}
		else if(floor(current_x) - floor(prev_x) < -1){
			x_offset = -1;
		}
		if(floor(current_y) - floor(prev_y) > 1){
			y_offset = 1;
		}
		else if(floor(current_y) - floor(prev_y) < -1){
			y_offset = -1;
		}
		if(debug) {
			show_debug_message("ADDING PIXEL GAP: " + string(prev_x + x_offset) + ", " + string(prev_y + y_offset));
			show_debug_message("CURRENT X AND Y: " + string(current_x) + ", " + string(current_y));
			show_debug_message("PREV X AND Y: " + string(prev_x) + ", " + string(prev_y));	
			show_debug_message("I: " + string(i));
			show_debug_message("====");
		}
		prev_x += x_offset;
		prev_y += y_offset;
		array_push(current_pixel_list,
			[prev_x, prev_y,
			make_color_rgb(
				(app_list[dir_i][sprite_num][_i][4][0] * (1-intensity) + app_list[dir_i][sprite_num][_i][5][0] * (intensity)),
				(app_list[dir_i][sprite_num][_i][4][1] * (1-intensity) + app_list[dir_i][sprite_num][_i][5][1] * (intensity)),
				(app_list[dir_i][sprite_num][_i][4][2] * (1-intensity) + app_list[dir_i][sprite_num][_i][5][2] * (intensity)))
			]);
	}
}