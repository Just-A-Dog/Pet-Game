{
  "$GMScript":"v1",
  "%Name":"scr_fill_in_pixel_gaps_3",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_fill_in_pixel_gaps_3",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}