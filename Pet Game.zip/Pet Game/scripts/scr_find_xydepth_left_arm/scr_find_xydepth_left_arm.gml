function scr_find_xydepth_left_arm(l_arm_type = left_arm_type){
	dir_i = array_get_index(global.dir, dir);
	if(variable_struct_exists(color_coords[dir_i], "255,128,255")){
		if(dir == "e" or dir == "se") left_arm_depth = -1;
		else left_arm_depth = 0;
		left_arm_sprite = variable_struct_get(l_arm_type,dir);
		left_arm_width = sprite_get_width(left_arm_sprite);
		left_arm_x = freak_id.x + variable_struct_get(color_coords[dir_i],"255,128,255")[0] - left_arm_width;
		left_arm_y = freak_id.y + variable_struct_get(color_coords[dir_i],"255,128,255")[1];
		invisible = false;
	}
	else{
		left_arm_x = 0;
		left_arm_y = 0;
		left_arm_depth = 0;
		invisible = true;
	}
}