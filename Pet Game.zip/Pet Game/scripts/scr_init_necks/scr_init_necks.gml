function scr_init_necks(){

}