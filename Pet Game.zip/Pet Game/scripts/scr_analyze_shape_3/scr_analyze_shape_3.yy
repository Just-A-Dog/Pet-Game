{
  "$GMScript":"v1",
  "%Name":"scr_analyze_shape_3",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_analyze_shape_3",
  "parent":{
    "name":"Body Part Init",
    "path":"folders/Current Scripts/Body Part Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}