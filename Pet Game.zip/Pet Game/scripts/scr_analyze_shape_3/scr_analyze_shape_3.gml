function scr_analyze_shape_3(sprite_to_analyze, xoffset = 0, yoffset = 0, _color_dict = {}){
	var w = sprite_get_width(sprite_to_analyze) + xoffset;
	var h = sprite_get_height(sprite_to_analyze) + yoffset;
	var boundary_pixels = [];

	var surf = surface_create(w, h);

	var pixels = [];

	for(var current_subimg = 0; current_subimg < sprite_get_number(sprite_to_analyze); current_subimg++){

	    surface_set_target(surf);
	    draw_clear_alpha(c_black, 0);

	    draw_sprite(sprite_to_analyze, current_subimg, 0, 0);

	    surface_reset_target();
	
		for (var py = 0; py < h; py++)
		{
		    pixels[py] = [];

		    for (var px = 0; px < w; px++)
		    {
				var pixel = surface_getpixel_ext(surf, px, py);

				// Get alpha
		        var alpha = (pixel >> 24) & 255;

		        pixels[py][px] = (alpha > 0);
		    }
		}

		for (var py = 0; py < h; py++)
		{
		    for (var px = 0; px < w; px++)
		    {
		        // Ignore transparent pixels
		        if (!pixels[py][px])
		            continue;

		        var boundary = false;

		        // North
		        if (py == 0 || !pixels[py - 1][px])
		            boundary = true;

		        // East
		        if (px == w - 1 || !pixels[py][px + 1])
		            boundary = true;

		        // South
		        if (py == h - 1 || !pixels[py + 1][px])
		            boundary = true;

		        // West
		        if (px == 0 || !pixels[py][px - 1])
		            boundary = true;

		        if (boundary)
		        {
					// Get the pixel's color
					var pixel = surface_getpixel_ext(surf, px, py);

					var red  = pixel & 255;
					var green = (pixel >> 8) & 255;
					var blue   = (pixel >> 16) & 255;
					var color_string = scr_color_to_string(red, green, blue);

					if(variable_instance_exists(_color_dict, color_string)){
						red = colour_get_red(variable_instance_get(_color_dict, color_string));
						green = colour_get_green(variable_instance_get(_color_dict, color_string));
						blue = colour_get_blue(variable_instance_get(_color_dict, color_string));
					}
		            boundary_pixels[current_subimg][array_length(boundary_pixels[current_subimg])] = [px + xoffset, py + yoffset, [red, green, blue]];
		        }
		    }
		}
	}
	surface_free(surf);
	return boundary_pixels;
}