{
  "$GMScript":"v1",
  "%Name":"scr_app_cache_load",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_app_cache_load",
  "parent":{
    "name":"Cache",
    "path":"folders/Current Scripts/Cache.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}