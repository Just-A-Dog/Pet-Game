function scr_app_cache_load() {
    global.app_cache = {};
    global.app_cache_dirty = false;
	
	var _path = working_directory + "app_cache.json";

    if (file_exists(_path)) {
        var _file = file_text_open_read(_path);
        var _json = "";

        while (!file_text_eof(_file)) {
            _json += file_text_read_string(_file);
            file_text_readln(_file);
        }

        file_text_close(_file);

        if (_json != "") {
            global.app_cache = json_parse(_json);
        }
    }
}
