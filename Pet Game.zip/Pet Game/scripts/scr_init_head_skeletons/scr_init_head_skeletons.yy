{
  "$GMScript":"v1",
  "%Name":"scr_init_head_skeletons",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_init_head_skeletons",
  "parent":{
    "name":"Init",
    "path":"folders/Current Scripts/Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}