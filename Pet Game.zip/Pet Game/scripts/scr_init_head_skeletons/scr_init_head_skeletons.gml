function scr_init_head_skeletons(){
	global.base_head_skeleton = {
		s : spr_base_s_skeleton_head,
		sw : spr_base_sw_skeleton_head,
		w : spr_base_w_skeleton_head,
		nw : spr_base_nw_skeleton_head,
		n : spr_base_n_skeleton_head,
		ne : spr_base_ne_skeleton_head,
		e : spr_base_e_skeleton_head,
		se : spr_base_se_skeleton_head,
	}

	global.raccoon_head_skeleton = {
		s : spr_raccoon_s_skeleton_head,
		sw : spr_raccoon_sw_skeleton_head,
		w : spr_raccoon_w_skeleton_head,
		nw : spr_raccoon_nw_skeleton_head,
		n : spr_raccoon_n_skeleton_head,
		ne : spr_raccoon_ne_skeleton_head,
		e : spr_raccoon_e_skeleton_head,
		se : spr_raccoon_se_skeleton_head,
	}
}