{
  "$GMScript":"v1",
  "%Name":"scr_draw_and_fill_in_sprite_2",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_draw_and_fill_in_sprite_2",
  "parent":{
    "name":"Outdated",
    "path":"folders/Current Scripts/Outdated.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}