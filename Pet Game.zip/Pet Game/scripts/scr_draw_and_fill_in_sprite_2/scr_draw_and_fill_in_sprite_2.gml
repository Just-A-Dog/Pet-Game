//Can I turn this into a mask somehow? It'd be cool to put in a texture or some shit idk
function scr_draw_and_fill_in_sprite_2(_boundary_pixels, _inner_color, _head_offset = infinity, x_offset = 0){
	draw_set_color(_inner_color);
	var arr_len = array_length(_boundary_pixels);
	//For each pixel we check the other pixels. Search for a pixel with the same x, and the lowest y.
	for(var _i = 0; _i < arr_len; _i++){
//		if(_i == 89) debug = true;
//		else 
			debug = false;
		if(debug){
			show_debug_message("HERE IS THE LIST OF PIXELS:");
			show_debug_message(_boundary_pixels);
			show_debug_message("THIS POINT");
			show_debug_message(_boundary_pixels[_i]);
		}

		//Finds previous point index
		if(_i - 1 >= 0) ppi = _i - 1;
		else ppi = arr_len - 1;
		
		//Keeps going back if the pixels are the same
		while(_boundary_pixels[ppi][0] == _boundary_pixels[_i][0] and _boundary_pixels[ppi][1] == _boundary_pixels[_i][1]){
			if(ppi - 1 >= 0) ppi--;
			else ppi = arr_len - 1;
		}
		
		//Finds next point index
		if(_i + 1 < arr_len) ni = _i + 1;
		else ni = 0;
		
		//Skip if this if the next one is the same as this one.
		if(_i + 1 < arr_len 
		and _boundary_pixels[_i][0] == _boundary_pixels[_i + 1][0] 
		and _boundary_pixels[_i][1] == _boundary_pixels[_i + 1][1]){
			if(debug)show_debug_message("Skipped because next pixel is the same as this one.");	
			continue;
		}		
		
		//If the next pixel in line is directly below this one.
		if(_boundary_pixels[ni][1] == _boundary_pixels[_i][1] + 1 
		and (_boundary_pixels[ni][0] == _boundary_pixels[_i][0] 
		or _boundary_pixels[ni][0] == _boundary_pixels[_i][0] - 1)){
			if(debug)show_debug_message("Skipped because next pixel is directly below this one.");
			continue;
		}	
		
		//Skip if previous point is not east nor is previous point above
		if(!(_boundary_pixels[_i][0] - 1 == _boundary_pixels[ppi][0] //The previous pixel comes from the west
		or _boundary_pixels[_i][1] - 1 == _boundary_pixels[ppi][1])){ //The previous pixel comes from the north
			if(debug)show_debug_message("Skipped because previous point is not east nor is previous point above.");
			continue;
		}		
		
		//Skip if previous point is above, and next pixel is to the left.
		if(_boundary_pixels[ppi][1] < _boundary_pixels[_i][1]
		and _boundary_pixels[ni][0] < _boundary_pixels[_i][0]){
			if(debug)show_debug_message("Skipped because previous pixel is above, and next pixel is to the west.");
			continue;
		}
		

		//Reset values
		var ypixeldist = 999;
		var bi = -1;
		var width = 0;

		if(_i - 1 >= 0) prev_i = _i - 1;
		else prev_i = arr_len - 1;


		//Finds the closest point below it.
		for(_j = 0; _j < arr_len; _j++){
			if(_boundary_pixels[_j][0] == _boundary_pixels[_i][0] //If the found pixel has the same x
			and ypixeldist > _boundary_pixels[_j][1] - _boundary_pixels[_i][1] //And its distance from y is smaller than the current distance from y
			and _boundary_pixels[_j][1] - _boundary_pixels[_i][1] > 1){ //And the pixel is lower than the current pixel
				ypixeldist = _boundary_pixels[_j][1] - _boundary_pixels[_i][1];
				bi = _j;
			}
		}

		if(debug) show_debug_message("Bottom index: " + string(bi));
		
		//If it finds the closest point below it, and the point isn't directly below it...		
		if(bi != -1 and !(_boundary_pixels[bi][0] == _boundary_pixels[_i][0] and _boundary_pixels[bi][1] == _boundary_pixels[_i][1] + 1)){
			if(_i + 1 != arr_len) ni = _i + 1;
			else ni = 0;
			var ci = _i;

			var top_width = 0;
			//While we stay on the same y row.
			while(_boundary_pixels[ni][1] == _boundary_pixels[ci][1]){
				//Increase width, if it is not the same exact pixel
				if(_boundary_pixels[ni][0] != _boundary_pixels[ci][0]) {
					if(debug){
						show_debug_message("ADDING TOP_WIDTH");
						show_debug_message(_boundary_pixels[ci][0]);
						show_debug_message(_boundary_pixels[ni][0]);
					}
					top_width++;
				}

				//Increment
				if(ci + 1 < arr_len) ci++;
				else ci = 0;
				if(ni + 1 < arr_len) ni++;
				else ni = 0;				
			}
							
			//Keep going east. Since these are assumedly bottom pixels, we iterate backwards through the array.
			//Skip check if bottom pixel does not go east at all.
			if(bi - 1 >= 0) prev_i = bi - 1;
			else prev_i = arr_len - 1;

			ci = bi;
			var bottom_width = 0;
			
			//While we stay on the same y row.
			while(_boundary_pixels[prev_i][1] == _boundary_pixels[ci][1]){				
				//Increase width, if it is not the same exact pixel
				if(_boundary_pixels[prev_i][0] != _boundary_pixels[ci][0]) bottom_width++;

				//Decrement
				if(prev_i - 1 >= 0) prev_i--;
				else prev_i = arr_len - 1;
				if(ci - 1 >= 0) ci--;
				else ci = arr_len - 1;
			}

			//Width is the minimum of bottom_width or top_width, with the maximum being 1.
			width = max(min(bottom_width, top_width), 1);

			//if(debug){
				show_debug_message("TOP WIDTH: " + string(top_width));
				show_debug_message("BOTTOM WIDTH: " + string(bottom_width));
				show_debug_message("Width: " + string(width));
				show_debug_message("COORDS: " + string(_boundary_pixels[_i]));
				show_debug_message("X1: " + string(_boundary_pixels[_i][0]));
				show_debug_message("Y1: " + string(_boundary_pixels[_i][1]));
				show_debug_message("X2: " + string(_boundary_pixels[_i][0] + width));
				show_debug_message("Y2: " + string(_boundary_pixels[bi][1]));		
			show_debug_message("=====");
			//}
			//To make sure that the bottom of the head isn't drawn if head is low enough.
			var y2 = min(_boundary_pixels[bi][1], _head_offset);
			draw_rectangle(x + (_boundary_pixels[_i][0]) - 1, y + _boundary_pixels[_i][1], x + (_boundary_pixels[_i][0] + width) - 1, y + y2,0);
		}
		//else show_debug_message("Pixel somehow does not have a bottom pixel, despite fitting the proper criteria of having one.");
	}
}