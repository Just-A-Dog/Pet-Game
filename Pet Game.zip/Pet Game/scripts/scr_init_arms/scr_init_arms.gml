function scr_init_arms(){
	global.base_right_arm = {
		s : spr_base_s_idle_arm,
		sw : spr_base_sw_idle_arm,
		w : spr_base_w_idle_arm,
		nw : spr_base_sw_idle_arm_r,
		n : spr_base_s_idle_arm_r,
		ne : spr_base_s_idle_arm_r,
		e : spr_base_w_idle_arm,
		se : spr_base_sw_idle_arm,		
	}

	global.base_left_arm = { 
		s : spr_base_s_idle_arm_r,
		sw : spr_base_sw_idle_arm_r,
		w : spr_base_w_idle_arm,
		nw : spr_base_s_idle_arm,
		n : spr_base_s_idle_arm,
		ne : spr_base_sw_idle_arm,
		e : spr_base_w_idle_arm,
		se : spr_base_sw_idle_arm_r,		
	}
}