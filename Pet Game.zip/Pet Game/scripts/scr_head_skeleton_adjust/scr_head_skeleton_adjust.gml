function scr_head_skeleton_adjust(_head_skeleton){
	show_debug_message("ADJUSTING HEAD SKELETON");
	_head_skeleton.current_list = [];
	_head_skeleton.dir_i = array_get_index(global.dir, dir);
	for(var i = 0; i < array_length(_head_skeleton.app_list[_head_skeleton.dir_i]); i++){
		array_push(_head_skeleton.current_list,
		[lerp(_head_skeleton.app_list[_head_skeleton.dir_i][i][0], _head_skeleton.app_list[_head_skeleton.dir_i][i][2], _head_skeleton.intensity),
			lerp(_head_skeleton.app_list[_head_skeleton.dir_i][i][1], _head_skeleton.app_list[_head_skeleton.dir_i][i][3], _head_skeleton.intensity),
			_head_skeleton.app_list[_head_skeleton.dir_i][i][4]]);
	}

	
	_head_skeleton.half_width = sprite_get_width(variable_struct_get(global.base_head_skeleton, dir)) / 2;
	_head_skeleton.height = sprite_get_height(variable_struct_get(global.base_head_skeleton, dir));
	
	//Update x and y based on position of red in self.
	for(var i = 0; i < array_length(self.current_list); i++){
		if(self.current_list[i][2] == _head_skeleton.location_color){
			_head_skeleton.x = self.current_list[i][0] - _head_skeleton.half_width + self.x;
			_head_skeleton.y = self.current_list[i][1] - _head_skeleton.height + self.y + 1;
		}
	}
}