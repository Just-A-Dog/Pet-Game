{
  "$GMScript":"v1",
  "%Name":"scr_head_skeleton_adjust",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_head_skeleton_adjust",
  "parent":{
    "name":"Skeleton Stuff",
    "path":"folders/Current Scripts/Skeleton Stuff.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}