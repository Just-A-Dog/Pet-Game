{
  "$GMScript":"v1",
  "%Name":"scr_get_cache_key_2",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_get_cache_key_2",
  "parent":{
    "name":"Cache",
    "path":"folders/Current Scripts/Cache.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}