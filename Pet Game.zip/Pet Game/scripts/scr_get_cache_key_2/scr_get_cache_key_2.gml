function scr_get_cache_key_2(_key){
	switch(_key){
		case(global.base_body): return "base_body";
		case(global.base_head): return "base_head";
		case(global.base_left_arm): return "base_left_arm";
		case(global.base_left_ear): return "base_left_ear";
		case(global.base_left_eye): return "base_left_eye";
		case(global.base_left_eyebrow): return "base_left_eyebrow";
		case(global.base_left_leg): return "base_left_leg";
		case(global.base_right_arm): return "base_right_arm";
		case(global.base_right_ear): return "base_right_ear";
		case(global.base_right_eye): return "base_right_eye";
		case(global.base_right_eyebrow): return "base_right_eyebrow";
		case(global.base_right_leg): return "base_right_leg";
		case(global.base_mouth): return "base_mouth";
		case(global.base_nose): return "base_nose";

		case(global.raccoon_head): return "raccoon_head";		
		case(global.circle_body): return "circle_body";
		default: show_debug_message(string(_key) + " does not have a key registered. Go to scr_get_cache_key_helper and input it, or fix it.");
	}
}