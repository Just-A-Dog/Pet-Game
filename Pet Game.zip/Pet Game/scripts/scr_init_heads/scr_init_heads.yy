{
  "$GMScript":"v1",
  "%Name":"scr_init_heads",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_init_heads",
  "parent":{
    "name":"Init",
    "path":"folders/Current Scripts/Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}