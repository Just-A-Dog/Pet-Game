function scr_init_heads(){
	global.raccoon_head = {
		s : spr_raccoon_s_idle_head,
		sw : spr_raccoon_sw_idle_head,
		w : spr_raccoon_w_idle_head,
		nw : spr_raccoon_sw_idle_head,
		n : spr_raccoon_s_idle_head_r,
		ne : spr_raccoon_sw_idle_head_r,
		e : spr_raccoon_w_idle_head_r,
		se : spr_raccoon_sw_idle_head_r,	
	}
	
	global.base_head = {
		s : spr_base_s_idle_head,
		sw : spr_base_sw_idle_head,
		w : spr_base_sw_idle_head,
		nw : spr_base_sw_idle_head,
		n : spr_base_s_idle_head,
		ne : spr_base_sw_idle_head_r,
		e : spr_base_sw_idle_head_r,
		se : spr_base_sw_idle_head_r,
	}
}