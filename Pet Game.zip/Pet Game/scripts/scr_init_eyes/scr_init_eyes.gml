function scr_init_eyes(){
	global.base_left_eye = {
		s : spr_base_s_idle_eye,
		sw : spr_base_s_idle_eye, 
		w : -1,
		nw : -1,
		n : -1,
		ne : -1,
		e : spr_base_s_idle_eye,
		se : spr_base_s_idle_eye
	}

	global.base_right_eye = {
		s : spr_base_s_idle_eye,
		sw : spr_base_s_idle_eye,
		w : spr_base_s_idle_eye,
		nw : -1,
		n : -1,
		ne : -1,
		e : -1,
		se : spr_base_s_idle_eye,
	}
}