{
  "$GMScript":"v1",
  "%Name":"scr_init_eyes",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_init_eyes",
  "parent":{
    "name":"Init",
    "path":"folders/Current Scripts/Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}