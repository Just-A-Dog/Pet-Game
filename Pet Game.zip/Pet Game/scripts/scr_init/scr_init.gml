function scr_init(){
	window_set_fullscreen(true);
	gpu_set_texfilter(false); //Makes pixels look crisp
	scr_app_cache_load(); //Loads each possible app_list
	
	global.dir = ["s", "sw", "w", "nw", "n", "ne", "e", "se"];
	
	scr_init_heads();
	scr_init_head_skeletons();
	scr_init_bodies();
	scr_init_body_skeletons();
	scr_init_eyebrows();
	scr_init_arms();
	scr_init_legs();
	scr_init_snouts();
	scr_init_eyes();
	scr_init_ears();
	scr_init_horns();
	scr_init_necks();
	scr_init_tails();
	scr_init_noses();
	scr_init_mouths();
	scr_init_colors();
	
	instance_create_depth(mouse_x,mouse_y,0,obj_cursor);
}