{
  "$GMScript":"v1",
  "%Name":"scr_init",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_init",
  "parent":{
    "name":"Init",
    "path":"folders/Current Scripts/Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}