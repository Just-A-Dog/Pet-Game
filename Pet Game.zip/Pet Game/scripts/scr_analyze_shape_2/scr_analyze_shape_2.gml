function scr_analyze_shape_2(sprite_to_analyze){
	var w = sprite_get_width(sprite_to_analyze);
	var h = sprite_get_height(sprite_to_analyze);

	var surf = surface_create(w, h);

	surface_set_target(surf);
	draw_clear_alpha(c_white, 0);
	draw_sprite(sprite_to_analyze, 0, 0, 0);
	surface_reset_target();

	var black_pixels = [];

	surface_set_target(surf);

	for (var py = 0; py < h; py++)
	{
	    for (var px = 0; px < w; px++)
	    {
	        var pixel = surface_getpixel(surf, px, py);

	        var red   = (pixel >> 16) & 255;
	        var green = (pixel >> 8) & 255;
	        var blue  = pixel & 255;

	        if (red == 0 && green == 0 && blue == 0)
	        {
	            black_pixels[array_length(black_pixels)] = [px, py];
	        }
	    }
	}

	surface_reset_target();
	surface_free(surf);

	return black_pixels;
}