function scr_update_freak(_freak_id = self){
	dir_i = array_get_index(global.dir, dir);	
	scr_update_body_skeleton(_freak_id.body_skeleton);
	scr_update_head_skeleton(_freak_id.head_skeleton);
	scr_update_arm(_freak_id.right_arm);
	scr_update_arm(_freak_id.left_arm);
	scr_update_body(_freak_id.body);
	scr_update_eye(_freak_id.right_eye);
	scr_update_eye(_freak_id.left_eye);
	scr_update_head(_freak_id.head);
	scr_update_leg(_freak_id.right_leg);
	scr_update_leg(_freak_id.left_leg);
	scr_update_snout(_freak_id.snout);
	scr_update_nose(_freak_id.nose);
	scr_update_mouth(_freak_id.mouth);
	scr_update_ear(_freak_id.left_ear);
	scr_update_ear(_freak_id.right_ear);
	scr_update_tail(_freak_id.tail);
}