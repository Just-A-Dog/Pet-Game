function scr_change_directions(_freak, _dir){
	_freak.body.dir = _dir;
	_freak.body.left_arm.dir = _dir;
	_freak.body.right_arm.dir = _dir;
	_freak.body.left_leg.dir = _dir;
	_freak.body.right_leg.dir = _dir;
	_freak.head.dir = _dir;
	_freak.head.chin.dir = _dir;
	_freak.head.left_eye.dir = _dir;
	_freak.head.right_eye.dir = _dir;
	_freak.head.left_eyebrow.dir = _dir;
	_freak.head.right_eyebrow.dir = _dir;
	_freak.head.mouth.dir = _dir;
}