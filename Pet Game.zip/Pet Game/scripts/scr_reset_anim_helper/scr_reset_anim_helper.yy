{
  "$GMScript":"v1",
  "%Name":"scr_reset_anim_helper",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_reset_anim_helper",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}