function scr_reset_anim_helper(_){
	_.x = _.x_orig;
	_.y = _.y_orig;
}