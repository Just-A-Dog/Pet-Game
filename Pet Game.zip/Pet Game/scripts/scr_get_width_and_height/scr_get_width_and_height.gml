//Returns the width and height of a list of points: [Width, Height]
function scr_get_width_and_height(_points_list){
	var _x1 = 1000;
	var _x2 = -1;
	var _y1 = 1000;
	var _y2 = -1;
	for(var _i = 0; _i < array_length(_points_list); _i++){
		_x1 = min(_points_list[_i][0], _x1);
		_x2 = max(_points_list[_i][0], _x2);
		_y1 = min(_points_list[_i][1], _y1);
		_y2 = max(_points_list[_i][1], _y2);
	}
	var width = _x2 - _x1;
	var height = _y2 - _y1;
	return [_x2 - _x1,_y2 - _y1];
}