function scr_create_freak(data){
	_ = instance_create_depth(x,y,0,obj_freak,
	/*{
		base_color : data.base_color,
		tertiary_color : data.tertiary_color,
		head_type : data.head_type,
		head_intensity : data.head_intensity,
		left_eye_type : data.left_eye_type,
		right_eye_type : data.right_eye_type,
		left_eyebrow_type: data.left_eyebrow_type,
		right_eyebrow_type: data.right_eyebrow_type,
		nose_type : data.nose_type,
		mouth_type : data.mouth_type,
		chin_type : data.chin_type,
		
		body_type : data.body_type,
		body_intensity : data.body_intensity,
		right_arm_type : data.right_arm_type,
		left_arm_type : data.left_arm_type,
		arm_intensity : data.arm_intensity,
		
		left_leg_type : data.left_leg_type,
		right_leg_type : data.right_leg_type,
		leg_intensity : data.leg_intensity
	});*/
	{
		data : data
	});
	return _;
}