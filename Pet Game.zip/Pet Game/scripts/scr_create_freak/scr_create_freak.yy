{
  "$GMScript":"v1",
  "%Name":"scr_create_freak",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_create_freak",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}