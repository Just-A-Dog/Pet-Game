function scr_update_body_skeleton(_id){
	_id.dir_i = dir_i;
	var current_list = [];
	var app_list = _id.app_list;
	var intensity = _id.freak_id.body_intensity;
	
	for(var i = 0; i < array_length(app_list[dir_i]); i++){
		array_push(current_list,
		[lerp(app_list[dir_i][i][0], app_list[dir_i][i][2], intensity),
			lerp(app_list[dir_i][i][1], app_list[dir_i][i][3], intensity),
			app_list[dir_i][i][4]]);
	}
	
	_id.freak_id.head.head_offset = floor(_id.max_head_offset[dir_i] * intensity);
	_id.current_list = current_list;
}