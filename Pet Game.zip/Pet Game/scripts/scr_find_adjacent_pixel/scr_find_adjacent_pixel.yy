{
  "$GMScript":"v1",
  "%Name":"scr_find_adjacent_pixel",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_find_adjacent_pixel",
  "parent":{
    "name":"Body Part Init",
    "path":"folders/Current Scripts/Body Part Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}