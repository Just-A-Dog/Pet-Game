function find_adjacent_pixel(pixel_array, px, py){
	/*if(px == 21 and py == 1) {
		show_debug_message("WHAT THE FUCK???");
		show_debug_message(pixel_array);
		debug = true;
	}
	else */
		debug = false;
	
	for(i = 0; i < array_length(pixel_array); i++){
		if(debug){
			show_debug_message(pixel_array[i]);
			show_debug_message(i);
			show_debug_message("=========");
		}
		if(pixel_array[i][0] == px and pixel_array[i][1] == py) return true;
	}
	return false;
}