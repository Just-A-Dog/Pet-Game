function scr_init_legs(){
	global.base_right_leg = {
		s : spr_base_s_idle_leg,
		sw : spr_base_s_idle_leg,
		w : spr_base_w_idle_leg,
		nw : spr_base_s_idle_leg_r,
		n : spr_base_s_idle_leg_r,
		ne : spr_base_s_idle_leg,
		e : spr_base_w_idle_leg_r,
		se : spr_base_s_idle_leg,		
	}

	global.base_left_leg = {
		s : spr_base_s_idle_leg_r,
		sw : spr_base_s_idle_leg_r,
		w : spr_base_w_idle_leg,
		nw : spr_base_s_idle_leg_r,
		n : spr_base_s_idle_leg,
		ne : spr_base_s_idle_leg,
		e : spr_base_w_idle_leg_r,
		se : spr_base_s_idle_leg_r,		
	}
}