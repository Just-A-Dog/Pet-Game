function scr_anim_idle(_freak = self){
	if(!variable_instance_exists(_freak, "_step")) _step = 0;
	switch(_step){
		case(0):
			scr_head_move(0,1);
			body.y++;
			body.arms.y++;
			break;

		case(20): 
			scr_head_move(0,1);
			break;

		case(40): 
			scr_head_move(0,-1);
			body.y--;
			body.arms.y--;
			break;

		case(60): 
			scr_head_move(0,-1);
			break;

		case(80):
			_step = -1;
			break;
	}
	_step++;
}