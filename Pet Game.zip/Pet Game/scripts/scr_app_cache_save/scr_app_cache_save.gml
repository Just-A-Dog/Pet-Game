function scr_app_cache_save() {
    if (!global.app_cache_dirty) {
        return;
    }

	var _path = working_directory + "app_cache.json";
    var _file = file_text_open_write(_path);

    file_text_write_string(
        _file,
        json_stringify(global.app_cache)
    );

    file_text_close(_file);

    global.app_cache_dirty = false;
}