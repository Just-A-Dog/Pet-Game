{
  "$GMScript":"v1",
  "%Name":"scr_app_cache_save",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_app_cache_save",
  "parent":{
    "name":"Cache",
    "path":"folders/Current Scripts/Cache.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}