//Takes two lists of pixels, and associates each pixel with the closest one on the other list.
function scr_pair_points_2(cp_1, cp_2){
	//Swaps arrays if the longer one is second.
	if(array_length(cp_2) > array_length(cp_1)){
		arrays_swapped = true;
		temp = cp_1;
		cp_1 = cp_2;
		cp_2 = temp;
	}
	else arrays_swapped = false;

	//First we iterate through the two to find the shortest distance between two points
	sp_1 = 0;
	sp_2 = 0;
	cp_1_points_left = array_length(cp_1) - 1; //- 1 because the first two points are automatically assigned.
	cp_2_points_left = array_length(cp_2) - 1;
	
	minimum_distance = 999;
	for(var i = 0; i < array_length(cp_1); i++){
		for(j = 0; j < array_length(cp_2); j++){
			distance = point_distance(cp_1[i][0], cp_1[i][1], cp_2[j][0], cp_2[j][1]);
			if(distance < minimum_distance){
				minimum_distance = distance;
				sp_1 = i;
				sp_2 = j;
			}
		}
	}
		
	//After finding the shortest distance we start with adding the two into the final array
	if(!arrays_swapped) final_array = [[cp_1[sp_1][0], cp_1[sp_1][1], cp_2[sp_2][0], cp_2[sp_2][1], cp_1[sp_1][2], cp_2[sp_2][2]]];
	else final_array = [[cp_2[sp_2][0], cp_2[sp_2][1], cp_1[sp_1][0], cp_1[sp_1][1], cp_2[sp_2][2], cp_1[sp_1][2]]];
	if(array_length(cp_1) != sp_1 + 1) cpi1 = sp_1 + 1;
	else cpi1 = 0;

	prev_point_index = sp_2;
	if(array_length(cp_2) != sp_2 + 1) cpi2 = sp_2 + 1;
	else cpi2 = 0;

	//Iterates through the larger array until it hits the original point again.
	while(cpi1 != sp_1){
		distance_from_new_point = point_distance(cp_1[cpi1][0], cp_1[cpi1][1], cp_2[cpi2][0], cp_2[cpi2][1]);
		distance_from_prev_point = point_distance(cp_1[cpi1][0], cp_1[cpi1][1], cp_2[prev_point_index][0], cp_2[prev_point_index][1]);

		//We also need to check for the remaining points in cp_2. If there is an equal number of remaining points, then we just assign them to each next cp_1
		//The new large array point is closer to the new smaller array point, rather than the older array point.
		//Also automatically goes to the next one if there aren't enough points left.
		if(distance_from_new_point <= distance_from_prev_point or cp_1_points_left == cp_2_points_left){
			if(!arrays_swapped) array_push(final_array, [cp_1[cpi1][0], cp_1[cpi1][1], cp_2[cpi2][0], cp_2[cpi2][1], cp_1[cpi1][2], cp_2[cpi2][2]]);
			else array_push(final_array, [cp_2[cpi2][0], cp_2[cpi2][1], cp_1[cpi1][0], cp_1[cpi1][1], cp_2[cpi2][2], cp_1[cpi1][2]]);

			//Updates comparison point
			prev_point_index = cpi2;
			if(array_length(cp_2) != cpi2 + 1) cpi2++;
			else cpi2 = 0;			
			cp_2_points_left--;
		}
		else{
			if(!arrays_swapped) array_push(final_array, [cp_1[cpi1][0], cp_1[cpi1][1], cp_2[prev_point_index][0], cp_2[prev_point_index][1], cp_1[cpi1][2], cp_2[prev_point_index][2]]);
			else array_push(final_array, [cp_2[prev_point_index][0], cp_2[prev_point_index][1], cp_1[cpi1][0], cp_1[cpi1][1], cp_2[prev_point_index][2], cp_1[cpi1][2]]);
		}

	if(array_length(cp_1) != cpi1 + 1) cpi1++;
	else cpi1 = 0;
	
	cp_1_points_left--;
	}

	return final_array;
}