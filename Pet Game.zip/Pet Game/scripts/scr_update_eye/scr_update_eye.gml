function scr_update_eye(_id){
	_id.dir_i = dir_i;
	var found = false;
	//Adjust x and y co-ordinates of eyes
	var skeleton = _id.freak_id.head_skeleton;
	for(var i = 0; i < array_length(skeleton.current_list); i++){
		if(skeleton.current_list[i][2] == _id.location_color){
			_id.x = skeleton.current_list[i][0] + skeleton.x;
			_id.y = skeleton.current_list[i][1] + skeleton.y - sprite_get_height(variable_instance_get(_id.eye_type, global.dir[dir_i]));
			if(_id.left) {
				_id.freak_id.left_eyebrow.x = _id.x - sprite_get_width(variable_instance_get(_id.freak_id.left_eyebrow.eyebrow_type, global.dir[dir_i]));
				_id.freak_id.left_eyebrow.y = _id.y - 2;
				_id.x -= sprite_get_width(variable_instance_get(_id.eye_type,global.dir[dir_i]));
			}
			else {
				_id.freak_id.right_eyebrow.x = _id.x;
				_id.freak_id.right_eyebrow.y = _id.y - 2;
			}
			found = true;
			_id.invisible = false;
			if(_id.left) {
				_id.freak_id.left_eyebrow.invisible = false;
				_id.freak_id.left_eyebrow.dir_i = dir_i;
			}
			else {
				_id.freak_id.right_eyebrow.invisible = false;
				_id.freak_id.right_eyebrow.dir_i = dir_i;
			}
			break;
		}
	}
	if(!found) {
		_id.invisible = true;
		if(_id.left) _id.freak_id.left_eyebrow.invisible = true;
		else _id.freak_id.right_eyebrow.invisible = true;
	}
	if(_id.left){
		if(_id.freak_id.dir == "s" or _id.freak_id.dir == "sw") _id.depth = _id.freak_id.depth - 2;
		else _id.depth = _id.freak_id.depth - 4;
	}
	else{
		if(_id.freak_id.dir == "s" or _id.freak_id.dir == "se") _id.depth = _id.freak_id.depth - 2;
		else _id.depth = _id.freak_id.depth - 4;
	}
}