{
  "$GMScript":"v1",
  "%Name":"scr_check_change_sprite",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_check_change_sprite",
  "parent":{
    "name":"Update current pixel list",
    "path":"folders/Current Scripts/Update current pixel list.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}