//Updates current pixel list.
//NOTE: I know the return statements look weird, but it only returns true if the direction has changed so it can update co-ordinates.
//If intensity changes then it doesn't matter.
function scr_check_change_sprite(app_list){
	if(intensity != prev_intensity or dir != prev_dir){
		_ = app_list[array_get_index(global.dir,dir)];
		if(_ == -1) current_pixel_list = -1;
		else current_pixel_list = scr_current_point_list(_, intensity);
		if(intensity != prev_intensity) prev_intensity = intensity;
		if(dir != prev_dir){
			prev_dir = dir;
			return true;
		}
	}
	return false;
}