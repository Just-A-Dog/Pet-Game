function scr_draw_sprite(_points, _x, _y){
	for(_i = 0; _i < array_length(_points); _i++){
		draw_set_color(_points[_i][2]);
		draw_point(_x + _points[_i][0], _y + _points[_i][1])	;
	}
}