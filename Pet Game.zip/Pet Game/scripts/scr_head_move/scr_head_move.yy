{
  "$GMScript":"v1",
  "%Name":"scr_head_move",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_head_move",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}