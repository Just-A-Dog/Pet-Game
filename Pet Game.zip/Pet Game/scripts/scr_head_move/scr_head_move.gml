function scr_head_move(_x, _y){
	head.y += _y;
	head.x += _x;

	head.r_eye.y += _y;
	head.r_eye.x += _x;

	head.l_eye.y += _y;
	head.l_eye.x += _x;

	head.r_eyebrow.y += _y;
	head.r_eyebrow.x += _x;

	head.l_eyebrow.y += _y;
	head.l_eyebrow.x += _x;

	head.mouth.y += _y;
	head.mouth.x += _x;
	
	head.nose.y += _y;
	head.nose.x += _x;
	
	head.l_ear.y += _y;
	head.l_ear.x += _x;
	
	head.r_ear.y += _y;
	head.r_ear.x += _x;
	
	head.chin.y += _y;
	head.chin.x += _x;
	
}