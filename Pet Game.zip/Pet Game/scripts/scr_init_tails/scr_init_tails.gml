function scr_init_tails(){
	global.base_tail = {
		y_adj : {
			n : [4], //<- Adjusts y [down 4 pixels], for the first sprite in the north facing position.
		},
		s : spr_tail_base_s,
		sw : spr_tail_base_s,
		w : spr_tail_base_s,
		nw : spr_tail_base_s,
		n : spr_tail_base_s,
		ne : spr_tail_base_s,
		e : spr_tail_base_s,
		se : spr_tail_base_s,
	}
	
	global.raccoon_tail = {
		s : spr_tail_raccoon_n,
		sw : spr_tail_raccoon_ne_r,
		w : spr_tail_raccoon_e_r,
		nw : spr_tail_raccoon_ne_r,
		n : spr_tail_raccoon_n,
		ne : spr_tail_raccoon_ne,
		e : spr_tail_raccoon_e,
		se : spr_tail_raccoon_ne,	
	}
}