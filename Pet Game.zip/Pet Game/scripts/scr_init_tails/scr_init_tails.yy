{
  "$GMScript":"v1",
  "%Name":"scr_init_tails",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_init_tails",
  "parent":{
    "name":"Init",
    "path":"folders/Current Scripts/Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}