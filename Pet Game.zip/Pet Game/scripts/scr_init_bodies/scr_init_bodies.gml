function scr_init_bodies(){
	global.base_body = {
		s : spr_base_s_idle_body,
		sw : spr_base_sw_idle_body,
		w : spr_base_w_idle_body,
		nw : spr_base_sw_idle_body_r,
		n : spr_base_s_idle_body,
		ne : spr_base_sw_idle_body,
		e : spr_base_w_idle_body_r,
		se : spr_base_sw_idle_body_r,		
	}
	
	global.circle_body = {
		s : spr_circle_s_idle_body,
		sw : spr_circle_sw_idle_body,
		w : spr_circle_w_idle_body,
		nw : spr_circle_sw_idle_body_r,
		n : spr_circle_s_idle_body,
		ne : spr_circle_sw_idle_body,
		e : spr_circle_w_idle_body_1,
		se : spr_circle_sw_idle_body_r,
	}

}