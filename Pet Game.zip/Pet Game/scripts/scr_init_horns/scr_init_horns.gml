function scr_init_horns(){

}