{
  "$GMScript":"v1",
  "%Name":"scr_triangle_area",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_triangle_area",
  "parent":{
    "name":"Body Part Init",
    "path":"folders/Current Scripts/Body Part Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}