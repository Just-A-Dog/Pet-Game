function scr_fill_in_pixel_gaps(xdiff, ydiff, cpli, current_pixel_list, medium_pixel_x, medium_pixel_y){
		tx = 0;
		ty = 0;		
		count = 0;
		do{			
			if(xdiff > 1){
				tx--;
				xdiff--;
			}
			else if(xdiff < -1){
				tx++;
				xdiff++;
			}
			if(ydiff > 1){
				ty--;
				ydiff--;
			}
			else if(ydiff < -1){
				ty++;
				ydiff++;
			}
			array_insert(current_pixel_list, cpli, [medium_pixel_x - tx, medium_pixel_y - ty, current_pixel_list[cpli][2]]);
			count++;
		}until(xdiff <= 1 and xdiff >= -1 and ydiff <= 1 and ydiff >= -1);
		return count;
}