{
  "$GMScript":"v1",
  "%Name":"scr_fill_in_pixel_gaps",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_fill_in_pixel_gaps",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}