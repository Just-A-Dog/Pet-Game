function sprite_to_pixels(_sprite)
{
    var sprite_w = sprite_get_width(_sprite);
    var sprite_h = sprite_get_height(_sprite);

    var pixels = array_create(sprite_w);

    for (var px = 0; px < sprite_w; px++)
    {
        pixels[px] = array_create(sprite_h, false);
    }

    // We'll fill this in with the actual
    // sprite pixel-reading method.

    return pixels;
}