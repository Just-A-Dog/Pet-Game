function scr_init_colors(){
	global.colors = {
        BLACK: make_color_rgb(27,25,27),
        DARKGRAY: make_color_rgb(136,131,131),
		LIGHTGRAY: make_color_rgb(201,191,192),
		WHITE: make_color_rgb(254,252,252),

        DARKRED: make_color_rgb(96,6,47),
        MIDRED: make_color_rgb(133, 10, 51),
        RED: make_color_rgb(219, 51, 51),
		PINK: make_color_rgb(255,128,130),
		
		DARKBROWN: make_color_rgb(81,34,20),
		BROWN: make_color_rgb(143,66,20),
		ORANGE: make_color_rgb(248,128,84),
		LIGHTORANGE: make_color_rgb(255,230,180),
		
		DARKGOLD: make_color_rgb(213,140,1),
		GOLD: make_color_rgb(255,208,15),
		YELLOW: make_color_rgb(255,245,15),
		LIGHTYELLOW: make_color_rgb(255,255,156),
		
		DARKGREEN: make_color_rgb(53,74,48),
		MIDGREEN: make_color_rgb(88,141,73),
		GREEN: make_color_rgb(67,230,25),
		LIGHTGREEN: make_color_rgb(168,242,130),
		
		DARKCYAN: make_colour_rgb(17,63,85),
		MIDCYAN: make_color_rgb(18,130,155),
		CYAN: make_color_rgb(40,225,250),
		LIGHTCYAN: make_color_rgb(198,239,235),
		
		DARKBLUE: make_color_rgb(26,12,95),
		MIDBLUE: make_color_rgb(43,28,156),
		BLUE: make_color_rgb(60,46,210),
		LIGHTBLUE: make_color_rgb(103,106,228),
		
		DARKPURPLE: make_color_rgb(66,17,79),
		MIDPURPLE: make_color_rgb(78,25,112),
		PURPLE: make_color_rgb(143,54,204),
		LIGHTPURPLE: make_color_rgb(206,153,215)
    };

}