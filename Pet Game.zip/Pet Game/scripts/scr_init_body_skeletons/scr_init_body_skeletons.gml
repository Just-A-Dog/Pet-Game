function scr_init_body_skeletons(){
	global.circle_body_skeleton = {
		s : spr_circle_s_skeleton_body,
		sw : spr_circle_sw_skeleton_body,
		w : spr_circle_w_skeleton_body,
		nw : spr_circle_nw_skeleton_body,
		n : spr_circle_n_skeleton_body,
		ne : spr_circle_ne_skeleton_body,
		e : spr_circle_e_skeleton_body,
		se : spr_circle_se_skeleton_body,
		max_head_offset : [3,4,2,3,3,3,2,4]
	}

	global.base_body_skeleton = {
		s : spr_base_s_skeleton_body,
		sw : spr_base_sw_skeleton_body,
		w : spr_base_w_skeleton_body,
		nw : spr_base_nw_skeleton_body,
		n : spr_base_n_skeleton_body,
		ne : spr_base_ne_skeleton_body,
		e : spr_base_e_skeleton_body,
		se : spr_base_se_skeleton_body,
	}
}