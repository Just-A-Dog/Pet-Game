{
  "$GMScript":"v1",
  "%Name":"scr_current_point_list",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_current_point_list",
  "parent":{
    "name":"Update current pixel list",
    "path":"folders/Current Scripts/Update current pixel list.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}