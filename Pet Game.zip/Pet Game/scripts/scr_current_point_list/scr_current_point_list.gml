function scr_current_point_list(_app_list, _intensity){
	_current_pixel_list = [];
	_cpli = 0;
	for(_i = 0; _i < array_length(_app_list); _i++){
		_medium_pixel_x = round(lerp(_app_list[_i][0], _app_list[_i][2], _intensity));
		_medium_pixel_y = round(lerp(_app_list[_i][1], _app_list[_i][3], _intensity)); 
		//Check to see if there is a gap between pixels now. [Before and after.]
		//Add pixel in, colored exact middle between two pixels.
		//Keep running until it runs out of space between the two pixels.

		_current_pixel_list[_cpli] = [_medium_pixel_x, _medium_pixel_y, scr_intensify_colors(_app_list[_i][4], _app_list[_i][5], _intensity)];

		//Is there a space greater than 1 between this pixel and the pixel beforehand? If so, we create some new pixels to take the place.
		if(_i != 0){
			_xdiff = _current_pixel_list[_cpli - 1][0] - _current_pixel_list[_cpli][0];
			_ydiff = _current_pixel_list[_cpli - 1][1] - _current_pixel_list[_cpli][1];
			if(_xdiff > 1 or _xdiff < -1 or _ydiff > 1 or _ydiff < -1){
				_cpli += scr_fill_in_pixel_gaps(_xdiff, _ydiff, _cpli, _current_pixel_list, _medium_pixel_x, _medium_pixel_y);
			}
		}

		//Last pixel in the list checks for gaps between itself and the first pixel.
		//Acts as if 0 index pixel is checking behind itself.
		if(_i == array_length(_app_list) - 1){
			_xdiff = _current_pixel_list[_cpli][0] - _current_pixel_list[0][0];
			_ydiff = _current_pixel_list[_cpli][1] - _current_pixel_list[0][1];
			if(_i != 0 and (_xdiff > 1 or _xdiff < -1 or _ydiff > 1 or _ydiff < -1)){
				scr_fill_in_pixel_gaps(_xdiff, _ydiff, 0, _current_pixel_list, _medium_pixel_x, _medium_pixel_y);
			}
		}
		_cpli++;
	}
	return _current_pixel_list;
}