function sprite_to_polygon(_sprite)
{
    var sprite_w = sprite_get_width(_sprite);
    var sprite_h = sprite_get_height(_sprite);

    // -------------------------------------------------
    // Create temporary surface
    // -------------------------------------------------

    var surf = surface_create(sprite_w, sprite_h);

    surface_set_target(surf);

    draw_clear_alpha(c_black, 0);

    draw_sprite(_sprite, 0, 0, 0);

    surface_reset_target();


    // -------------------------------------------------
    // Create pixel grid
    // -------------------------------------------------

    var pixels = array_create(sprite_w);

    for (var px = 0; px < sprite_w; px++)
    {
        pixels[px] = array_create(sprite_h, false);

        for (var py = 0; py < sprite_h; py++)
        {
            var pixel_color = surface_getpixel(surf, px, py);

            if (color_get_alpha(pixel_color) > 0)
            {
                pixels[px][py] = true;
            }
        }
    }


    // -------------------------------------------------
    // Free surface
    // -------------------------------------------------

    surface_free(surf);


    // -------------------------------------------------
    // Find boundary edges
    // -------------------------------------------------

    var edge_px1 = [];
    var edge_py1 = [];

    var edge_px2 = [];
    var edge_py2 = [];


    for (var px = 0; px < sprite_w; px++)
    {
        for (var py = 0; py < sprite_h; py++)
        {
            if (!pixels[px][py])
                continue;


            // -----------------------------------------
            // TOP EDGE
            // -----------------------------------------

            if (py == 0 || !pixels[px][py - 1])
            {
                array_push(edge_px1, px);
                array_push(edge_py1, py);

                array_push(edge_px2, px + 1);
                array_push(edge_py2, py);
            }


            // -----------------------------------------
            // RIGHT EDGE
            // -----------------------------------------

            if (px == sprite_w - 1 || !pixels[px + 1][py])
            {
                array_push(edge_px1, px + 1);
                array_push(edge_py1, py);

                array_push(edge_px2, px + 1);
                array_push(edge_py2, py + 1);
            }


            // -----------------------------------------
            // BOTTOM EDGE
            // -----------------------------------------

            if (py == sprite_h - 1 || !pixels[px][py + 1])
            {
                array_push(edge_px1, px + 1);
                array_push(edge_py1, py + 1);

                array_push(edge_px2, px);
                array_push(edge_py2, py + 1);
            }


            // -----------------------------------------
            // LEFT EDGE
            // -----------------------------------------

            if (px == 0 || !pixels[px - 1][py])
            {
                array_push(edge_px1, px);
                array_push(edge_py1, py + 1);

                array_push(edge_px2, px);
                array_push(edge_py2, py);
            }
        }
    }


    // -------------------------------------------------
    // Connect edges into ordered polygon
    // -------------------------------------------------

    var edge_count = array_length(edge_px1);

    var used_edges = array_create(edge_count, false);

    var points = [];


    if (edge_count == 0)
    {
        return points;
    }


    // Start with first edge

    var current_edge = 0;

    used_edges[current_edge] = true;

    var start_px = edge_px1[current_edge];
    var start_py = edge_py1[current_edge];

    var current_px = edge_px2[current_edge];
    var current_py = edge_py2[current_edge];


    array_push(points, {
        px: start_px,
        py: start_py
    });


    while (true)
    {
        // Add current point

        array_push(points, {
            px: current_px,
            py: current_py
        });


        // Have we returned to the beginning?

        if (current_px == start_px && current_py == start_py)
        {
            break;
        }


        var found_next = false;


        // Find an edge that begins where
        // the previous edge ended.

        for (var edge_index = 0; edge_index < edge_count; edge_index++)
        {
            if (used_edges[edge_index])
                continue;


            if (edge_px1[edge_index] == current_px &&
                edge_py1[edge_index] == current_py)
            {
                used_edges[edge_index] = true;

                current_px = edge_px2[edge_index];
                current_py = edge_py2[edge_index];

                found_next = true;

                break;
            }
        }


        if (!found_next)
        {
            show_debug_message(
                "ERROR: Could not connect polygon boundary."
            );

            break;
        }
    }


    // -------------------------------------------------
    // Remove redundant points
    // -------------------------------------------------

    var changed = true;

    while (changed)
    {
        changed = false;

        var point_count = array_length(points);

        if (point_count <= 3)
            break;


        for (var point_index = 0;
             point_index < point_count;
             point_index++)
        {
            var previous_index =
                (point_index - 1 + point_count) mod point_count;

            var next_index =
                (point_index + 1) mod point_count;


            var ax = points[previous_index].px;
            var ay = points[previous_index].py;

            var bx = points[point_index].px;
            var by = points[point_index].py;

            var cx = points[next_index].px;
            var cy = points[next_index].py;


            // Cross product.
            //
            // 0 means all three points are
            // on the same straight line.

            var cross =
                (bx - ax) * (cy - ay)
                -
                (by - ay) * (cx - ax);


            if (cross == 0)
            {
                array_delete(points, point_index, 1);

                changed = true;

                break;
            }
        }
    }


    return points;
}