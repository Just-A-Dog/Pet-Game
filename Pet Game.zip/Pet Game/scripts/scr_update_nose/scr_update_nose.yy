{
  "$GMScript":"v1",
  "%Name":"scr_update_nose",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_update_nose",
  "parent":{
    "name":"Update Freak Position and Depth",
    "path":"folders/Current Scripts/Update Freak Position and Depth.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}