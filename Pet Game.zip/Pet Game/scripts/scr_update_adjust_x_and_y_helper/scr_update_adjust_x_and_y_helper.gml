function scr_update_adjust_x_and_y_helper(_id, _global_type, _transformed_type){
	//Adds a final adjustment based on whether both sprites adjust or not.
	//Starting with x...
	var _x_adj = 0;

	if (variable_instance_exists(_global_type, "x_adj")) {
		var _adj_dir = variable_instance_get(_global_type, "x_adj");

		if (variable_struct_exists(_adj_dir, global.dir[dir_i])) {
			var _adj_array = variable_struct_get(_adj_dir, global.dir[dir_i]);

			if (array_length(_adj_array) > _id.sprite_num) {
				_x_adj = _adj_array[_id.sprite_num];
			}
		}
	}

	global_x_adj = _x_adj;

	_x_adj = 0;

	if (variable_instance_exists(_transformed_type, "x_adj")) {
		var _adj_dir = variable_instance_get(_transformed_type, "x_adj");

		if (variable_struct_exists(_adj_dir, global.dir[dir_i])) {
			var _adj_array = variable_struct_get(_adj_dir, global.dir[dir_i]);

			if (array_length(_adj_array) > _id.sprite_num) {
				_x_adj = _adj_array[_id.sprite_num];
			}
		}
	}

	transformed_x_adj = _x_adj;

	_id.x += global_x_adj + ((transformed_x_adj - global_x_adj) * intensity);
			
	//Then y.
	var _y_adj = 0;

	if (variable_instance_exists(_global_type, "y_adj")) {
		var _adj_dir = variable_instance_get(_global_type, "y_adj");

		if (variable_struct_exists(_adj_dir, global.dir[dir_i])) {
			var _adj_array = variable_struct_get(_adj_dir, global.dir[dir_i]);

			if (array_length(_adj_array) > _id.sprite_num) {
				_y_adj = _adj_array[_id.sprite_num];
			}
		}
	}

	global_y_adj = _y_adj;

	_y_adj = 0;

	if (variable_instance_exists(_transformed_type, "y_adj")) {
		var _adj_dir = variable_instance_get(_transformed_type, "y_adj");

		if (variable_struct_exists(_adj_dir, global.dir[dir_i])) {
			var _adj_array = variable_struct_get(_adj_dir, global.dir[dir_i]);

			if (array_length(_adj_array) > _id.sprite_num) {
				_y_adj = _adj_array[_id.sprite_num];
			}
		}
	}

	transformed_y_adj = _y_adj;
	_id.y += global_y_adj + ((transformed_y_adj - global_y_adj) * intensity);
}