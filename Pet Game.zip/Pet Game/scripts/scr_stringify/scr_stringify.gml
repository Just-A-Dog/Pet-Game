function stringify(p1, p2){
	if (p1[0] > p2[0] || (p1[0] == p2[0] && p1[1] > p2[1])) {
	    var temp = p1;
	    p1 = p2;
	    p2 = temp;
	}

	return string(p1[0]) + "," + string(p1[1]) + "|" + string(p2[0]) + "," + string(p2[1]);
}