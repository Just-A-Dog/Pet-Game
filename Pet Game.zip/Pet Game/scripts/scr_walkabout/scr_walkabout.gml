//Should return all corner points of an image, given the boundary pixels.
//Has a flaw in that it doesn't work on disconnected blobs.
//However, this can be remedied by running both blobs into this and just appending the two blobs' arrays together.
//Since this shouldn't be run in game.

function scr_walkabout(_boundary_pixels, w, h){
	cpx = _boundary_pixels[0][0]; //Current pixel x
	cpy = _boundary_pixels[0][1]; //Current pixel y
	directions = ["N","NE","E","SE","S","SW","W","NW"];
	final_array = [[cpx, cpy]];
	dir = 0;
	
	//Do this until we end up back at the beginning again.
	do{
		found_pix = false;

		for(starting_dir = dir; dir - starting_dir < 9; dir++){
			switch(directions[dir mod array_length(directions)]){
				case("N"):
					if(cpy != 0 and find_adjacent_pixel(_boundary_pixels, cpx, cpy - 1)){
						//Check to see if direction has changed.
						if(directions[starting_dir] != "SW" and (cpx != _boundary_pixels[0][0] or cpy != _boundary_pixels[0][1])){
							array_push(final_array, [cpx, cpy]);
						}
						//Either way, we update the new current point.
						cpy = cpy - 1;
						dir = 5;
						found_pix = true;
					}
				break;
				case("NE"):
					if(cpy != 0 and cpx != w and find_adjacent_pixel(_boundary_pixels, cpx + 1, cpy - 1)){
						//Check to see if direction has changed.
						if(directions[starting_dir] != "W" and (cpx != _boundary_pixels[0][0] or cpy != _boundary_pixels[0][1])){
							array_push(final_array, [cpx, cpy]);
						}
						//Either way, we update the new current point.
						cpy = cpy - 1;
						cpx = cpx + 1;
						dir = 6;
						found_pix = true;
					}
				break;
				case("E"):
					if(cpx != w and find_adjacent_pixel(_boundary_pixels, cpx + 1, cpy)){
						//Check to see if direction has changed.
						if(directions[starting_dir] != "NW" and (cpx != _boundary_pixels[0][0] or cpy != _boundary_pixels[0][1])){
							array_push(final_array, [cpx, cpy]);
						}
						//Either way, we update the new current point.
						cpx = cpx + 1;
						dir = 7;
						found_pix = true;
					}
				break;
				case("SE"):
					if(cpx != w and cpy != h and find_adjacent_pixel(_boundary_pixels, cpx + 1, cpy + 1)){
						//Check to see if direction has changed.
						if(directions[starting_dir] != "N" and (cpx != _boundary_pixels[0][0] or cpy != _boundary_pixels[0][1])){
							array_push(final_array, [cpx, cpy]);
						}
						//Either way, we update the new current point.
						cpx = cpx + 1;
						cpy = cpy + 1;
						dir = 0;
						found_pix = true;
					}
				break;
				case("S"):
					if(cpy != h and find_adjacent_pixel(_boundary_pixels, cpx, cpy + 1)){
						//Check to see if direction has changed.
						if(directions[starting_dir] != "NE" and (cpx != _boundary_pixels[0][0] or cpy != _boundary_pixels[0][1])){
							array_push(final_array, [cpx, cpy]);
						}
						//Either way, we update the new current point.
						cpy = cpy + 1;
						dir = 1;
						found_pix = true;
					}
				break;
				case("SW"):
				if(cpy != h and cpx != 0 and find_adjacent_pixel(_boundary_pixels, cpx - 1, cpy + 1)){
						//Check to see if direction has changed.
						if(directions[starting_dir] != "E" and (cpx != _boundary_pixels[0][0] or cpy != _boundary_pixels[0][1])){
							array_push(final_array, [cpx, cpy]);
						}
						//Either way, we update the new current point.
						cpy = cpy + 1;
						cpx = cpx - 1;
						dir = 2;
						found_pix = true;
					}
				break;
				case("W"):
				if(cpx != 0 and find_adjacent_pixel(_boundary_pixels, cpx - 1, cpy)){
						//Check to see if direction has changed.
						if(directions[starting_dir] != "SE" and (cpx != _boundary_pixels[0][0] or cpy != _boundary_pixels[0][1])){
							array_push(final_array, [cpx, cpy]);
						}
						//Either way, we update the new current point.
						cpx = cpx - 1;
						dir = 3;
						found_pix = true;
					}
				break;
				case("NW"):
				if(cpx != 0 and cpy != 0 and find_adjacent_pixel(_boundary_pixels, cpx - 1, cpy - 1)){
						//Check to see if direction has changed.
						if(directions[starting_dir] != "S" and (cpx != _boundary_pixels[0][0] or cpy != _boundary_pixels[0][1])){
							array_push(final_array, [cpx, cpy]);
						}
						//Either way, we update the new current point.
						cpx = cpx - 1;
						cpy = cpy - 1;
						dir = 4;
						found_pix = true;
					}
				break;
				default: show_debug_message("Something borked.");
				break;
			}
			if(found_pix) break;
		}
		//In case it gets stuck on an island.
		if (!found_pix) break;
		
	}
	until(cpx == _boundary_pixels[0][0] and cpy == _boundary_pixels[0][1])
	return final_array;
}