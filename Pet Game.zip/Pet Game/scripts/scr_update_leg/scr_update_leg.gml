function scr_update_leg(_id){
	_id.dir_i = dir_i;
	var leg_sprite = _id.leg_sprite;
	var left = _id.left;
	var sprite_num = _id.sprite_num;
	var width = 0;
	var skeleton = _id.freak_id.body_skeleton;
	var location_color = _id.location_color;
	var found = false;
	//Adjust x and y based on the color in the skeleton intensity
	if(leg_sprite[dir_i] != -1){
		if(!left) width = scr_get_width_and_height(leg_sprite[dir_i][sprite_num])[0];
		for(var i = 0; i < array_length(skeleton.current_list); i++){
			if(skeleton.current_list[i][2] == location_color){
				_id.x = floor(skeleton.current_list[i][0]) + skeleton.x - width;
				_id.y = floor(skeleton.current_list[i][1]) + skeleton.y;
				found = true;
				break;
			}
		}
	}
	if(!left and (dir == "sw" or dir == "w" or dir == "nw")) _id.depth = _id.freak_id.depth -1;
	else if(left and (dir == "ne" or dir == "e" or dir == "se")) _id.depth = _id.freak_id.depth -1;
	else _id.depth = _id.freak_id.depth + 1;
	
	
	if(!found or _id.current_sprite == -1) _id.invisible = true;
	else _id.invisible = false;
}