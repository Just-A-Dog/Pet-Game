function scr_find_xydepth_chin(c_type = chin_type){
	dir_i = array_get_index(global.dir, dir);
	var color = "";
	if(variable_struct_exists(color_coords[dir_i], "128,0,0") or variable_struct_exists(color_coords[dir_i], "255,128,128")){
		if(variable_struct_exists(color_coords[dir_i], "128,0,0")) color = "128,0,0";
		else color = "255,128,128";		
		var half_width = floor(sprite_get_width(variable_struct_get(base_chin_type, dir))/2);
		chin_x = freak_id.x + variable_struct_get(color_coords[dir_i], color)[0] - half_width;
		chin_y = freak_id.y + variable_struct_get(color_coords[dir_i], color)[1];
	}
	else{
		chin_x = 0;
		chin_y = 0;
		//chin_depth = 0;
		invisible = true;
	}
}