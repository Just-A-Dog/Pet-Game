{
  "$GMScript":"v1",
  "%Name":"scr_get_max_width_and_height",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_get_max_width_and_height",
  "parent":{
    "name":"Other",
    "path":"folders/Current Scripts/Other.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}