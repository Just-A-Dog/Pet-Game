function scr_get_max_width_and_height(_list_of_pixels){
	var max_x = -1;
	var max_y = -1;
	for(var i = 0; i < array_length(_list_of_pixels); i++){
		max_x = max(max_x, _list_of_pixels[i][0]);
		max_y = max(max_y, _list_of_pixels[i][1]);		
	}
	return [max_x, max_y];
}