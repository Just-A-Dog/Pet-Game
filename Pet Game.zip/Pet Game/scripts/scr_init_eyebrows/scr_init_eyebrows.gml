function scr_init_eyebrows(){
	global.base_left_eyebrow = {
		s : spr_base_s_idle_eyebrow,
		sw : spr_base_s_idle_eyebrow,
		w : -1,
		nw : -1,
		n : -1,
		ne : -1,
		e : spr_base_s_idle_eyebrow,
		se : spr_base_s_idle_eyebrow,
	}

	global.base_right_eyebrow = {
		s : spr_base_s_idle_eyebrow_r,
		sw : spr_base_s_idle_eyebrow_r,
		w : spr_base_s_idle_eyebrow_r,
		nw : -1,
		n : -1,
		ne : -1,
		e : -1,
		se : spr_base_s_idle_eyebrow_r,
	}
}