function scr_update_arm(_id){
	_id.dir_i = dir_i;
	var arm_sprite = _id.arm_sprite;
	var left = _id.left;
	var width = 0;
	var skeleton = _id.freak_id.body_skeleton;
	var found = false; //Yes we need both.
	
	//Adjust x and y based on the color in the skeleton intensity
	//If arm is left, it gets placed minus width. Else, just x or y.
	if(arm_sprite[dir_i] != -1){
		if(left) width = scr_get_width_and_height(arm_sprite[dir_i][_id.sprite_num])[0];
		found = false;
		for(var i = 0; i < array_length(skeleton.current_list); i++){
			if(skeleton.current_list[i][2] == _id.location_color){
				if(left){
					_id.x = floor(skeleton.current_list[i][0]) + skeleton.x - width;
					_id.y = floor(skeleton.current_list[i][1]) + skeleton.y;
				}
				else{
					_id.x = ceil(skeleton.current_list[i][0]) + skeleton.x - width;
					_id.y = ceil(skeleton.current_list[i][1]) + skeleton.y;
				}
				found = true;
				break;
			}
		}
	}
	if(!left and (dir == "sw" or dir == "w" or dir == "nw")) _id.depth = -1;
	else if(left and (dir == "ne" or dir == "e" or dir == "se")) _id.depth = -1;
	else _id.depth = 2;
	
	if(!found or _id.current_sprite == -1) _id.invisible = true;
	else _id.invisible = false;
}