{
  "$GMScript":"v1",
  "%Name":"scr_draw_outline_2",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_draw_outline_2",
  "parent":{
    "name":"DRAW",
    "path":"folders/Current Scripts/DRAW.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}