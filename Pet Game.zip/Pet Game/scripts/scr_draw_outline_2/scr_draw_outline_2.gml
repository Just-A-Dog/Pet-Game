function scr_draw_outline_2(_outline_pixels, _base_color = c_gray, _head_offset = infinity){
	//Figure out where the bottom rows are.
	for(_i = 0; _i < array_length(_outline_pixels); _i++){
		//Doesn't redraw repeating pixels, and if its a head, cuts off the head where appropriate.
		if((_i == 0 or _outline_pixels[_i][0] != _outline_pixels[_i - 1][0] or _outline_pixels[_i][1] != _outline_pixels[_i - 1][1])
		and _head_offset >= _outline_pixels[_i][1]){
			draw_set_color(_outline_pixels[_i][2]);
			draw_point(x + _outline_pixels[_i][0], y + _outline_pixels[_i][1]);
		}
	}
}