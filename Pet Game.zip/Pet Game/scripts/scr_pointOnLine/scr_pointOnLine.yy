{
  "$GMScript":"v1",
  "%Name":"scr_pointOnLine",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_pointOnLine",
  "parent":{
    "name":"Body Part Init",
    "path":"folders/Current Scripts/Body Part Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}