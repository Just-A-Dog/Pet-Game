//Line thickness must be at least [Can be higher but not lower]
function scr_pointOnLine(x, y, x1, y1, x2, y2, lineThickness = 0.5, rounded = false, infinite = false)
{
    //Find the dot product between the line vector and the vector from the first endpoint to the coordinate we're checking
    var t = dot_product(x2 - x1, y2 - y1, x - x1, y - y1);

    //Divide t by the square of the length of the line segment so that a coordinate at (x1, y1) corresponds to 0, and a coordinate at (x2, y2) corresponds to 1
    t /= dot_product(x2 - x1, y2 - y1, x2 - x1, y2 - y1);

    //Clamp t so that it is always between 0 and 1
    if (!infinite)
    {
        if (rounded)
        {
            //Rounded edges
            t = clamp(t, 0, 1);
        }
        else if (t < 0 || t > 1)
        {
            //Flat edges
            return false;
        }
    }

    //Find the projected coordinates on the line segment
    var px = lerp(x1, x2, t);
    var py = lerp(y1, y2, t);

    //Find the distance between the point and the line segment
    var d = point_distance(x, y, px, py);

    //Check if the distance is above some threshold value, ie. the thickness of the line
    if (d > lineThickness){return d;}

    return true;
}