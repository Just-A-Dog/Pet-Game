{
  "$GMScript":"v1",
  "%Name":"scr_pair_points_symmetrical",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_pair_points_symmetrical",
  "parent":{
    "name":"Outdated",
    "path":"folders/Current Scripts/Outdated.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}