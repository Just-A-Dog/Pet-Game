//Takes two lists of pixels, and associates each pixel with the closest one on the other list.
function scr_pair_points_symmetrical(cp_1, cp_2, sym_line){
	final_array = [];
	second_half_array = [];
	//Swaps arrays if the longer one is second.
	if(array_length(cp_2) > array_length(cp_1)){
		temp = cp_1;
		cp_1 = cp_2;
		cp_2 = temp;
	}
	
cpi2 = 0;

var closest_x_distance = 1000;

for (var j = 0; j < array_length(cp_2); j++) {
    var x_distance = abs(cp_2[j][0] - sym_line);

    if (x_distance < closest_x_distance) {
        closest_x_distance = x_distance;
        cpi2 = j;
    }

    // Prefer an exact match if one exists.
    if (x_distance == 0) {
        break;
    }
}

prev_point_index = cpi2;
cpi2_points_left = array_length(cp_2);
//
	slc = 0;
	for(_i = 0; _i < array_length(cp_1); _i++){
		debug = true;
		if(cp_2[cpi2][0] == 33 and cp_2[cpi2][1] == 43){
			//show_debug_message("FOUND POINT!!!");
		}
		else debug = false;
		if debug show_debug_message("Checking to see if passed the sym_line.");
		if(cp_1[_i][0] >= sym_line){		
			if debug show_debug_message("PASSED THE SYM LINE.");
			slc ++;
			distance_from_new_point = point_distance(cp_1[_i][0], cp_1[_i][1], cp_2[cpi2][0], cp_2[cpi2][1]);
			distance_from_prev_point = point_distance(cp_1[_i][0], cp_1[_i][1], cp_2[prev_point_index][0], cp_2[prev_point_index][1]);

			//We also need to check for the remaining points in cp_2. If there is an equal number of remaining points, then we just assign them to each next cp_1
			//The new large array point is closer to the new smaller array point, rather than the older array point.
			//Also automatically goes to the next one if there aren't enough points left.
			if(distance_from_new_point <= distance_from_prev_point or array_length(cp_1) - _i == cpi2_points_left){
				if debug show_debug_message("DISTANCE IS CLOSER TO NEXT POINT.");
				array_push(final_array, [cp_1[_i][0], cp_1[_i][1], cp_2[cpi2][0], cp_2[cpi2][1], cp_1[_i][2], cp_2[cpi2][2]]);

				//Adds mirror into second_half_array in reverse order.
				if(cp_1[_i][0] != sym_line){
					array_insert(second_half_array, 0, [sym_line - (cp_1[_i][0] - sym_line), cp_1[_i][1], sym_line - (cp_2[cpi2][0] - sym_line), cp_2[cpi2][1], cp_1[_i][2], cp_2[cpi2][2]]);
					//show_debug_message("Pairing points [New point]: " + string([cp_2[cpi2][0], cp_2[cpi2][1]]));
					//show_debug_message("Mirrored point: " + string([sym_line - (cp_2[cpi2][0] - sym_line), cp_2[cpi2][1]]));
				}

				//Updates comparison point
				prev_point_index = cpi2;
				if(array_length(cp_2) != cpi2 + 1) cpi2++;
				else cpi2 = 0;
				cpi2_points_left--;
			}
			else{
				if debug show_debug_message("DISTANCE IS CLOSER TO PREVIOUS POINT.");
				array_push(final_array, [cp_1[_i][0], cp_1[_i][1], cp_2[prev_point_index][0], cp_2[prev_point_index][1], cp_1[_i][2], cp_2[prev_point_index][2]]);
				if(cp_1[_i][0] != sym_line){
					array_insert(second_half_array, 0, [sym_line - (cp_1[_i][0] - sym_line), cp_1[_i][1], sym_line - (cp_2[prev_point_index][0] - sym_line), cp_2[prev_point_index][1], cp_1[_i][2], cp_2[prev_point_index][2]]);
					//show_debug_message("Pairing points [Old point]: " + string(final_array,[cp_2[prev_point_index][0], cp_2[prev_point_index][1]]));
					//show_debug_message("Mirrored point: " + string([sym_line - (cp_2[prev_point_index][0] - sym_line), cp_2[prev_point_index][1]]));
				}
			}
		}
		if debug show_debug_message("DONE CHECKING.");
	}
	return array_concat(final_array, second_half_array);
}