function scr_init_mouths(){
	global.base_mouth = {
		s : spr_base_s_idle_mouth,
		sw : spr_base_s_idle_mouth,
		w : spr_base_w_idle_mouth,
		nw : -1,
		n : -1,
		ne : -1,
		e : spr_base_w_idle_mouth_r,
		se : spr_base_s_idle_mouth,	
	}

	global.raccoon_mouth = {
		s : spr_raccoon_s_idle_mouth,
		sw : spr_raccoon_s_idle_mouth,
		w : spr_raccoon_w_idle_mouth,
		nw : -1,
		n : -1,
		ne : -1,
		e : spr_raccoon_w_idle_mouth_r,
		se : spr_raccoon_s_idle_mouth,	
	}
}