{
  "$GMScript":"v1",
  "%Name":"scr_find_xydepth_body",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_find_xydepth_body",
  "parent":{
    "name":"Find XYDEPTH",
    "path":"folders/Current Scripts/Find XYDEPTH.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}