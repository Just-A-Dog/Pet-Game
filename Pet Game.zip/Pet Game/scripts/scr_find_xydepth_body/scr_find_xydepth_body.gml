function scr_find_xydepth_body(){
	dir_i = array_get_index(global.dir, dir);
	if(variable_struct_exists(color_coords[dir_i], "128,0,255")){
		body_x = freak_id.x + variable_struct_get(color_coords[dir_i], "128,0,255")[0];
		body_y = freak_id.y + variable_struct_get(color_coords[dir_i], "128,0,255")[1];
		invisible = false;
	}
	else{
		body_x = 0;
		body_y = 0;
		body_depth = 0;
		invisible = true;
	}
}