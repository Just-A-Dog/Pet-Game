{
  "$GMScript":"v1",
  "%Name":"scr_find_adjacent_pixel_color",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_find_adjacent_pixel_color",
  "parent":{
    "name":"Body Part Init",
    "path":"folders/Current Scripts/Body Part Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}