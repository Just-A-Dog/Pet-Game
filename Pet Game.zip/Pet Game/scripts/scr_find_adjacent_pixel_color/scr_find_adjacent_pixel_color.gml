function find_adjacent_pixel_color(_boundary_pixels, _x, _y){
	for (var i = 0; i < array_length(_boundary_pixels); i++){
		if (_boundary_pixels[i][0] == _x && _boundary_pixels[i][1] == _y){
			return _boundary_pixels[i][2];
		}
	}
	
	return undefined;
}