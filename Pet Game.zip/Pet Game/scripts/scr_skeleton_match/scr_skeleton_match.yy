{
  "$GMScript":"v1",
  "%Name":"scr_skeleton_match",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_skeleton_match",
  "parent":{
    "name":"Skeleton Stuff",
    "path":"folders/Current Scripts/Skeleton Stuff.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}