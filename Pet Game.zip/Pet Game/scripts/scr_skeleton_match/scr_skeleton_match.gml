function scr_skeleton_match(sprite1, sprite2) {
	var color_groups = [
	    {
	        base: [0, 0, 255], // Blue
	        equivalents: [
	            //[0, 128, 0],   // Green
	            //[128, 128, 255] // Periwinkle
	        ]
	    }
	];	
	
    var w1 = sprite_get_width(sprite1);
    var h1 = sprite_get_height(sprite1);

    var w2 = sprite_get_width(sprite2);
    var h2 = sprite_get_height(sprite2);

    // Create surfaces for both sprites.
    var surf1 = surface_create(w1, h1);
    var surf2 = surface_create(w2, h2);

    // Draw Sprite 1 onto its surface.
    surface_set_target(surf1);
    draw_clear_alpha(c_black, 0);
    draw_sprite(sprite1, 0, 0, 0);
    surface_reset_target();

    // Draw Sprite 2 onto its surface.
    surface_set_target(surf2);
    draw_clear_alpha(c_black, 0);
    draw_sprite(sprite2, 0, 0, 0);
    surface_reset_target();

    var pixels1 = [];
    var pixels2 = [];

    // Read all non-transparent pixels from Sprite 1.
    surface_set_target(surf1);

    for (var py = 0; py < h1; py++) {
        for (var px = 0; px < w1; px++) {
            var pixel = surface_getpixel_ext(surf1, px, py);
            var alpha = (pixel >> 24) & 255;

            if (alpha > 0) {
                var red = pixel & 255;
                var green = (pixel >> 8) & 255;
                var blue = (pixel >> 16) & 255;

                array_push(pixels1, [px, py, [red, green, blue]]);
            }
        }
    }

    surface_reset_target();

    // Read all non-transparent pixels from Sprite 2.
    surface_set_target(surf2);

    for (var py = 0; py < h2; py++) {
        for (var px = 0; px < w2; px++) {
            var pixel = surface_getpixel_ext(surf2, px, py);
            var alpha = (pixel >> 24) & 255;

            if (alpha > 0) {
                var red = pixel & 255;
                var green = (pixel >> 8) & 255;
                var blue = (pixel >> 16) & 255;

                array_push(pixels2, [px, py, [red, green, blue]]);
            }
        }
    }

    surface_reset_target();

	// Match pixels by RGB color.
	var result = [];

	for (var i = 0; i < array_length(pixels1); i++) {
	    var p1 = pixels1[i];
	    var rgb1 = p1[2];

	    for (var j = 0; j < array_length(pixels2); j++) {
	        var p2 = pixels2[j];
	        var rgb2 = p2[2];

	        var matched = false;

	        // First, check for an exact color match.
	        if (rgb1[0] == rgb2[0]
	        &&  rgb1[1] == rgb2[1]
	        &&  rgb1[2] == rgb2[2]) {
	            matched = true;
	        }

	        // Check whether Sprite 1's color has equivalents.
	        if (!matched) {
	            for (var g = 0; g < array_length(color_groups); g++) {
	                var group = color_groups[g];
	                var base = group.base;

	                if (rgb1[0] == base[0]
	                &&  rgb1[1] == base[1]
	                &&  rgb1[2] == base[2]) {

	                    for (var k = 0; k < array_length(group.equivalents); k++) {
	                        var equivalent = group.equivalents[k];

	                        if (rgb2[0] == equivalent[0]
	                        &&  rgb2[1] == equivalent[1]
	                        &&  rgb2[2] == equivalent[2]) {
	                            matched = true;
	                            break;
	                        }
	                    }
	                }
	            }
	        }

	        if (matched) {
	            array_push(result, [
	                p1[0],
	                p1[1],
	                p2[0],
	                p2[1],
	                make_color_rgb(rgb1[0], rgb1[1], rgb1[2])
	            ]);
	        }
	    }
	}

    // Clean up the surfaces.
    surface_free(surf1);
    surface_free(surf2);

    return result;
}