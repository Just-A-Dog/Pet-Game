function scr_find_xydepth_eye(eye_type, eyebrow_type){
	dir_i = array_get_index(global.dir, dir);
	
	//Left Eye
	if(variable_struct_exists(color_coords[dir_i], "0,255,0") and left){
		invisible = false;
		eyebrow_invisible = false;
		
		eye_sprite = variable_struct_get(eye_type, dir);
		eye_w = sprite_get_width(eye_sprite);
		eye_h = sprite_get_height(eye_sprite);

		var color = variable_struct_get(color_coords[dir_i], "0,255,0");
		eye_x = freak_id.x + (color[0] - eye_w) + 1;
		eye_y = freak_id.y + (color[1] - eye_h) + 1;
		eye_depth = -1;
		
		//Left Eyebrow
		eyebrow_sprite = variable_instance_get(eyebrow_type, dir);
		eyebrow_w = sprite_get_width(eyebrow_sprite);

		eyebrow_x = eye_x + eye_w - eyebrow_w - 1;
		eyebrow_y = eye_y - 2;	
		eyebrow_depth = -1;
	}
	
	//Right Eye
	else if(variable_struct_exists(color_coords[dir_i], "0,255,255") and !left){
		invisible = false;
		eyebrow_invisible = false;
		
		eye_sprite = variable_struct_get(eye_type, dir);
		eye_w = sprite_get_width(eye_sprite);
		eye_h = sprite_get_height(eye_sprite);

		var color = variable_struct_get(color_coords[dir_i], "0,255,255");
		eye_x = freak_id.x + color[0];
		eye_y = freak_id.y + (color[1] - eye_h) + 1;
		eye_depth = -1;
		
		//Right Eyebrow
		eyebrow_sprite = variable_instance_get(eyebrow_type, dir);
		eyebrow_w = sprite_get_width(eyebrow_sprite);

		eyebrow_x = eye_x + 1;
		eyebrow_y = eye_y - 2;	
		eyebrow_depth = -1;
	}
	else{
		eye_x = 0;
		eye_y = 0;
		eye_depth = -1;

		eyebrow_x = 0;
		eyebrow_y = 0;
		eyebrow_depth = -1;
		
		invisible = true;
		eyebrow_invisible = true;
	}
}