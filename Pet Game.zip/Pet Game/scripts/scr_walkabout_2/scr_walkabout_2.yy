{
  "$GMScript":"v1",
  "%Name":"scr_walkabout_2",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_walkabout_2",
  "parent":{
    "name":"Body Part Init",
    "path":"folders/Current Scripts/Body Part Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}