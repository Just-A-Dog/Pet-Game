function scr_walkabout_2(_boundary_pixels, w, h){
	cpx = floor(_boundary_pixels[0][0]); //Default pixel x
	cpy = floor(_boundary_pixels[0][1]); //Default pixel y
	directions = ["N","NE","E","SE","S","SW","W","NW"];
	final_array = [];
	_dir = 0;
	
	for(var i = 0; i < array_length(_boundary_pixels); i++){
		if(_boundary_pixels[i][1] < cpy or (_boundary_pixels[i][0] < cpx and _boundary_pixels[i][1] == cpy)){
			cpy = floor(_boundary_pixels[i][1]);
			cpx = floor(_boundary_pixels[i][0]);
		}
	}
	ending_x = cpx;
	ending_y = cpy;

	array_push(final_array, [cpx, cpy, _boundary_pixels[0][2]]);	
	
	//Do this until we end up back at the beginning again.
	do{
		found_pix = false;

		for(starting_dir = _dir; _dir - starting_dir < 9; _dir++){
			//if(cpx == 20 and cpy = 1) debug = true;
			//else 
			switch(directions[_dir mod array_length(directions)]){
				case("N"):
					if(cpy != 0 and find_adjacent_pixel(_boundary_pixels, cpx, cpy - 1)){
						array_push(final_array, [cpx, cpy, find_adjacent_pixel_color(_boundary_pixels, cpx, cpy)]);
						cpy = cpy - 1;
						_dir = 5;
						found_pix = true;
					}
				break;
				case("NE"):
					if(cpy != 0 and cpx != w and find_adjacent_pixel(_boundary_pixels, cpx + 1, cpy - 1)){
						array_push(final_array, [cpx, cpy, find_adjacent_pixel_color(_boundary_pixels, cpx, cpy)]);
						cpy = cpy - 1;
						cpx = cpx + 1;
						_dir = 6;
						found_pix = true;
					}
				break;
				case("E"):
					if(cpx != w and find_adjacent_pixel(_boundary_pixels, cpx + 1, cpy)){
						array_push(final_array, [cpx, cpy, find_adjacent_pixel_color(_boundary_pixels, cpx, cpy)]);
						cpx = cpx + 1;
						_dir = 7;
						found_pix = true;
					}
				break;
				case("SE"):
					if(cpx != w and cpy != h and find_adjacent_pixel(_boundary_pixels, cpx + 1, cpy + 1)){
						array_push(final_array, [cpx, cpy, find_adjacent_pixel_color(_boundary_pixels, cpx, cpy)]);
						cpx = cpx + 1;
						cpy = cpy + 1;
						_dir = 0;
						found_pix = true;
					}
				break;
				case("S"):
					if(cpy != h and find_adjacent_pixel(_boundary_pixels, cpx, cpy + 1)){
						array_push(final_array, [cpx, cpy, find_adjacent_pixel_color(_boundary_pixels, cpx, cpy)]);
						cpy = cpy + 1;
						_dir = 1;
						found_pix = true;
					}
				break;
				case("SW"):
					if(cpy != h and cpx != 0 and find_adjacent_pixel(_boundary_pixels, cpx - 1, cpy + 1)){
						array_push(final_array, [cpx, cpy, find_adjacent_pixel_color(_boundary_pixels, cpx, cpy)]);
						cpy = cpy + 1;
						cpx = cpx - 1;
						_dir = 2;
						found_pix = true;
					}
				break;
				case("W"):
					if(cpx != 0 and find_adjacent_pixel(_boundary_pixels, cpx - 1, cpy)){
						array_push(final_array, [cpx, cpy, find_adjacent_pixel_color(_boundary_pixels, cpx, cpy)]);
						cpx = cpx - 1;
						_dir = 3;
						found_pix = true;
					}
				break;
				case("NW"):
					if(cpx != 0 and cpy != 0 and find_adjacent_pixel(_boundary_pixels, cpx - 1, cpy - 1)){
						array_push(final_array, [cpx, cpy, find_adjacent_pixel_color(_boundary_pixels, cpx, cpy)]);
						cpx = cpx - 1;
						cpy = cpy - 1;
						_dir = 4;
						found_pix = true;
					}
				break;
				default: show_debug_message("Something borked.");
				break;
			}
			if(found_pix) break;
		}
		//In case it gets stuck on an island.
		if (!found_pix) break;
		
	}
	until(cpx == ending_x and cpy == ending_y)
	return final_array;
}