//Takes two lists of pixels, and associates each pixel with the closest one on the other list.
function scr_pair_points(cp_1, cp_2){
	distance_array = [];
	if(array_length(cp_1) <= array_length(cp_2)){
		//Reverse is to simply maintain order of the two inputted ones.
		reverse = false;
		s_array = cp_1;
		l_array = cp_2;
	}
	else{
		reverse = true;
		s_array = cp_2;
		l_array = cp_1;
	}
	for(var i = 0; i < array_length(s_array); i++){
		minimum_distance = 999;
		delete_index = -1;
		mp_x = -1;
		mp_y = -1;
		 for(j = 0; j < array_length(l_array); j++){
			distance = point_distance(s_array[i][0], s_array[i][1], l_array[j][0], l_array[j][1])
			if(distance < minimum_distance){
				minimum_distance = distance;
				delete_index = j;
				mp_x = l_array[j][0];
				mp_y = l_array[j][1];
			}
		 }
		 if(mp_x >= 0){
			array_delete(l_array, delete_index, 1);
			if(reverse)	array_push(distance_array, [mp_x, mp_y, s_array[i][0], s_array[i][1]]);
			else array_push(distance_array, [s_array[i][0], s_array[i][1], mp_x, mp_y]);
		 }
	}
	
	//Iterate through the remaining larger_array points 
	for(var i = 0; i < array_length(l_array); i++){
		minimum_distance = 999;
		delete_index = -1;
		mp_x = -1;
		mp_y = -1;
		for(j = 0; j < array_length(s_array); j++){
			distance = point_distance(l_array[i][0], l_array[i][1], s_array[j][0], s_array[j][1])
			if(distance < minimum_distance){
				minimum	= distance;
				mp_x = s_array[j][0];
				mp_y = s_array[j][1];
			}
		}
		 if(mp_x >= 0){
			if(reverse)	array_push(distance_array, [l_array[i][0], l_array[i][1], mp_x, mp_y]);
			else array_push(distance_array, [mp_x, mp_y, l_array[i][0], l_array[i][1]]);
		 }
	}
	return distance_array;
}