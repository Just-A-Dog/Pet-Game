function scr_draw_shape(_points){

	if(array_length(_points) > 0) cp = _points[0];
	else return false;

	temp_array = [];
	array_copy(temp_array, 0, _points, 0, array_length(_points));
		
	do{
		//Search left of this point for the CLOSEST point that is either on the _points list or between two concurrent points that is exactly to the left of this one.
		
		//If it finds one:
			//- If the point is less than its x and not next in the list order, then we mark x1 as being tpx+1, tpy [target point's x], cpx - 1, cpcpy [current point's connected point] and draw it. 
			//- Then, if the x is off for tp's connected point, we draw a triangle, (tpx + 1, tpy, tpx + 1, cpcpy, lcpx + 1 {lower connected point}, lcpy)
			//- We also check to see if the x is off for the connected point, and draw a triangle for that. (cpx - 1, cpy, cpx - 1, cpcpy, cpcpx - 1, cpcpy)

		//- If the current point is on the temp list and it found a paired point to draw a line between, we remove it and the connecting point [if applicable] from the temp list.	
		}until(cp == _points[0]);
}