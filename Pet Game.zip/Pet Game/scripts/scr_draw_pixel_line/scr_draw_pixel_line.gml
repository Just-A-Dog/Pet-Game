function scr_draw_pixel_line(x1, y1, x2, y2){
	//For now only draws straight lines
	draw_rectangle(x1,y1,x2+1,y2+1,false);
}