function scr_init_ears(){
	global.base_right_ear = {
		x_adj : {
			n : [2],
			ne : [2],
		},
		s : spr_base_s_idle_ear,
		sw : spr_base_s_idle_ear,
		w : spr_base_s_idle_ear,
		nw : spr_base_s_idle_ear,
		n : spr_base_s_idle_ear,
		ne : spr_base_s_idle_ear,
		e : spr_base_s_idle_ear,
		se : spr_base_s_idle_ear,
	}

	global.base_left_ear = {
		x_adj : {
			n : [-2],	
		},		
		s : spr_base_s_idle_ear_r,
		sw : spr_base_s_idle_ear_r,
		w : spr_base_s_idle_ear_r,
		nw : spr_base_s_idle_ear_r,
		n : spr_base_s_idle_ear_r,
		ne : spr_base_s_idle_ear_r,
		e : spr_base_s_idle_ear_r,
		se : spr_base_s_idle_ear_r,
	}
	
	global.raccoon_right_ear = {
		s : spr_raccoon_s_idle_ear,
		sw : spr_raccoon_sw_idle_ear,
		w : spr_raccoon_w_idle_ear,
		nw : spr_raccoon_sw_idle_ear_r,
		n : spr_raccoon_s_idle_ear_r,
		ne : spr_raccoon_sw_idle_ear_r,
		e : spr_raccoon_w_idle_ear,
		se : spr_raccoon_sw_idle_ear,
	}
	
	global.raccoon_left_ear = {
		s : spr_raccoon_s_idle_ear_r,
		sw : spr_raccoon_sw_idle_ear_r,
		w : spr_raccoon_w_idle_ear_r,
		nw : spr_raccoon_sw_idle_ear,
		n : spr_raccoon_s_idle_ear,
		ne : spr_raccoon_sw_idle_ear,
		e : spr_raccoon_w_idle_ear_r,
		se : spr_raccoon_sw_idle_ear_r,
	}

}