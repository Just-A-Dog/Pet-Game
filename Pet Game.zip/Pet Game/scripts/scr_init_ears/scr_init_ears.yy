{
  "$GMScript":"v1",
  "%Name":"scr_init_ears",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_init_ears",
  "parent":{
    "name":"Init",
    "path":"folders/Current Scripts/Init.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}